﻿Imports System.Data.SqlClient
Public Class QCSMBulkAddUsers

    ' QC Admin Connections
    Dim SAClientSource As New SACLIENTLib.SAapi
    Dim SAClientTarget As New SACLIENTLib.SAapi
    ' QC Client Connections and objects
    Dim tdconSource As New TDAPIOLELib.TDConnection
    Dim tdconTarget As New TDAPIOLELib.TDConnection
    Dim tdconUsersList As New TDAPIOLELib.List
    Dim tdconCustom As TDAPIOLELib.Customization
    Dim tdconCustomUser As TDAPIOLELib.CustomizationUser
    Dim tdconCustomUsers As TDAPIOLELib.CustomizationUsers
    Dim tdconCustomLists As TDAPIOLELib.CustomizationLists
    Dim tdconCustomGroup As TDAPIOLELib.CustomizationUsersGroup
    Dim tdconCustomGroups As TDAPIOLELib.CustomizationUsersGroups

    Dim tdconCommand, tdconCommand2 As TDAPIOLELib.Command
    Dim tdconRecSet, tdconRecSet2 As TDAPIOLELib.Recordset

    Dim tdconUserAsset As TDAPIOLELib.UserAsset
    Dim tdconUserAssetFactory As TDAPIOLELib.UserAssetFactory

    Dim ExcelObj As Object
    Dim ws As Microsoft.Office.Interop.Excel.Worksheet
    Dim wb As Microsoft.Office.Interop.Excel.Workbook

    ' SQL variables
    Dim sqlConn As SqlConnection
    Dim sqlCmd As SqlCommand
    Dim sqlReader As SqlDataReader
    Dim sqlresults As String

    ' SA URLs
    Dim SASource, SATarget, SAReport

    ' Outlook Definitions
    Dim ApprEmail As New Microsoft.Office.Interop.Outlook.Application
    Dim oMailItem As Microsoft.Office.Interop.Outlook.MailItem
    Dim almUSer As Microsoft.Office.Interop.Outlook.Recipient
    Dim userEntry As Microsoft.Office.Interop.Outlook.AddressEntry

    Dim oWrite As System.IO.StreamWriter

    ' Global variables...
    Dim strFileName, userIDs(10000), userNames(10000), emails(10000), userGroups(10000), domainAuth, siteDB As String
    Dim sqlString, sqlString2 As String

    Dim truistID, outlookAlias, outlookName, outlookEmail, newUserID, newUserName, newUserEmail, newUserAuth, workingString, nameParts As String

    Dim saReply, saReply2

    Dim xID, uValue1, uValue2, uValue3, uValue4, uValue5, uValue6, uValue7 As String
    Dim tDomain, tProject, excelVersion As String
    Dim ndx, ndx2, ndx3, ndx4, ndx5, nrows, nCol, CommitOrNot, groupsLeft As Integer
    Dim pdata, pdatastring, tempGroups, tempName, strDate, sumreport, filePath As String
    Dim alreadyIn, notDone, decrimentGroup As Boolean
    Dim tempArray(), tempString As String


    Const report_DIR As String = "c:\Temp"


    ' Version notes
    '
    ' v 1.0 - Initial version - hSTI ALM only
    ' v 1.1 - Added hBBT ALM and multiple roles
    ' v 1.2 - Fixes for hBBT project migration loads
    ' v 1.3 - Added logic to covert hSTI IDs to Truist IDs and Outlook name checking, cleanup of project group
    ' v 1.4 - Added straight SQL to set the LDAP authentication
    '

    Private Sub QCSMBulkAddUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Set up any pre-requirements here...

    End Sub
    Private Sub importUsers_Click(sender As Object, e As EventArgs) Handles importUsers.Click

        Dim undx, serverNum As Integer

        ' Current hSTI ALM values...

        domainAuth = "BBT"
        serverNum = 2
        siteDB = "qcsiteadmin_db1260dev"

        ' Set up report...
        strDate = DateTime.Now.ToString("yyyy-MM-dd")
        filePath = report_DIR & "\" & "ALM-Bulk-User-Import_" & strDate & ".txt"

        sumreport = "ALM Bulk User Import" & vbCrLf & "------------------------------" & vbCrLf
        sumreport = sumreport & "  Date Run     : " & strDate & vbCrLf & vbCrLf
        sumreport = sumreport & "  Target ALM   : " & cmbURL.Text & vbCrLf
        sumreport = sumreport & "        Domain : " & cmbDomain.Text & " Project: " & cmbProject.Text & vbCrLf & vbCrLf

        ' Main processing code...

        tDomain = cmbDomain.Text
        tProject = cmbProject.Text
        SASource = cmbURL.Text

        ' Basic ALM connection to service...
        tdconSource.Connect(tDomain, tProject)
        tdconUsersList = tdconSource.UsersList
        tdconCustom = tdconSource.Customization
        tdconCustomGroups = tdconCustom.UsersGroups

        ' Fetch all of the current users from the site admin database...
        SAClientSource.Login(SASource, txtUser.Text, txtPassword.Text)
        ' saReply2 = SAClientSource.GetAllUsers

        ' Set up the direct SQL connection to the site admin database...

        sqlConn = New SqlConnection("Server=GA016VDE74;Database=" & siteDB & ";User Id=testdirector;Password=x87r5;")

        ' Clear out the temp user space...

        For ndx2 = 0 To nrows
            userGroups(ndx2) = ""
        Next

        ' Open the Excel file...

        RunStatus.Text = "Opening source file..."
        Application.DoEvents()

        ' Set up Excel objects...
        ExcelObj = CreateObject("Excel.Application")
        excelVersion = ExcelObj.Version

        ' Open the spreadsheet source...

        ExcelObj.Workbooks.Open(strFileName)
        wb = ExcelObj.ActiveWorkbook
        ws = ExcelObj.Sheets.Item(1)

        ' Get the range and count...

        nrows = ws.UsedRange.Rows.Count

        If hasHeaders.Checked Then
            ndx = 2
        Else
            ndx = 1
        End If

        RunStatus.Text = "Loading users to import..."
        Application.DoEvents()

        ' Bulk load the mandatory fields to use, then close the spreadsheet...

        For ndx2 = ndx To nrows

            userIDs(ndx2 - ndx) = ws.Cells(ndx2, 1).Value         ' User ID

            RunStatus.Text = "Loading user '" & userIDs(ndx2 - ndx) & "'..."
            Application.DoEvents()

            userNames(ndx2 - ndx) = ws.Cells(ndx2, 2).Value       ' Full Name - Last.First
            emails(ndx2 - ndx) = ws.Cells(ndx2, 3).Value          ' Email
            userGroups(ndx2 - ndx) = ws.Cells(ndx2, 6).Value      ' ALM Project Access Groups

            TaskStatus.Value = 100 * (ndx2 / nrows)
            Application.DoEvents()

        Next

        ' Close the spreadsheet...

        ExcelObj.ActiveWorkbook.Close()
        ExcelObj.Quit()

        ' Loop over the data and add the items back in...
        RunStatus.Text = "Processing users..."
        Application.DoEvents()

        ' Loop over the rows and check for current access...

        For ndx2 = 0 To nrows - ndx

            ' Verify the ID and provided name and return the specific match from Outlook...

            xID = CheckALMUser(userIDs(ndx2), userNames(ndx2))              ' Set working User ID

            If xID = "" Then

                ' Something seriously wrong with this ID...skip it...

                sumreport = sumreport & "--> Error adding user '" & userIDs(ndx2) & "' [" & userNames(ndx2) & "] to ALM" & ControlChars.CrLf

            Else

                RunStatus.Text = "Processing " & xID & "..."
                Application.DoEvents()

                uValue2 = newUserName              ' Full Name - Last.First
                uValue3 = newUserEmail             ' Email
                uValue4 = ""                       ' Phone Number
                uValue5 = ""                       ' Description
                uValue6 = userGroups(ndx2)         ' ALM Project Access Group
                uValue7 = newUserAuth              ' Domain Auth (bbt-user\userID)

                ' Start off believing it isn't in...

                alreadyIn = False

                Try

                    saReply = SAClientSource.GetUser(xID)
                    alreadyIn = True

                    ' Update the existing user information to the validate values...

                    saReply = SAClientSource.SetUserProperty(xID, 3, uValue2)
                    saReply = SAClientSource.SetUserProperty(xID, 4, uValue3)

                Catch

                    ' This user isn't in at all...create it...

                    Try
                        ' UserName, FullName, Email, Phone, Description, password, domainAuth

                        saReply = SAClientSource.CreateUserEx(xID, uValue2, uValue3, uValue4, uValue5, "", uValue7)
                        sumreport = sumreport & xID & ": added to ALM..." & ControlChars.CrLf

                    Catch ex As Exception

                        saReply = Nothing
                        ' MsgBox("Error adding user '" & xID & "' to project: " & ex.Message)
                        RunStatus.Text = "Error adding user '" & xID & "' to project: " & ex.Message
                        sumreport = sumreport & "--> Error adding user '" & xID & "' to ALM: " & ex.Message & ControlChars.CrLf

                    End Try

                End Try

                Try

                    ' Get the specific user ID key for this new ID...

                    sqlString = "select user_id from td.users where USER_NAME = '" & xID & "'"

                    sqlCmd = sqlConn.CreateCommand
                    sqlCmd.CommandText = sqlString

                    'Open the SQL connection...
                    sqlConn.Open()
                    sqlReader = sqlCmd.ExecuteReader()
                    sqlReader.Read()
                    sqlresults = sqlReader.GetInt32(0)
                    sqlReader.Close()
                    sqlConn.Close()

                    undx = sqlresults

                    ' Now use this to update the related LDAP...

                    sqlString2 = "update td.users_auth_data set uad_value = " & serverNum & " where uad_user_id = " & undx & " and UAD_KEY = 'LDAP_SERVER_ID'"

                    Try

                        sqlCmd.CommandText = sqlString2

                        'Open the SQL connection...
                        sqlConn.Open()
                        sqlReader = sqlCmd.ExecuteReader()
                        sqlReader.Close()
                        sqlConn.Close()

                    Catch ex2 As Exception

                        sumreport = sumreport & "--> Error setting user '" & xID & "' LDAP server info: " & ex2.Message & ControlChars.CrLf

                    End Try

                    ' ...and update the internal tables...
                    userIDs(ndx2) = xID
                    userNames(ndx2) = newUserName
                    emails(ndx2) = newUserEmail

                Catch ex As Exception

                    sumreport = sumreport & "--> Error setting user '" & xID & "' LDAP server info: " & ex.Message & ControlChars.CrLf

                End Try

                If addGroups.Checked Then

                    If uValue6 <> "" Then

                        RunStatus.Text = "Processing user '" & xID & "..."
                        Application.DoEvents()

                        Try

                            ' ...Add the user to specific project...
                            SAClientSource.AddUsersToProject(tDomain, tProject, xID)
                            sumreport = sumreport & xID & ": added to project" & ControlChars.CrLf

                        Catch ex As Exception

                            sumreport = sumreport & "--> Error adding user '" & xID & "' to project: " & ex.Message & ControlChars.CrLf

                        End Try

                        If alreadyIn Then

                            ' Get the current group for this user...
                            tdconCustom = tdconSource.Customization
                            tempGroups = GetGroupMembership(xID)

                            If tempGroups = uValue6 Then

                                ' Group membership is already correct...skip this part...
                            Else

                                If tempGroups <> "" Then

                                    If tempGroups.Contains(",") Then
                                        tempArray = Split(tempGroups, ",")
                                        ndx3 = tempArray.Length - 1
                                    Else
                                        ndx3 = 0
                                        tempGroups = tempGroups & ",Nothing"
                                        tempArray = Split(tempGroups, ",")
                                    End If


                                    Try

                                        tdconCustom.Load()

                                        For ndx4 = 0 To ndx3

                                            tempName = tempArray(ndx4).Trim()
                                            tdconCustomGroup = tdconCustomGroups.Group(tempName)
                                            tdconCustomGroup.RemoveUser(xID)

                                        Next

                                        tdconCustom.Commit()

                                    Catch ex As Exception

                                        sumreport = sumreport & "--> Error removing user '" & xID & "' from group: " & tempName & " - " & ex.Message & ControlChars.CrLf

                                    End Try

                                End If

                                Try
                                    ' ...now try adding to the requested group...

                                    tempName = uValue6.Trim()

                                    Try

                                        SAClientSource.AddUsersToGroup(tDomain, tProject, tempName, xID)
                                        sumreport = sumreport & "Added '" & xID & "' to group '" & tempName & "..." & ControlChars.CrLf

                                    Catch ex As Exception

                                        sumreport = sumreport & "--> Error adding user '" & xID & "' to group '" & tempName & "': " & ex.Message & ControlChars.CrLf

                                    End Try

                                Catch ex2 As Exception

                                    '...or the default QATest group if that didn't work...
                                    SAClientSource.AddUsersToGroup(tDomain, tProject, "04_Tester", xID)
                                    sumreport = sumreport & "Added '" & xID & "' to group '04_Tester'..." & ControlChars.CrLf

                                End Try

                            End If

                        End If

                        Try

                            ' ...and now save this user's changes entirely...
                            tdconCustom.Commit()

                        Catch ex As Exception

                        End Try

                    End If

                End If

            End If

            TaskStatus.Value = 100 * (ndx2 / nrows)
            Application.DoEvents()

        Next

        ' Now go back and remove "Viewer", if present...

        RunStatus.Text = "Removing extra Viewer groups..."
        Application.DoEvents()

        For ndx2 = 0 To nrows - ndx

            xID = userIDs(ndx2)

            Try

                ' Remove Viewer if it got in there...
                tdconCustom.Load()
                tdconCustomGroup = tdconCustomGroups.Group("Viewer")
                tdconCustomGroup.RemoveUser(xID)
                tdconCustom.Commit()

            Catch ex As Exception

            End Try

            TaskStatus.Value = 100 * (ndx2 / nrows)
            Application.DoEvents()

        Next

        ' Log out of Site Admin...
        SAClientSource.Logout()

        ' ...and log out of standard connection...
        If tdconSource.Connected = True Then
            tdconSource.ReleaseConnection()
        End If

        ' Write out the summary
        sumreport = sumreport & ControlChars.CrLf & "Import completed!"

        FileOpen(2, filePath, OpenMode.Output)
        PrintLine(2, sumreport)
        FileClose(2)

        sumreport = ""

        RunStatus.Text = "Processing complete!"
        Application.DoEvents()

    End Sub

    Function CheckALMUser(userID, userName)

        Dim ndx, ndx2 As Integer

        truistID = ""

        If userName.Contains("sv") Or userName.Contains("SV") Then

            ' hBBT ADS process IDs - do not allow...
            truistID = ""
            Return truistID

        End If

        If userName = "" Or userName = "null" Then

            ' Return a null name for processing...
            truistID = ""
            Return truistID

        End If

        ndx = 0
        workingString = userName

        ndx = workingString.IndexOf(".")
        ndx2 = 1

        If ndx <= 0 Then

            ndx = workingString.IndexOf(" ")

            ' Flip the name - most likely is "First Last"...
            nameParts = workingString.Substring(ndx + 1) & " " & workingString.Substring(0, ndx)
            workingString = nameParts
            ndx = workingString.IndexOf(" ")
            ndx2 = 1

        End If

        ' Check to see if we have no delimiter...

        If ndx <= 0 Then

            ' Nothing we can work with here...return null...
            Return ""

        End If

        ' We have something...reformat accordingly...

        If ndx > 0 Then

            ' Reformat the name to ALM lookup...
            nameParts = workingString.Substring(0, ndx) & "." & workingString.Substring(ndx + ndx2)
            userName = nameParts

        End If

        ' If not, then let's try resolving it through Outlook...flip the name order...

        workingString = userName
        ndx = workingString.IndexOf(".")

        If ndx <= 0 Then

            ' User's name is one word!  Stop processing...
            Return ""

        End If

        nameParts = workingString.Substring(0, ndx) & ", " & workingString.Substring(ndx + 1)
        userName = nameParts

        Try

            ' Set up a temporary email item...
            oMailItem = ApprEmail.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem)
            oMailItem.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatHTML
            oMailItem.To = userName

            ' Now try to resolve it to get the "alias", which is the Truist ID...
            ' oMailItem = ApprEmail.ActiveInspector.CurrentItem
            almUSer = oMailItem.Recipients.Item(1)
            ' almUSer = oMailItem.Recipients.Add(almUSer.AddressEntry)

            ' Found in Outlook...get the Truist ID...
            almUSer.Resolve()
            outlookAlias = almUSer.AddressEntry.GetExchangeUser.Alias
            outlookName = almUSer.AddressEntry.GetExchangeUser.Name
            outlookEmail = almUSer.AddressEntry.GetExchangeUser.PrimarySmtpAddress
            almUSer.Delete()
            oMailItem.Delete()

            newUserID = outlookAlias
            newUserName = outlookName
            newUserName = newUserName.Replace(", ", ".")
            newUserEmail = outlookEmail
            newUserAuth = "BBT-USER\" & newUserID

            truistID = outlookAlias

        Catch ex As Exception
            sumreport = sumreport & "--> Error adding user '" & userName & "' to MOE project: " & ex.Message & ControlChars.CrLf

        End Try

        Return truistID

    End Function
    Function GetGroupMembership(ByVal strUserID)
        On Error GoTo checkerror

        Dim users As TDAPIOLELib.CustomizationUsers
        Dim ugroups As TDAPIOLELib.CustomizationUsersGroups
        Dim ugroup As TDAPIOLELib.CustomizationUsersGroup
        Dim lst As IList
        Dim userlist As IList
        Dim user As TDAPIOLELib.CustomizationUser
        Dim i As Long
        Dim Grouplst
        Dim groupname

        GetGroupMembership = ""

        users = tdconCustom.Users
        user = users.User(LCase(strUserID))
        ugroups = tdconCustom.UsersGroups
        Grouplst = ugroups.Groups

        'loop through each group and see if the user is a member of it
        For i = 1 To Grouplst.Count
            'set the group name
            groupname = Grouplst.Item(i).Name

            'check user's existence in this group
            If user.InGroup(groupname) Then
                If GetGroupMembership = "" Then
                    GetGroupMembership = groupname
                Else
                    GetGroupMembership = GetGroupMembership & ", " & groupname
                End If
            End If
        Next i

        userlist = Nothing
        users = Nothing
        ugroups = Nothing
        ugroup = Nothing
        lst = Nothing

        Exit Function

checkerror:

        userlist = Nothing
        users = Nothing
        ugroups = Nothing
        ugroup = Nothing
        lst = Nothing

        GetGroupMembership = ""

    End Function

    Private Sub btnPickFile_Click(sender As Object, e As EventArgs) Handles btnPickFile.Click
        Dim fdlg As OpenFileDialog = New OpenFileDialog()

        strFileName = ""

        fdlg.Title = "Select Source Excel File:"
        fdlg.InitialDirectory = "c:\"
        fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fdlg.FilterIndex = 2
        fdlg.RestoreDirectory = True
        If fdlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtPath.Text = fdlg.FileName
            strFileName = fdlg.FileName
        End If

    End Sub

    Private Sub cmdServer_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdServer.Click
        Dim dom As Integer
        Dim tdurl_arr As Object

        cmbDomain.Items.Clear()

        On Error GoTo CheckError

        If txtUser.Text = "" Or txtPassword.Text = "" Then
            MsgBox("UserID and Password are required")
            Exit Sub
        End If

        tdconSource.InitConnectionEx(cmbURL.Text)

        If tdconSource.Connected = False Then
            MsgBox("Can not connect to ALM Server")
            Exit Sub
        End If

        tdconSource.Login(txtUser.Text, txtPassword.Text)

        If tdconSource.LoggedIn = False Then
            MsgBox("Unable to login.  Check User and Password information then try again.")
            Exit Sub
        End If

        For dom = 1 To tdconSource.VisibleDomains.Count
            If tdconSource.VisibleProjects(tdconSource.VisibleDomains.Item(dom)).Count > 0 Then
                cmbDomain.Items.Add((tdconSource.VisibleDomains.Item(dom)))
            End If
        Next

        '  Enable Domain selection process
        cmbDomain.Enabled = True
        cmbDomain.SelectedIndex = 0

        ' Disable Server texbox and connection button
        cmbURL.Enabled = False
        cmdServer.Enabled = False
        txtUser.Enabled = False
        txtPassword.Enabled = False
        cmdDisconnect.Enabled = True

        RunStatus.Text = "Log in to Quality Center..."
        Application.DoEvents()

        Exit Sub
CheckError:
        MsgBox("cmdServer_Click Error #" & (Err.Number - vbObjectError) & Chr(13) & Err.Description, MsgBoxStyle.Critical)
    End Sub

    Private Sub cmbDomain_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmbDomain.SelectedIndexChanged
        Dim proj As Integer

        cmbProject.Items.Clear()

        For proj = 1 To tdconSource.VisibleProjects(cmbDomain.Text).Count
            cmbProject.Items.Add((tdconSource.VisibleProjects(cmbDomain.Text).Item(proj)))
        Next

        cmbProject.SelectedIndex = 0

        ' Enable Project and Login processes
        cmbProject.Enabled = True
        cmdLogin.Enabled = True

    End Sub

    Private Sub cmdLogin_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLogin.Click

        ' connect selected project
        tdconSource.Connect(cmbDomain.Text, cmbProject.Text)

        ' Disable Project/login objects
        cmbDomain.Enabled = False
        cmbProject.Enabled = False
        txtUser.Enabled = False
        txtPassword.Enabled = False
        cmdLogin.Enabled = False

        ' Load the list of lists...
        tdconCustom = tdconSource.Customization
        tdconCustom.Load()
        tdconCustomLists = tdconCustom.Lists

        ' Ready to proceed...
        RunStatus.Text = "Select a file of users to import..."
        Application.DoEvents()

    End Sub

    Private Sub cmdLogout_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLogout.Click

        If tdconSource.Connected = True Then
            If tdconSource.ProjectConnected = True Then
                tdconSource.DisconnectProject()
            End If
        End If

        ' Enable Project/login objects
        cmbDomain.Enabled = True
        cmbProject.Enabled = True
        cmdLogin.Enabled = True

        ' Disable logout
        cmdLogout.Enabled = False
        cmbDomain.Focus()

    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click


        If tdconSource.Connected = True Then
            If tdconSource.ProjectConnected = True Then
                tdconSource.DisconnectProject()
            End If
        End If

        Me.Close()

    End Sub

End Class
