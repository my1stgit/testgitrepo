﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QCSMBulkAddUsers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.frameConnection = New System.Windows.Forms.GroupBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdDisconnect = New System.Windows.Forms.Button()
        Me.cmbURL = New System.Windows.Forms.ComboBox()
        Me.cmdServer = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.lblUrl = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.frameDomain = New System.Windows.Forms.GroupBox()
        Me.cmdLogout = New System.Windows.Forms.Button()
        Me.cmdLogin = New System.Windows.Forms.Button()
        Me.cmbProject = New System.Windows.Forms.ComboBox()
        Me.cmbDomain = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnPickFile = New System.Windows.Forms.Button()
        Me.txtPath = New System.Windows.Forms.TextBox()
        Me.lblFile = New System.Windows.Forms.Label()
        Me.statusBox = New System.Windows.Forms.GroupBox()
        Me.RunStatus = New System.Windows.Forms.RichTextBox()
        Me.TaskStatus = New System.Windows.Forms.ProgressBar()
        Me.importUsers = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.addGroups = New System.Windows.Forms.CheckBox()
        Me.hasHeaders = New System.Windows.Forms.CheckBox()
        Me.frameConnection.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.frameDomain.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.statusBox.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'frameConnection
        '
        Me.frameConnection.BackColor = System.Drawing.SystemColors.Control
        Me.frameConnection.Controls.Add(Me.Frame1)
        Me.frameConnection.Controls.Add(Me.frameDomain)
        Me.frameConnection.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameConnection.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameConnection.Location = New System.Drawing.Point(12, 12)
        Me.frameConnection.Name = "frameConnection"
        Me.frameConnection.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameConnection.Size = New System.Drawing.Size(393, 313)
        Me.frameConnection.TabIndex = 67
        Me.frameConnection.TabStop = False
        Me.frameConnection.Text = "Quality Center Connection "
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdDisconnect)
        Me.Frame1.Controls.Add(Me.cmbURL)
        Me.Frame1.Controls.Add(Me.cmdServer)
        Me.Frame1.Controls.Add(Me.txtPassword)
        Me.Frame1.Controls.Add(Me.txtUser)
        Me.Frame1.Controls.Add(Me.lblUrl)
        Me.Frame1.Controls.Add(Me.lblPassword)
        Me.Frame1.Controls.Add(Me.lblUser)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(8, 24)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(368, 121)
        Me.Frame1.TabIndex = 14
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Quality Center Authentication"
        '
        'cmdDisconnect
        '
        Me.cmdDisconnect.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDisconnect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDisconnect.Enabled = False
        Me.cmdDisconnect.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDisconnect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDisconnect.Location = New System.Drawing.Point(256, 88)
        Me.cmdDisconnect.Name = "cmdDisconnect"
        Me.cmdDisconnect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDisconnect.Size = New System.Drawing.Size(97, 25)
        Me.cmdDisconnect.TabIndex = 22
        Me.cmdDisconnect.Text = "&Disconnect"
        Me.cmdDisconnect.UseVisualStyleBackColor = False
        '
        'cmbURL
        '
        Me.cmbURL.BackColor = System.Drawing.SystemColors.Window
        Me.cmbURL.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbURL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.cmbURL.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbURL.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbURL.Items.AddRange(New Object() {"http://qc.suntrust.com/qcbin/", "http://qc-qa.suntrust.com/qcbin/", "http://qc-dev.suntrust.com/qcbin/"})
        Me.cmbURL.Location = New System.Drawing.Point(64, 24)
        Me.cmbURL.Name = "cmbURL"
        Me.cmbURL.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbURL.Size = New System.Drawing.Size(225, 21)
        Me.cmbURL.TabIndex = 0
        Me.cmbURL.Text = "http://alm12.suntrust.com/qcbin"
        '
        'cmdServer
        '
        Me.cmdServer.BackColor = System.Drawing.SystemColors.Control
        Me.cmdServer.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdServer.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdServer.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdServer.Location = New System.Drawing.Point(256, 56)
        Me.cmdServer.Name = "cmdServer"
        Me.cmdServer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdServer.Size = New System.Drawing.Size(97, 25)
        Me.cmdServer.TabIndex = 3
        Me.cmdServer.Text = "&Authenticate"
        Me.cmdServer.UseVisualStyleBackColor = False
        '
        'txtPassword
        '
        Me.txtPassword.AcceptsReturn = True
        Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
        Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtPassword.Location = New System.Drawing.Point(64, 88)
        Me.txtPassword.MaxLength = 0
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPassword.Size = New System.Drawing.Size(177, 20)
        Me.txtPassword.TabIndex = 2
        '
        'txtUser
        '
        Me.txtUser.AcceptsReturn = True
        Me.txtUser.BackColor = System.Drawing.SystemColors.Window
        Me.txtUser.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUser.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUser.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUser.Location = New System.Drawing.Point(64, 56)
        Me.txtUser.MaxLength = 0
        Me.txtUser.Name = "txtUser"
        Me.txtUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUser.Size = New System.Drawing.Size(177, 20)
        Me.txtUser.TabIndex = 1
        '
        'lblUrl
        '
        Me.lblUrl.BackColor = System.Drawing.SystemColors.Control
        Me.lblUrl.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUrl.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUrl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUrl.Location = New System.Drawing.Point(6, 27)
        Me.lblUrl.Name = "lblUrl"
        Me.lblUrl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUrl.Size = New System.Drawing.Size(33, 17)
        Me.lblUrl.TabIndex = 21
        Me.lblUrl.Text = "URL: "
        '
        'lblPassword
        '
        Me.lblPassword.BackColor = System.Drawing.SystemColors.Control
        Me.lblPassword.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPassword.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassword.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPassword.Location = New System.Drawing.Point(5, 93)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPassword.Size = New System.Drawing.Size(61, 17)
        Me.lblPassword.TabIndex = 16
        Me.lblPassword.Text = "Password:"
        '
        'lblUser
        '
        Me.lblUser.BackColor = System.Drawing.SystemColors.Control
        Me.lblUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUser.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUser.Location = New System.Drawing.Point(6, 59)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUser.Size = New System.Drawing.Size(33, 17)
        Me.lblUser.TabIndex = 15
        Me.lblUser.Text = "User:"
        '
        'frameDomain
        '
        Me.frameDomain.BackColor = System.Drawing.SystemColors.Control
        Me.frameDomain.Controls.Add(Me.cmdLogout)
        Me.frameDomain.Controls.Add(Me.cmdLogin)
        Me.frameDomain.Controls.Add(Me.cmbProject)
        Me.frameDomain.Controls.Add(Me.cmbDomain)
        Me.frameDomain.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameDomain.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameDomain.Location = New System.Drawing.Point(8, 152)
        Me.frameDomain.Name = "frameDomain"
        Me.frameDomain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameDomain.Size = New System.Drawing.Size(368, 153)
        Me.frameDomain.TabIndex = 13
        Me.frameDomain.TabStop = False
        Me.frameDomain.Text = "Select Domain and Project "
        '
        'cmdLogout
        '
        Me.cmdLogout.BackColor = System.Drawing.SystemColors.Control
        Me.cmdLogout.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdLogout.Enabled = False
        Me.cmdLogout.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLogout.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdLogout.Location = New System.Drawing.Point(112, 104)
        Me.cmdLogout.Name = "cmdLogout"
        Me.cmdLogout.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLogout.Size = New System.Drawing.Size(81, 25)
        Me.cmdLogout.TabIndex = 20
        Me.cmdLogout.Text = "Log&out"
        Me.cmdLogout.UseVisualStyleBackColor = False
        '
        'cmdLogin
        '
        Me.cmdLogin.BackColor = System.Drawing.SystemColors.Control
        Me.cmdLogin.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdLogin.Enabled = False
        Me.cmdLogin.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLogin.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdLogin.Location = New System.Drawing.Point(8, 104)
        Me.cmdLogin.Name = "cmdLogin"
        Me.cmdLogin.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLogin.Size = New System.Drawing.Size(89, 25)
        Me.cmdLogin.TabIndex = 19
        Me.cmdLogin.Text = "&Login"
        Me.cmdLogin.UseVisualStyleBackColor = False
        '
        'cmbProject
        '
        Me.cmbProject.BackColor = System.Drawing.SystemColors.Window
        Me.cmbProject.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject.Enabled = False
        Me.cmbProject.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProject.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject.Location = New System.Drawing.Point(8, 72)
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbProject.Size = New System.Drawing.Size(241, 22)
        Me.cmbProject.TabIndex = 5
        Me.cmbProject.Text = "Select Project"
        '
        'cmbDomain
        '
        Me.cmbDomain.BackColor = System.Drawing.SystemColors.Window
        Me.cmbDomain.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbDomain.Enabled = False
        Me.cmbDomain.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbDomain.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbDomain.Location = New System.Drawing.Point(8, 32)
        Me.cmbDomain.Name = "cmbDomain"
        Me.cmbDomain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbDomain.Size = New System.Drawing.Size(241, 22)
        Me.cmbDomain.TabIndex = 4
        Me.cmbDomain.Text = "Select Domain"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnPickFile)
        Me.GroupBox1.Controls.Add(Me.txtPath)
        Me.GroupBox1.Controls.Add(Me.lblFile)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 332)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(393, 83)
        Me.GroupBox1.TabIndex = 68
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Bulk User File"
        '
        'btnPickFile
        '
        Me.btnPickFile.BackColor = System.Drawing.SystemColors.Control
        Me.btnPickFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnPickFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPickFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPickFile.Location = New System.Drawing.Point(296, 44)
        Me.btnPickFile.Name = "btnPickFile"
        Me.btnPickFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnPickFile.Size = New System.Drawing.Size(65, 22)
        Me.btnPickFile.TabIndex = 28
        Me.btnPickFile.Text = "&Browse"
        Me.btnPickFile.UseVisualStyleBackColor = False
        '
        'txtPath
        '
        Me.txtPath.AcceptsReturn = True
        Me.txtPath.BackColor = System.Drawing.SystemColors.Window
        Me.txtPath.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPath.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPath.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPath.Location = New System.Drawing.Point(17, 46)
        Me.txtPath.MaxLength = 0
        Me.txtPath.Name = "txtPath"
        Me.txtPath.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPath.Size = New System.Drawing.Size(273, 20)
        Me.txtPath.TabIndex = 27
        '
        'lblFile
        '
        Me.lblFile.BackColor = System.Drawing.SystemColors.Control
        Me.lblFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFile.Location = New System.Drawing.Point(14, 24)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFile.Size = New System.Drawing.Size(149, 18)
        Me.lblFile.TabIndex = 29
        Me.lblFile.Text = "Select file to be processed:"
        '
        'statusBox
        '
        Me.statusBox.Controls.Add(Me.RunStatus)
        Me.statusBox.Controls.Add(Me.TaskStatus)
        Me.statusBox.Location = New System.Drawing.Point(12, 497)
        Me.statusBox.Name = "statusBox"
        Me.statusBox.Size = New System.Drawing.Size(393, 107)
        Me.statusBox.TabIndex = 70
        Me.statusBox.TabStop = False
        Me.statusBox.Text = "Status"
        '
        'RunStatus
        '
        Me.RunStatus.BackColor = System.Drawing.SystemColors.Control
        Me.RunStatus.Location = New System.Drawing.Point(15, 18)
        Me.RunStatus.Name = "RunStatus"
        Me.RunStatus.Size = New System.Drawing.Size(361, 56)
        Me.RunStatus.TabIndex = 8
        Me.RunStatus.Text = "Connect to Quality Center..."
        '
        'TaskStatus
        '
        Me.TaskStatus.Location = New System.Drawing.Point(15, 79)
        Me.TaskStatus.Name = "TaskStatus"
        Me.TaskStatus.Size = New System.Drawing.Size(361, 20)
        Me.TaskStatus.TabIndex = 7
        '
        'importUsers
        '
        Me.importUsers.BackColor = System.Drawing.SystemColors.Control
        Me.importUsers.Cursor = System.Windows.Forms.Cursors.Default
        Me.importUsers.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.importUsers.ForeColor = System.Drawing.SystemColors.ControlText
        Me.importUsers.Location = New System.Drawing.Point(12, 611)
        Me.importUsers.Name = "importUsers"
        Me.importUsers.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.importUsers.Size = New System.Drawing.Size(121, 33)
        Me.importUsers.TabIndex = 74
        Me.importUsers.Text = "Import Users"
        Me.importUsers.UseVisualStyleBackColor = False
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(284, 611)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(121, 33)
        Me.cmdExit.TabIndex = 75
        Me.cmdExit.Text = "Exit"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.addGroups)
        Me.GroupBox2.Controls.Add(Me.hasHeaders)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 422)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(393, 69)
        Me.GroupBox2.TabIndex = 76
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Import Options"
        '
        'addGroups
        '
        Me.addGroups.AutoSize = True
        Me.addGroups.Location = New System.Drawing.Point(176, 30)
        Me.addGroups.Name = "addGroups"
        Me.addGroups.Size = New System.Drawing.Size(130, 17)
        Me.addGroups.TabIndex = 1
        Me.addGroups.Text = "Add to Project Groups"
        Me.addGroups.UseVisualStyleBackColor = True
        '
        'hasHeaders
        '
        Me.hasHeaders.AutoSize = True
        Me.hasHeaders.Location = New System.Drawing.Point(17, 30)
        Me.hasHeaders.Name = "hasHeaders"
        Me.hasHeaders.Size = New System.Drawing.Size(110, 17)
        Me.hasHeaders.TabIndex = 0
        Me.hasHeaders.Text = "Data has headers"
        Me.hasHeaders.UseVisualStyleBackColor = True
        '
        'QCSMBulkAddUsers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 657)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.importUsers)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.statusBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.frameConnection)
        Me.Name = "QCSMBulkAddUsers"
        Me.Text = "ALM - Site Admin - Add Bulk Users - v 1.4"
        Me.frameConnection.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.frameDomain.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.statusBox.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents frameConnection As GroupBox
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdDisconnect As Button
    Public WithEvents cmbURL As ComboBox
    Public WithEvents cmdServer As Button
    Public WithEvents txtPassword As TextBox
    Public WithEvents txtUser As TextBox
    Public WithEvents lblUrl As Label
    Public WithEvents lblPassword As Label
    Public WithEvents lblUser As Label
    Public WithEvents frameDomain As GroupBox
    Public WithEvents cmdLogout As Button
    Public WithEvents cmdLogin As Button
    Public WithEvents cmbProject As ComboBox
    Public WithEvents cmbDomain As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Public WithEvents btnPickFile As Button
    Public WithEvents txtPath As TextBox
    Public WithEvents lblFile As Label
    Friend WithEvents statusBox As GroupBox
    Friend WithEvents RunStatus As RichTextBox
    Friend WithEvents TaskStatus As ProgressBar
    Public WithEvents importUsers As Button
    Public WithEvents cmdExit As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents addGroups As CheckBox
    Friend WithEvents hasHeaders As CheckBox
End Class
