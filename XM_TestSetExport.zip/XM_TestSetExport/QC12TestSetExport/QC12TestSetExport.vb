﻿Public Class QC12TestSetExport

    ' QC Client Connections and objects
    Dim tdconTarget As New TDAPIOLELib.TDConnection
    Dim tdconCommand, tdconCommand2, tdconCommand3, tdconCommand4 As TDAPIOLELib.Command
    Dim tdconCustom As TDAPIOLELib.Customization
    Dim tdconCustomLists As TDAPIOLELib.CustomizationLists
    Dim tdconCustomList As TDAPIOLELib.CustomizationList
    Dim tdconRecSet, tdconRecSet2, tdconRecSet3, tdconRecSet4 As TDAPIOLELib.Recordset

    Dim tdconPlanTree As TDAPIOLELib.TreeManager
    Dim tdconTestTree As TDAPIOLELib.TestSetTreeManager

    Dim tdconPlanFolderTree, tempPlanFolderTree As TDAPIOLELib.TestFolderFactory
    Dim tdconLabFolderTree, tempLabFolderTree As TDAPIOLELib.TestLabFolderFactory

    Dim tdconTestFolder, tdconTestFolderChild As TDAPIOLELib.TestSetFolder
    Dim tdconPlanFolder As TDAPIOLELib.SubjectNode
    Dim tdconTestFactory As TDAPIOLELib.TestFactory
    Dim tdconTestFilter, tdconTestSetFilter As TDAPIOLELib.TDFilter

    Dim tdconTestSet As TDAPIOLELib.TestSet
    Dim tdconTestSetFactory As TDAPIOLELib.TestSetFactory
    Dim tdconTestSetList As TDAPIOLELib.FactoryList
    Dim tdconTSTestFactory As TDAPIOLELib.TSTestFactory
    Dim tempTest, calledTest As TDAPIOLELib.Test
    Dim tempTSTest As TDAPIOLELib.TSTest
    Dim tempTestFolder As TDAPIOLELib.TestFolder
    Dim tempTestSet As TDAPIOLELib.TestSet
    Dim tempTestSetFolder As TDAPIOLELib.TestLabFolder
    Dim testTree, testTSTree, testSetTree, designTree, calledDesignTree As TDAPIOLELib.List
    Dim aField As TDAPIOLELib.TDField

    Dim testDesignFactory, calledTestDesignFactory As TDAPIOLELib.DesignStepFactory
    Dim testDesignStep, calledTestDesignStep As TDAPIOLELib.DesignStep

    ' Excel-related variables
    Dim ExcelObj As Object
    Dim ws As Microsoft.Office.Interop.Excel.Worksheet
    Dim wb As Microsoft.Office.Interop.Excel.Workbook
    Dim tCell As Microsoft.Office.Interop.Excel.Range

    ' Local variables

    Dim planFolderList As New List(Of String)
    Dim labFolderList As New List(Of String)

    Dim planTestList As New List(Of String)
    Dim labTestList As New List(Of String)

    Dim batchStatus, reportOnly As Boolean
    Dim sDomain, sProject, curFolder, curTestSet, curTest As String

    Dim curShortNames(2000) As String
    Dim curFolderIDs(2000) As Integer
    Dim curChildCount(2000) As Integer

    Dim fdlg As New SaveFileDialog()
    Dim FilePath As String

    Dim ndx1, ndx2, ndx3, ndx4 As Integer
    Dim sText, reportType, excelVersion, rName As String
    Dim objData As DataObject

    Private Sub QC12TestSetExport_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        batchStatus = False

        QCLogin.Visible = False

    End Sub

    Private Sub doPlan_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles doPlan.CheckedChanged

        RunStatus.Text = "Creating Test Plan tree..."
        Application.DoEvents()

        treeView.Nodes.Clear()

        Call GrowPlanTree()

        RunStatus.Text = "Tree completed...getting data field names..."
        Application.DoEvents()

        RunStatus.Text = "Test Plan set-up completed"
        Application.DoEvents()

    End Sub

    Private Sub doLab_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles doLab.CheckedChanged

        RunStatus.Text = "Creating Test Lab tree..."
        Application.DoEvents()

        treeView.Nodes.Clear()

        Call GrowLabTree()

        RunStatus.Text = "Tree completed...getting data field names..."
        Application.DoEvents()

        RunStatus.Text = "Test Lab set-up completed"
        Application.DoEvents()

    End Sub

    Private Sub treeView_ExpandOrCollapse(ByVal sender As Object, ByVal e As TreeViewEventArgs) Handles treeView.AfterCollapse, treeView.AfterExpand

        If doPlan.Checked Then Call changePlanTree(e)
        If doLab.Checked Then Call changeLabTree(e)

    End Sub

    Private Sub exportTestSet_Click(sender As Object, e As EventArgs) Handles exportTestSet.Click

        Dim tagString As String

        Try
            tagString = treeView.SelectedNode.Tag.ToString()

        Catch ex As Exception

            MsgBox("Please select a folder from the Test Lab tree view")

            RunStatus.Text = "Please select a folder from the Test Lab tree view..."
            Application.DoEvents()

            Exit Sub

        End Try

        If doPlan.Checked Then
            reportType = "Test Plan"
        Else
            reportType = "Test Lab"
        End If

        fdlg.Title = "ALM Test/Test Set Export - Save Excel Report File:"
        fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fdlg.FilterIndex = 2
        fdlg.RestoreDirectory = True
        fdlg.FileName = "ALM-" & reportType & "-Export " & Now.ToString("yyyyMMdd-HHmmss") & ".xlsx"
        If fdlg.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            FilePath = fdlg.FileName
        Else
            RunStatus.Text = "Report cancelled!"
            Application.DoEvents()
            Exit Sub
        End If

        'Setup Excel Object for reporting

        ExcelObj = CreateObject("Excel.Application")
        excelVersion = ExcelObj.Version

        ExcelObj.Workbooks.Add()
        ExcelObj.Worksheets.Add()

        If excelVersion = "16.0" Then
            ' Excel 2016 only logic goes here...
        End If

        ExcelObj.DisplayAlerts = True

        ' Main execution starts here...

        ws = ExcelObj.Sheets.Item(1)
        ndx2 = 1

        If doPlan.Checked Then
            Call getPlanList()
        Else
            Call getLabList()
        End If

        ' Final report formatting...
        ws.Columns("A").ColumnWidth = 15
        ws.Columns("B").ColumnWidth = 30
        ws.Columns("C").ColumnWidth = 50
        ws.Columns("D").ColumnWidth = 30
        ws.Columns("E").ColumnWidth = 50
        ws.Columns("F").ColumnWidth = 50

        ws.Columns("E").WrapText = True
        ws.Columns("F").WrapText = True

        ' Close up the spreadsheet and save it...

        ExcelObj.ActiveWorkbook.SaveAs(FilePath)
        ExcelObj.ActiveWorkbook.Close()
        ExcelObj.Quit()

        RunStatus.Text = "ALM Export Report Completed!"
        Application.DoEvents()

    End Sub
    Private Sub getPlanList()

        Dim curTopFolderID As String
        Dim xndx As Integer

        ' Given the folder ID for the selected Test Plan folder, fetch the list of all enclosed test sets...

        ' Set the TestFolderFactory to the selected ID...

        tdconPlanFolderTree = tdconTarget.TestFolderFactory
        Try
            tempTestFolder = tdconPlanFolderTree.Item(treeView.SelectedNode.Tag.ToString())
            curTopFolderID = treeView.SelectedNode.Tag.ToString()

        Catch ex As Exception
            MsgBox("Please select a folder from the Test Plan tree view")

            RunStatus.Text = "Please select a folder from the Test Plan tree view..."
            Application.DoEvents()

            Exit Sub
        End Try

        ' Recursively loop downward for contained folders and make a list of the folder IDs...

        RunStatus.Text = "Adding Test Plan folders contained in your selection..."
        Application.DoEvents()

        planFolderList.Add(curTopFolderID)
        Call addPlanFolders(curTopFolderID)

        ' Work through the resulting folder ID list and create the list of enclosed test set IDs...

        RunStatus.Text = "Adding Tests contained in those folders..."
        Application.DoEvents()

        Call addPlanTests()

        ' Call the walk for Test Plan based on the resulting list...

        RunStatus.Text = "Walking the selected tests..."
        Application.DoEvents()

        For xndx = 0 To planTestList.Count - 1

            Call walkTestPlan(planTestList(xndx))

            TaskStatus2.Value = 100 * ((xndx + 1) / planTestList.Count)
            Application.DoEvents()

        Next

    End Sub
    Private Sub getLabList()

        Dim curTopFolderID As String
        Dim xndx As Integer

        ' Given the folder ID for the selected Test Lab folder, fetch the list of all enclosed test sets...

        ' Set the TestLabFolderFactory to the selected ID...

        tdconLabFolderTree = tdconTarget.TestLabFolderFactory
        Try
            tempTestSetFolder = tdconLabFolderTree.Item(treeView.SelectedNode.Tag.ToString())
            curTopFolderID = treeView.SelectedNode.Tag.ToString()

        Catch ex As Exception
            MsgBox("Please select a folder from the Test Lab tree view")

            RunStatus.Text = "Please select a folder from the Test Lab tree view..."
            Application.DoEvents()

            Exit Sub
        End Try

        ' Recursively loop downward for contained folders and make a list of the folder IDs...

        RunStatus.Text = "Adding Test Lab folders contained in your selection..."
        Application.DoEvents()

        labFolderList.Add(curTopFolderID)
        Call addLabFolders(curTopFolderID)

        ' Work through the resulting folder ID list and create the list of enclosed test set IDs...

        RunStatus.Text = "Adding Test Sets contained in those folders..."
        Application.DoEvents()

        Call addLabTestSets()

        ' Call the walk for Test Lab based on the resulting list...

        RunStatus.Text = "Walking the selected test sets..."
        Application.DoEvents()

        For xndx = 0 To labTestList.Count - 1

            Call walkTestLab(labTestList(xndx))

            TaskStatus.Value = 100 * ((xndx + 1) / labTestList.Count)
            Application.DoEvents()

        Next

    End Sub

    Private Sub addPlanFolders(curTestFolder)

        Dim tempPlanFolder, tFolder As TDAPIOLELib.TestFolder
        Dim tempPlanFactory As TDAPIOLELib.TestFolderFactory
        Dim testPlanTree As TDAPIOLELib.List

        Dim tFolderID As String

        tempPlanFolder = tdconPlanFolderTree.Item(curTestFolder)
        tempPlanFactory = tempPlanFolder.TestFolderFactory
        testPlanTree = tempPlanFactory.NewList("")

        If testPlanTree.Count = 0 Then Exit Sub

        ' Recursive call to get the test folder IDs at this level...

        For Each tFolder In testPlanTree

            tFolderID = tFolder.ID
            planFolderList.Add(tFolderID)

            ' Make the recursive call to get the children of this folder...
            Call addPlanFolders(tFolderID)

        Next

    End Sub

    Private Sub addPlanTests()

        Dim tempPlanFolder As TDAPIOLELib.TestFolder
        Dim tempTestTree As TDAPIOLELib.TestFactory
        Dim testSetTree As TDAPIOLELib.List
        Dim tSet As TDAPIOLELib.Test

        Dim tSetId As String
        Dim tndx As Integer

        ' Make a list of the test IDs from the list of test folders...

        For tndx = 0 To planFolderList.Count - 1

            tempPlanFolder = tdconPlanFolderTree.Item(planFolderList(tndx))
            tempTestTree = tempPlanFolder.TestFactory
            testSetTree = tempTestTree.NewList("")

            For Each tSet In testSetTree

                tSetId = tSet.ID
                planTestList.Add(tSetId)

            Next

        Next

    End Sub

    Private Sub addLabFolders(curTSFolder)

        Dim tempLabFolder, tFolder As TDAPIOLELib.TestLabFolder
        Dim tempLabFactory As TDAPIOLELib.TestLabFolderFactory
        Dim testLabTree As TDAPIOLELib.List

        Dim tFolderID As String

        tempLabFolder = tdconLabFolderTree.Item(curTSFolder)
        tempLabFactory = tempLabFolder.TestLabFolderFactory
        testLabTree = tempLabFactory.NewList("")

        If testLabTree.Count = 0 Then Exit Sub

        ' Recursive call to get the lab folder IDs at this level...

        For Each tFolder In testLabTree

            tFolderID = tFolder.ID
            labFolderList.Add(tFolderID)

            ' Make the recursive call to get the children of this folder...
            Call addLabFolders(tFolderID)

        Next

    End Sub

    Private Sub addLabTestSets()

        Dim tempLabFolder As TDAPIOLELib.TestLabFolder
        Dim tempTestSetTree As TDAPIOLELib.TestSetFactory
        Dim testSetTree As TDAPIOLELib.List
        Dim tSet As TDAPIOLELib.TestSet

        Dim tSetId As String
        Dim tndx As Integer

        ' Make a list of the test set IDs from the list of test set folders...

        For tndx = 0 To labFolderList.Count - 1

            tempLabFolder = tdconLabFolderTree.Item(labFolderList(tndx))
            tempTestSetTree = tempLabFolder.TestSetFactory
            testSetTree = tempTestSetTree.NewList("")

            For Each tSet In testSetTree

                tSetId = tSet.ID
                labTestList.Add(tSetId)

            Next

        Next

    End Sub
    Private Sub walkTestPlan(curTest)

        Dim calledTestID, curRange As String

        ' Subroutine to walk a single test...

        ' Get the current test...
        tdconTestFactory = tdconTarget.TestFactory

        tempTest = tdconTestFactory.Item(curTest)

        ws.Cells(ndx2, 2) = "Test Name:"
        ws.Cells(ndx2, 2).Font.Bold = True

        ws.Cells(ndx2, 3) = tempTest.Name
        ws.Cells(ndx2, 4) = "Test ID:" & curTest
        ws.Cells(ndx2, 5) = "Test Type: " & tempTest.Type

        ndx2 = ndx2 + 1

        testDesignFactory = tempTest.DesignStepFactory
        designTree = testDesignFactory.NewList("")

        ws.Cells(ndx2, 3) = "Design Steps:"
        ws.Cells(ndx2, 3).Font.Bold = True

        ws.Cells(ndx2, 4) = "Step Name"
        ws.Cells(ndx2, 4).Font.Bold = True

        ws.Cells(ndx2, 5) = "Description"
        ws.Cells(ndx2, 5).Font.Bold = True

        ws.Cells(ndx2, 6) = "Expected"
        ws.Cells(ndx2, 6).Font.Bold = True

        ndx2 = ndx2 + 1

        ndx1 = 1

        For Each testDesignStep In designTree

            With testDesignStep

                calledTestID = testDesignStep.LinkTestID

                If calledTestID <> "0" Then

                    ws.Cells(ndx2, 4) = StripTags(testDesignStep.StepName, False)
                    ws.Cells(ndx2, 5) = StripTags(testDesignStep.StepDescription, True)
                    ws.Cells(ndx2, 6) = StripTags(testDesignStep.StepExpectedResult, True)

                    ' Bold the line to indicate it's calling another test...
                    ws.Cells(ndx2, 4).Font.Bold = True
                    ws.Cells(ndx2, 5).Font.Bold = True
                    ws.Cells(ndx2, 6).Font.Bold = True

                    ws.Cells(ndx2, 4).Font.Italic = True
                    ws.Cells(ndx2, 5).Font.Italic = True
                    ws.Cells(ndx2, 6).Font.Italic = True

                    ndx2 = ndx2 + 1

                    ' Expand the called test in-stream...

                    calledTest = tdconTestFactory.Item(calledTestID)
                    calledTestDesignFactory = calledTest.DesignStepFactory
                    calledDesignTree = calledTestDesignFactory.NewList("")

                    For Each calledTestDesignStep In calledDesignTree

                        ws.Cells(ndx2, 3) = calledTest.Name
                        curRange = "C" & ndx2.ToString
                        ws.Range(curRange).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlRight
                        ws.Cells(ndx2, 4) = StripTags(calledTestDesignStep.StepName, True)
                        curRange = "D" & ndx2.ToString
                        ws.Range(curRange).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlRight
                        ws.Cells(ndx2, 5) = StripTags(calledTestDesignStep.StepDescription, True)
                        ws.Cells(ndx2, 6) = StripTags(calledTestDesignStep.StepExpectedResult, True)

                        ndx2 = ndx2 + 1

                    Next


                Else

                    ws.Cells(ndx2, 4) = StripTags(testDesignStep.StepName, True)
                    ws.Cells(ndx2, 5) = StripTags(testDesignStep.StepDescription, True)
                    ws.Cells(ndx2, 6) = StripTags(testDesignStep.StepExpectedResult, True)

                    ndx2 = ndx2 + 1

                End If

            End With

            TaskStatus3.Value = 100 * (ndx1 / designTree.Count)
            Application.DoEvents()

            ndx1 = ndx1 + 1

        Next

        ndx2 = ndx2 + 1

    End Sub

    Private Sub walkTestLab(curTestSet)

        Dim calledTestID, curRange As String

        ' Subroutine to walk a single test set...
        tdconTestSetFactory = tdconTarget.TestSetFactory
        testSetTree = tdconTestSetFactory.NewList("")
        tdconTestSet = testSetTree.Item(1)

        tempTestSet = tdconTestSetFactory.Item(curTestSet)

        ' Get the Test Set information...
        ws.Cells(ndx2, 1) = "Test Set Name:"
        ws.Cells(ndx2, 1).Font.Bold = True

        ws.Cells(ndx2, 2) = tempTestSet.Name
        ws.Cells(ndx2, 2).Font.Bold = True

        ws.Cells(ndx2, 3) = "Test Set Folder:" & tempTestSet.TestSetFolder.Path

        ndx2 = ndx2 + 2

        ' Loop over the called tests...
        tdconTSTestFactory = tempTestSet.TSTestFactory
        testTSTree = tdconTSTestFactory.NewList("")

        ndx3 = 1

        For Each tempTSTest In testTSTree

            With tempTSTest

                ws.Cells(ndx2, 2) = "Test Name: "
                ws.Cells(ndx2, 2).Font.Bold = True

                ws.Cells(ndx2, 3) = tempTSTest.Name
                ws.Cells(ndx2, 4) = "Test ID: " & tempTSTest.TestId
                ws.Cells(ndx2, 5) = "Test Type: " & tempTSTest.Type

                ndx2 = ndx2 + 1

                ws.Cells(ndx2, 3) = "Design Steps:"
                ws.Cells(ndx2, 3).Font.Bold = True

                ws.Cells(ndx2, 4) = "Step Name"
                ws.Cells(ndx2, 4).Font.Bold = True

                ws.Cells(ndx2, 5) = "Description"
                ws.Cells(ndx2, 5).Font.Bold = True

                ws.Cells(ndx2, 6) = "Expected"
                ws.Cells(ndx2, 6).Font.Bold = True


                ndx2 = ndx2 + 1

                ' Get the current test steps...
                tdconTestFactory = tdconTarget.TestFactory

                tempTest = tdconTestFactory.Item(tempTSTest.TestId)
                testDesignFactory = tempTest.DesignStepFactory
                designTree = testDesignFactory.NewList("")

                ndx1 = 1

                For Each testDesignStep In designTree

                    calledTestID = testDesignStep.LinkTestID

                    If calledTestID <> "0" Then

                        ws.Cells(ndx2, 4) = StripTags(testDesignStep.StepName, False)
                        ws.Cells(ndx2, 5) = StripTags(testDesignStep.StepDescription, True)
                        ws.Cells(ndx2, 6) = StripTags(testDesignStep.StepExpectedResult, True)

                        ' Bold the line to indicate it's calling another test...
                        ws.Cells(ndx2, 4).Font.Bold = True
                        ws.Cells(ndx2, 5).Font.Bold = True
                        ws.Cells(ndx2, 6).Font.Bold = True

                        ws.Cells(ndx2, 4).Font.Italic = True
                        ws.Cells(ndx2, 5).Font.Italic = True
                        ws.Cells(ndx2, 6).Font.Italic = True

                        ndx2 = ndx2 + 1

                        ' Expand the called test in-stream...

                        calledTest = tdconTestFactory.Item(calledTestID)
                        calledTestDesignFactory = calledTest.DesignStepFactory
                        calledDesignTree = calledTestDesignFactory.NewList("")

                        For Each calledTestDesignStep In calledDesignTree

                            ws.Cells(ndx2, 3) = calledTest.Name
                            curRange = "C" & ndx2.ToString
                            ws.Range(curRange).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlRight
                            ws.Cells(ndx2, 4) = StripTags(calledTestDesignStep.StepName, True)
                            curRange = "D" & ndx2.ToString
                            ws.Range(curRange).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlRight
                            ws.Cells(ndx2, 5) = StripTags(calledTestDesignStep.StepDescription, True)
                            ws.Cells(ndx2, 6) = StripTags(calledTestDesignStep.StepExpectedResult, True)

                            ndx2 = ndx2 + 1

                        Next


                    Else

                        ws.Cells(ndx2, 4) = StripTags(testDesignStep.StepName, True)
                        ws.Cells(ndx2, 5) = StripTags(testDesignStep.StepDescription, True)
                        ws.Cells(ndx2, 6) = StripTags(testDesignStep.StepExpectedResult, True)

                        ndx2 = ndx2 + 1

                    End If

                    TaskStatus3.Value = 100 * (ndx1 / designTree.Count)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                Next

                ndx2 = ndx2 + 1

            End With

            TaskStatus2.Value = 100 * (ndx3 / testTSTree.Count)
            Application.DoEvents()

            ndx3 = ndx3 + 1

        Next

        ' Add a blank line between test sets...
        ndx2 = ndx2 + 1

    End Sub

    Function StripTags(ByVal html As String, ByVal doStrip As Boolean) As String

        Dim tString As String

        ' Remove HTML tags...
        If doStrip Then
            tString = System.Text.RegularExpressions.Regex.Replace(html, "<.*?>", "")
        Else
            tString = html
        End If

        ' Replace special characters...
        tString = tString.Replace("&quot;", "'")
        tString = tString.Replace("&nbsp;", " ")
        tString = tString.Replace("&lt;", "<")
        tString = tString.Replace("&gt;", ">")

        ' Remove any extraneous line feeds...
        tString = tString.Replace(vbLf, "")

        Return tString

    End Function

    Sub GrowPlanTree()

        Dim ndx, ndx2, childCount As Integer

        treeView.Nodes.Add("Subject")

        tdconPlanFolderTree = tdconTarget.TestFolderFactory
        tdconTestFilter = tdconPlanFolderTree.Filter

        tdconTestFilter.Filter("AL_FATHER_ID") = 2
        testTree = tdconTestFilter.NewList

        ndx = testTree.Count

        Array.Clear(curShortNames, 0, 0)
        Array.Clear(curFolderIDs, 0, 0)
        Array.Clear(curChildCount, 0, 0)

        ndx2 = 0

        For Each tempTestFolder In testTree

            treeView.Nodes(0).Nodes.Add(tempTestFolder.Name).Tag = tempTestFolder.ID.ToString()

            curShortNames(ndx2) = tempTestFolder.Name
            curFolderIDs(ndx2) = tempTestFolder.ID
            curChildCount(ndx2) = tempTestFolder.Count
            ndx2 = ndx2 + 1

            TaskStatus.Value = 100 * (ndx2 / ndx)
            Application.DoEvents()

        Next

        treeView.Sort()

        ' Go back and add placeholders...
        childCount = treeView.Nodes(0).GetNodeCount(False)
        For ndx = 0 To childCount - 1
            treeView.Nodes(0).Nodes(ndx).ImageIndex = 0
            treeView.Nodes(0).Nodes(ndx).SelectedImageIndex = 1
            treeView.Nodes(0).Nodes(ndx).Nodes.Add("Placeholder")

            TaskStatus.Value = 100 * ((ndx + 1) / childCount)
            Application.DoEvents()

        Next

        RunStatus.Text = "Test Plan tree updated"
        TaskStatus.Value = 0
        Application.DoEvents()

    End Sub

    Sub GrowLabTree()

        Dim ndx, ndx2 As Integer
        Dim childCount As Integer

        ' Given the selected domain and project, create and populate the base tree...
        ' Put "Root" at the top...
        treeView.Nodes.Add("Root")

        ' Loop over the subfolders, populating Root's first level...

        tdconLabFolderTree = tdconTarget.TestLabFolderFactory
        tdconTestFilter = tdconLabFolderTree.Filter

        tdconTestFilter.Filter("CF_FATHER_ID") = 0
        testSetTree = tdconTestFilter.NewList

        ndx = testSetTree.Count

        Array.Clear(curShortNames, 0, 0)
        Array.Clear(curFolderIDs, 0, 0)
        Array.Clear(curChildCount, 0, 0)

        ndx2 = 0

        For Each tempTestSetFolder In testSetTree

            treeView.Nodes(0).Nodes.Add(tempTestSetFolder.Field("CF_ITEM_NAME"))

            curShortNames(ndx2) = tempTestSetFolder.Field("CF_ITEM_NAME")
            curFolderIDs(ndx2) = tempTestSetFolder.ID
            curChildCount(ndx2) = tempTestSetFolder.Count

            ndx2 = ndx2 + 1

            TaskStatus.Value = 100 * (ndx2 / ndx)
            Application.DoEvents()

        Next


        ' Go back and add placeholders...
        childCount = treeView.Nodes(0).GetNodeCount(False)
        For ndx = 0 To childCount - 1
            treeView.Nodes(0).Nodes(ndx).ImageIndex = 0
            treeView.Nodes(0).Nodes(ndx).SelectedImageIndex = 1
            treeView.Nodes(0).Nodes(ndx).Nodes.Add("Placeholder")
        Next

    End Sub

    Private Sub changePlanTree(ByVal e As TreeViewEventArgs)

        Dim nodeName, shortNodeName As String
        Dim childCount, ndx, ndx2 As Integer

        RunStatus.Text = "Updating Test Plan tree..."
        Application.DoEvents()

        Me.treeView.SelectedNode = e.Node
        nodeName = treeView.SelectedNode.FullPath
        shortNodeName = treeView.SelectedNode.Text

        If nodeName <> "Subject" Then

            tdconPlanFolderTree = tdconTarget.TestFolderFactory
            tdconTestFilter = tdconPlanFolderTree.Filter

            ndx = Array.IndexOf(curShortNames, shortNodeName)
            ndx2 = curFolderIDs(ndx)
            tdconTestFilter.Filter("AL_FATHER_ID") = curFolderIDs(ndx)
            testTree = tdconTestFilter.NewList

            childCount = testTree.Count

            If childCount > 0 Then
                ' Clear the placeholder and add the next level of folders...
                treeView.SelectedNode.Nodes.Clear()

                Array.Clear(curShortNames, 0, 0)
                Array.Clear(curFolderIDs, 0, 0)
                Array.Clear(curChildCount, 0, 0)
                ndx2 = 0

                For Each tempTestFolder In testTree

                    treeView.SelectedNode.Nodes.Add(tempTestFolder.Name).Tag = tempTestFolder.ID.ToString()

                    curShortNames(ndx2) = tempTestFolder.Name
                    curFolderIDs(ndx2) = tempTestFolder.ID
                    curChildCount(ndx2) = tempTestFolder.Count

                    ndx2 = ndx2 + 1

                    TaskStatus.Value = 100 * (ndx2 / childCount)
                    Application.DoEvents()

                Next

                ' ...then add icons and a placeholder node for next level down...
                For ndx = 0 To childCount - 1
                    treeView.SelectedNode.Nodes(ndx).ImageIndex = 0
                    treeView.SelectedNode.Nodes(ndx).SelectedImageIndex = 1

                    If curChildCount(ndx) > 0 Then
                        Try
                            treeView.SelectedNode.Nodes(ndx).Nodes.Add("-Data-")
                        Catch
                        End Try
                    End If

                    TaskStatus.Value = 100 * ((ndx + 1) / childCount)
                    Application.DoEvents()

                Next
            End If
        End If

        RunStatus.Text = "Test Plan tree updated"
        TaskStatus.Value = 0
        Application.DoEvents()

    End Sub

    Private Sub changeLabTree(ByVal e As TreeViewEventArgs)

        Dim nodeName, shortNodeName As String
        Dim childCount, ndx, ndx2 As Integer

        RunStatus.Text = "Updating Test Lab tree..."
        Application.DoEvents()

        Me.treeView.SelectedNode = e.Node
        nodeName = treeView.SelectedNode.FullPath
        shortNodeName = treeView.SelectedNode.Text

        If nodeName <> "Root" Then

            tdconLabFolderTree = tdconTarget.TestLabFolderFactory
            tdconTestFilter = tdconLabFolderTree.Filter

            ndx = Array.IndexOf(curShortNames, shortNodeName)
            ndx2 = curFolderIDs(ndx)
            tdconTestFilter.Filter("CF_FATHER_ID") = curFolderIDs(ndx)
            testSetTree = tdconTestFilter.NewList

            childCount = testSetTree.Count
            ndx2 = 0

            If childCount > 0 Then
                ' Clear the placeholder and add the next level of folders...
                treeView.SelectedNode.Nodes.Clear()

                For Each tempTestSetFolder In testSetTree

                    treeView.SelectedNode.Nodes.Add(tempTestSetFolder.Field("CF_ITEM_NAME")).Tag = tempTestSetFolder.ID.ToString()

                    curShortNames(ndx2) = tempTestSetFolder.Field("CF_ITEM_NAME")
                    curFolderIDs(ndx2) = tempTestSetFolder.ID
                    curChildCount(ndx2) = tempTestSetFolder.Count

                    ndx2 = ndx2 + 1

                    TaskStatus.Value = 100 * (ndx2 / childCount)
                    Application.DoEvents()

                Next

                ' ...then add icons and a placeholder node for next level down...
                For ndx = 0 To ndx2 - 1
                    treeView.SelectedNode.Nodes(ndx).ImageIndex = 0
                    treeView.SelectedNode.Nodes(ndx).SelectedImageIndex = 1

                    If curChildCount(ndx) > 0 Then
                        Try
                            treeView.SelectedNode.Nodes(ndx).Nodes.Add("-Data-")
                        Catch
                        End Try
                    End If

                    TaskStatus.Value = 100 * ((ndx + 1) / childCount)
                    Application.DoEvents()

                Next
            End If
        End If

        RunStatus.Text = "Test Lab tree updated"
        Application.DoEvents()

    End Sub

    Private Sub QCConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QCConnect.Click
        Dim tdurl_arr
        Dim ndx

        On Error GoTo CheckError

        If QCTargetID.Text = "" Or QCTargetPsw.Text = "" Then
            If Not batchStatus Then MsgBox("UserID and Password are required")
            Exit Sub
        End If

        tdconTarget.InitConnectionEx(QCTarget.Text)

        If tdconTarget.Connected = False Then
            If Not batchStatus Then MsgBox("Can not connect to QC Server")
            Exit Sub
        End If

        tdconTarget.Login(QCTargetID.Text, QCTargetPsw.Text)

        If tdconTarget.LoggedIn = False Then
            If Not batchStatus Then MsgBox("Unable to login.  Check User and Password information then try again.")
            Exit Sub
        End If

        ' Connection good...set Domain and Project selections and change state of boxes and buttons to show this...

        For ndx = 1 To tdconTarget.VisibleDomains.Count
            If tdconTarget.VisibleProjects(tdconTarget.VisibleDomains.Item(ndx)).Count > 0 Then
                QCDomList.Items.Add(tdconTarget.VisibleDomains.Item(ndx))
            End If
        Next

        QCDomList.SelectedIndex = 0
        QCTarget.Enabled = False
        QCTargetID.Enabled = False
        QCTargetPsw.Enabled = False

        QCLogin.Enabled = True
        QCLogin.Visible = True
        QCDomList.Enabled = True
        QCProjList.Enabled = True

        RunStatus.Text = "Log in to Quality Center..."
        Application.DoEvents()

        Exit Sub
CheckError:
        If Not batchStatus Then MsgBox("cmdServer_Click Error #" & (Err.Number - vbObjectError) & Chr(13) & Err.Description, vbCritical)

    End Sub

    Private Sub QCDomList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QCDomList.SelectedIndexChanged
        Dim ndx

        QCProjList.Items.Clear()

        For ndx = 1 To tdconTarget.VisibleProjects(QCDomList.Text).Count
            QCProjList.Items.Add(tdconTarget.VisibleProjects(QCDomList.Text).Item(ndx))
        Next

        sDomain = QCDomList.Text

        QCProjList.SelectedIndex = 0

    End Sub

    Private Sub QCProjList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QCProjList.SelectedIndexChanged

        sProject = QCProjList.Text

    End Sub

    Private Sub QCLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QCLogin.Click

        RunStatus.Text = "Logging in to Quality Center..."
        Application.DoEvents()

        tdconTarget.Connect(QCDomList.Text, QCProjList.Text)

        ' Connect to the selected project...
        tdconTarget.Connect(sDomain, sProject)

        RunStatus.Text = "Select either Test Plan or Test Lab as the source..."
        Application.DoEvents()

    End Sub

    Private Sub QCExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QCExit.Click

        If tdconTarget.Connected = True Then
            ' Close the QC connection...
            tdconTarget.Logout()
            tdconTarget.ReleaseConnection()
        End If

        Me.Close()

    End Sub

End Class
