﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QC12TestSetExport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.statusBox = New System.Windows.Forms.GroupBox()
        Me.RunStatus = New System.Windows.Forms.RichTextBox()
        Me.TaskStatus = New System.Windows.Forms.ProgressBar()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.QCProjList = New System.Windows.Forms.ComboBox()
        Me.QCLogin = New System.Windows.Forms.Button()
        Me.QCDomList = New System.Windows.Forms.ComboBox()
        Me.QCConnect = New System.Windows.Forms.Button()
        Me.QCTargetPsw = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.QCTargetID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.QCTarget = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.exportTestSet = New System.Windows.Forms.Button()
        Me.QCExit = New System.Windows.Forms.Button()
        Me.treeLabel = New System.Windows.Forms.Label()
        Me.moduleBox = New System.Windows.Forms.GroupBox()
        Me.doLab = New System.Windows.Forms.RadioButton()
        Me.doPlan = New System.Windows.Forms.RadioButton()
        Me.treeView = New System.Windows.Forms.TreeView()
        Me.TaskStatus2 = New System.Windows.Forms.ProgressBar()
        Me.TaskStatus3 = New System.Windows.Forms.ProgressBar()
        Me.statusBox.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.moduleBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'statusBox
        '
        Me.statusBox.Controls.Add(Me.TaskStatus3)
        Me.statusBox.Controls.Add(Me.TaskStatus2)
        Me.statusBox.Controls.Add(Me.RunStatus)
        Me.statusBox.Controls.Add(Me.TaskStatus)
        Me.statusBox.Location = New System.Drawing.Point(492, 428)
        Me.statusBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.statusBox.Name = "statusBox"
        Me.statusBox.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.statusBox.Size = New System.Drawing.Size(450, 266)
        Me.statusBox.TabIndex = 60
        Me.statusBox.TabStop = False
        Me.statusBox.Text = "Status"
        '
        'RunStatus
        '
        Me.RunStatus.BackColor = System.Drawing.SystemColors.Control
        Me.RunStatus.Location = New System.Drawing.Point(22, 28)
        Me.RunStatus.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RunStatus.Name = "RunStatus"
        Me.RunStatus.Size = New System.Drawing.Size(402, 91)
        Me.RunStatus.TabIndex = 8
        Me.RunStatus.Text = "Connect to Quality Center..."
        '
        'TaskStatus
        '
        Me.TaskStatus.Location = New System.Drawing.Point(22, 129)
        Me.TaskStatus.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TaskStatus.Name = "TaskStatus"
        Me.TaskStatus.Size = New System.Drawing.Size(404, 31)
        Me.TaskStatus.TabIndex = 7
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.QCProjList)
        Me.GroupBox2.Controls.Add(Me.QCLogin)
        Me.GroupBox2.Controls.Add(Me.QCDomList)
        Me.GroupBox2.Controls.Add(Me.QCConnect)
        Me.GroupBox2.Controls.Add(Me.QCTargetPsw)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.QCTargetID)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.QCTarget)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(18, 18)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox2.Size = New System.Drawing.Size(450, 400)
        Me.GroupBox2.TabIndex = 62
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Quality Center Connect"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(22, 314)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(58, 20)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "Project"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(22, 245)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(64, 20)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Domain"
        '
        'QCProjList
        '
        Me.QCProjList.FormattingEnabled = True
        Me.QCProjList.Location = New System.Drawing.Point(27, 343)
        Me.QCProjList.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCProjList.Name = "QCProjList"
        Me.QCProjList.Size = New System.Drawing.Size(397, 28)
        Me.QCProjList.TabIndex = 25
        '
        'QCLogin
        '
        Me.QCLogin.Location = New System.Drawing.Point(267, 203)
        Me.QCLogin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCLogin.Name = "QCLogin"
        Me.QCLogin.Size = New System.Drawing.Size(112, 35)
        Me.QCLogin.TabIndex = 22
        Me.QCLogin.Text = "Login"
        Me.QCLogin.UseVisualStyleBackColor = True
        '
        'QCDomList
        '
        Me.QCDomList.FormattingEnabled = True
        Me.QCDomList.Location = New System.Drawing.Point(27, 272)
        Me.QCDomList.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCDomList.Name = "QCDomList"
        Me.QCDomList.Size = New System.Drawing.Size(397, 28)
        Me.QCDomList.TabIndex = 24
        '
        'QCConnect
        '
        Me.QCConnect.Location = New System.Drawing.Point(267, 128)
        Me.QCConnect.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCConnect.Name = "QCConnect"
        Me.QCConnect.Size = New System.Drawing.Size(112, 35)
        Me.QCConnect.TabIndex = 23
        Me.QCConnect.Text = "Connect"
        Me.QCConnect.UseVisualStyleBackColor = True
        '
        'QCTargetPsw
        '
        Me.QCTargetPsw.Location = New System.Drawing.Point(27, 203)
        Me.QCTargetPsw.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCTargetPsw.Name = "QCTargetPsw"
        Me.QCTargetPsw.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.QCTargetPsw.Size = New System.Drawing.Size(186, 26)
        Me.QCTargetPsw.TabIndex = 22
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 175)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 20)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Password"
        '
        'QCTargetID
        '
        Me.QCTargetID.Location = New System.Drawing.Point(27, 132)
        Me.QCTargetID.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCTargetID.Name = "QCTargetID"
        Me.QCTargetID.Size = New System.Drawing.Size(186, 26)
        Me.QCTargetID.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 105)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 20)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "User ID"
        '
        'QCTarget
        '
        Me.QCTarget.Location = New System.Drawing.Point(27, 65)
        Me.QCTarget.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCTarget.Name = "QCTarget"
        Me.QCTarget.Size = New System.Drawing.Size(397, 26)
        Me.QCTarget.TabIndex = 18
        Me.QCTarget.Text = "http://alm12.suntrust.com/qcbin"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 38)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 20)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Quality Center"
        '
        'exportTestSet
        '
        Me.exportTestSet.Location = New System.Drawing.Point(492, 723)
        Me.exportTestSet.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.exportTestSet.Name = "exportTestSet"
        Me.exportTestSet.Size = New System.Drawing.Size(152, 35)
        Me.exportTestSet.TabIndex = 64
        Me.exportTestSet.Text = "Export"
        Me.exportTestSet.UseVisualStyleBackColor = True
        '
        'QCExit
        '
        Me.QCExit.Location = New System.Drawing.Point(830, 723)
        Me.QCExit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QCExit.Name = "QCExit"
        Me.QCExit.Size = New System.Drawing.Size(112, 35)
        Me.QCExit.TabIndex = 63
        Me.QCExit.Text = "Exit"
        Me.QCExit.UseVisualStyleBackColor = True
        '
        'treeLabel
        '
        Me.treeLabel.AutoSize = True
        Me.treeLabel.Location = New System.Drawing.Point(500, 86)
        Me.treeLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.treeLabel.Name = "treeLabel"
        Me.treeLabel.Size = New System.Drawing.Size(170, 20)
        Me.treeLabel.TabIndex = 67
        Me.treeLabel.Text = "Select starting location"
        '
        'moduleBox
        '
        Me.moduleBox.Controls.Add(Me.doLab)
        Me.moduleBox.Controls.Add(Me.doPlan)
        Me.moduleBox.Location = New System.Drawing.Point(492, 18)
        Me.moduleBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.moduleBox.Name = "moduleBox"
        Me.moduleBox.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.moduleBox.Size = New System.Drawing.Size(450, 58)
        Me.moduleBox.TabIndex = 66
        Me.moduleBox.TabStop = False
        Me.moduleBox.Text = "Select Module"
        '
        'doLab
        '
        Me.doLab.AutoSize = True
        Me.doLab.Location = New System.Drawing.Point(164, 24)
        Me.doLab.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.doLab.Name = "doLab"
        Me.doLab.Size = New System.Drawing.Size(89, 24)
        Me.doLab.TabIndex = 2
        Me.doLab.TabStop = True
        Me.doLab.Text = "Test Lab"
        Me.doLab.UseVisualStyleBackColor = True
        '
        'doPlan
        '
        Me.doPlan.AutoSize = True
        Me.doPlan.Location = New System.Drawing.Point(27, 24)
        Me.doPlan.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.doPlan.Name = "doPlan"
        Me.doPlan.Size = New System.Drawing.Size(93, 24)
        Me.doPlan.TabIndex = 1
        Me.doPlan.TabStop = True
        Me.doPlan.Text = "Test Plan"
        Me.doPlan.UseVisualStyleBackColor = True
        '
        'treeView
        '
        Me.treeView.Location = New System.Drawing.Point(492, 123)
        Me.treeView.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.treeView.Name = "treeView"
        Me.treeView.Size = New System.Drawing.Size(448, 295)
        Me.treeView.TabIndex = 65
        '
        'TaskStatus2
        '
        Me.TaskStatus2.Location = New System.Drawing.Point(22, 170)
        Me.TaskStatus2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TaskStatus2.Name = "TaskStatus2"
        Me.TaskStatus2.Size = New System.Drawing.Size(404, 31)
        Me.TaskStatus2.TabIndex = 9
        '
        'TaskStatus3
        '
        Me.TaskStatus3.Location = New System.Drawing.Point(22, 211)
        Me.TaskStatus3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TaskStatus3.Name = "TaskStatus3"
        Me.TaskStatus3.Size = New System.Drawing.Size(404, 31)
        Me.TaskStatus3.TabIndex = 10
        '
        'QC12TestSetExport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(964, 777)
        Me.Controls.Add(Me.treeLabel)
        Me.Controls.Add(Me.moduleBox)
        Me.Controls.Add(Me.treeView)
        Me.Controls.Add(Me.exportTestSet)
        Me.Controls.Add(Me.QCExit)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.statusBox)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "QC12TestSetExport"
        Me.Text = "ALM 12.53 - Test Plan\Test Lab Export - v 1.0"
        Me.statusBox.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.moduleBox.ResumeLayout(False)
        Me.moduleBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents statusBox As GroupBox
    Friend WithEvents RunStatus As RichTextBox
    Friend WithEvents TaskStatus As ProgressBar
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents QCProjList As ComboBox
    Friend WithEvents QCLogin As Button
    Friend WithEvents QCDomList As ComboBox
    Friend WithEvents QCConnect As Button
    Friend WithEvents QCTargetPsw As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents QCTargetID As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents QCTarget As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents exportTestSet As Button
    Friend WithEvents QCExit As Button
    Friend WithEvents treeLabel As Label
    Friend WithEvents moduleBox As GroupBox
    Friend WithEvents doLab As RadioButton
    Friend WithEvents doPlan As RadioButton
    Friend WithEvents treeView As TreeView
    Friend WithEvents TaskStatus3 As ProgressBar
    Friend WithEvents TaskStatus2 As ProgressBar
End Class
