﻿Public Class ALMDataMerge

    ' ALM OTA variables...
    'Naga Changes Testing
    Dim tdconSource, tdconTarget As New TDAPIOLELib.TDConnection

    Dim SAClientSource As New SACLIENTLib.SAapi
    Dim SAClientTarget As New SACLIENTLib.SAapi

    Dim saReply, saReply2

    Dim tdconSourceReqFactory, tdconTargetReqFactory, synchTempReqFactory As TDAPIOLELib.ReqFactory
    Dim tdconSourceTestFactory, tdconTargetTestFactory As TDAPIOLELib.TestFactory
    Dim tdconSourceTestFolderFactory, tdconTargetTestFolderFactory As TDAPIOLELib.TestFolderFactory
    Dim tdconSourceDesignStepFactory, tdconTargetDesignStepFactory As TDAPIOLELib.DesignStepFactory
    Dim testSourceExtendedStorage, testTargetExtendedStorage As TDAPIOLELib.ExtendedStorage
    Dim testTreeMgr As TDAPIOLELib.TreeManager
    Dim workingFolder, workingNode As TDAPIOLELib.SubjectNode

    Dim tdconSourceTestSetFactory, tdconTargetTestSetFactory As TDAPIOLELib.TestSetFactory
    Dim sourceTSTFactory, targetTSTFactory As TDAPIOLELib.TSTestFactory
    Dim sourceTSTest, targetTSTest As TDAPIOLELib.TSTest
    Dim tdconSourceTSFolderFactory, tdconTargetTSFolderFactory As TDAPIOLELib.TestLabFolderFactory
    Dim sourceTestSetFolder, targetTestSetFolder As TDAPIOLELib.TestLabFolder
    Dim sourceTSFilter, targetTSFilter As TDAPIOLELib.TDFilter
    Dim sourceTSFList, targetTSFList, sourceTSTFList As TDAPIOLELib.List
    Dim sourceTestSet, targetTestSet, newTestSet, tempTestSet As TDAPIOLELib.TestSet

    Dim sourceReq, newReq, tempReq, tempReq2 As TDAPIOLELib.Req
    Dim coverableReq As TDAPIOLELib.ICoverableReq
    Dim sourceTest, newTest, tempTest, tempTest2 As TDAPIOLELib.Test
    Dim sourceStep, targetStep, tempStep, tempStep2 As TDAPIOLELib.DesignStep
    Dim sourceBug, newBug, tempBug, tempBug2 As TDAPIOLELib.Bug

    Dim tdconCommand, tdconCommand2, tdconCommand3, tdconCommand4 As TDAPIOLELib.Command
    Dim tdconRecSet, tdconRecSet2, tdconRecSet3, tdconRecSet4 As TDAPIOLELib.Recordset

    Dim cust As TDAPIOLELib.Customization
    Dim custUsers As TDAPIOLELib.CustomizationUsers
    Dim custLists As TDAPIOLELib.CustomizationLists
    Dim custListNode As TDAPIOLELib.CustomizationListNode
    Dim workingList As TDAPIOLELib.CustomizationList
    Dim cuser As TDAPIOLELib.CustomizationUser
    Dim curLocation As TDAPIOLELib.List

    ' Excel objects
    Dim wa1 As New Microsoft.Office.Interop.Excel.Application
    Dim wb1 As Microsoft.Office.Interop.Excel.Workbook
    Dim ws1 As Microsoft.Office.Interop.Excel.Worksheet
    Dim wRange As Microsoft.Office.Interop.Excel.Range
    Dim dFound As Microsoft.Office.Interop.Excel.Range

    ' Outlook Definitions
    Dim ApprEmail As New Microsoft.Office.Interop.Outlook.Application
    Dim oMailItem As Microsoft.Office.Interop.Outlook.MailItem
    Dim almUSer As Microsoft.Office.Interop.Outlook.Recipient
    Dim userEntry As Microsoft.Office.Interop.Outlook.AddressEntry

    Dim oWrite, reportWrite As System.IO.StreamWriter

    ' Local objects...
    Dim strcommandLine, SASource, sDomain, sProject, tDomain, tProject, strFileName, sumreport, strDate, filePath2, lastChecked, checkFromDate, checkToDate As String
    Dim tempBugID, tempBugID2, sourceBugID, tempReqID, tempReqID2, sourceReqID, tempTestID, tempTestID2, sourceTestID, curSource, tempTestSetID As String
    Dim sourceTestSetID, targetTestSetID As String

    Dim projectName(10000), relName(500), appName(10000), defectState(20), testPhase(20), severity(20), almPriority(20), almDomNames(50), almProjNames(50) As String

    Dim curReqFieldName, curTestFieldName, curDefectFieldName, almReqFieldName(50), sourceTestClientPath, sourceTestServerPath, targetTestClientPath, targetTestServerPath As String
    Dim firstRun, wasChanged As Boolean

    Dim almProjName, almFlatFile, almFlatRecord, almFields(20), sqlString, sqlString2, sqlString3, sqlString4, tDate, tName, moveToFolderID As String
    Dim icount, ndx1, ndx2, ndx3, ndx4, ndx5, alen, tlen, nCons, fCount, nAreas As Integer
    Dim Number, Custom_CopyToALM, Description, Custom_State, Custom_EnterpriseProjectName2, Custom_EnterpriseRelease2, LastUpdateDate, TargetDate As String
    Dim Custom_EnterpriseApplication, CreatedBy, CreateDate, Custom_TestPhase, Custom_Severity, Custom_Priority, Owners, Priority, AssetState, ClosedDate As String
    Dim myParent, myStatus, ExpectedResults, LastVerdict, ScheduledState, AcceptanceCriteria, synchReqFolderID, synchTestFolderID, Custom_Type As String
    Dim notdone, parentFound, badRecord As Boolean

    ' Const almFlat_DIR As String = "E:\MFConnect"
    Const almFlat_DIR As String = "C:\Temp"

    ' Version History
    '
    ' v 1.0 - Initial version - rework of ALM MOE Synch code
    ' v 1.1 - Added "from" and "to" date filters, test design steps
    ' v 1.2 - Converted report output to running text file to avoid memory issues
    ' v 1.3 - Added Automated tests
    ' v 1.4 - Added Test Sets
    '

    Private Sub QCDMALMSynch_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Set up the established production ALM project information...

        'almDomNames(0) = "BBT"
        'almDomNames(1) = "BBT"
        'almDomNames(2) = "BBT"
        'almDomNames(3) = "BBT"
        'almDomNames(4) = "BBT"
        'almDomNames(5) = "BBT"
        'almDomNames(6) = "BBT"
        'almDomNames(7) = "BBT"
        'almDomNames(8) = "BBT"
        'almDomNames(9) = "BBT"
        'almDomNames(10) = "BBT"
        'almDomNames(11) = "BBT"
        'almDomNames(12) = "BBT"
        'almDomNames(13) = "BBT"
        'almDomNames(14) = "BBT"
        'almDomNames(15) = "BBT"
        'almDomNames(16) = "BBT"
        'almDomNames(17) = "BBT"
        'almDomNames(18) = "BBT"
        'almDomNames(19) = "BBT"
        'almDomNames(20) = "BBT"
        'almDomNames(21) = "BBT"
        'almDomNames(22) = "BBT"
        'almDomNames(23) = "BBT"
        'almDomNames(24) = "BBT"
        'almDomNames(25) = "BBT"
        'almDomNames(26) = "BBT"
        'almDomNames(27) = "BBT"
        'almDomNames(28) = "BBT"
        'almDomNames(29) = "BBT"
        'almDomNames(30) = "BBT"
        'almDomNames(31) = "BBT"
        'almDomNames(32) = "BBT"
        'almDomNames(33) = "BBT"
        'almDomNames(34) = "BBT"
        'almDomNames(35) = "BBT"
        'almDomNames(36) = "BBT"
        'almDomNames(37) = "BBT"
        'almDomNames(38) = "BBT"
        'almDomNames(39) = "BBT"
        'almDomNames(40) = "BBT"
        'almDomNames(41) = "STRH_CIB"
        'almDomNames(42) = "SUNTRUST_BANK"
        'almDomNames(43) = "TRUIST"

        'almProjNames(0) = "Account_Analysis"
        'almProjNames(1) = "Acct_Reconcilement_Replacement"
        'almProjNames(2) = "ACH_PEP"
        'almProjNames(3) = "ATM_Deposit_Automation"
        'almProjNames(4) = "BSA_AML_ERCM"
        'almProjNames(5) = "Card_Personalization"
        'almProjNames(6) = "CCWP_FTM"
        'almProjNames(7) = "CIF"
        'almProjNames(8) = "CIP_CDD_E"
        'almProjNames(9) = "CL_Loan_Orig_Serv"
        'almProjNames(10) = "Client_Central"
        'almProjNames(11) = "CMOL_FIS"
        'almProjNames(12) = "CMOL_Replacement_BT"
        'almProjNames(13) = "Commerce_Gateway"
        'almProjNames(14) = "Construction_Loan_Control_Syst"
        'almProjNames(15) = "CPS"
        'almProjNames(16) = "Dealer_Finance"
        'almProjNames(17) = "Deposits"
        'almProjNames(18) = "Enterprise_Data_Office"
        'almProjNames(19) = "IRDB"
        'almProjNames(20) = "LG_ODH_Migration"
        'almProjNames(21) = "Lockbox"
        'almProjNames(22) = "LRM_2052A"
        'almProjNames(23) = "Mortg_Virtual_Cash_Workstation"
        'almProjNames(24) = "Mortgage_Servicing"
        'almProjNames(25) = "MWL_Client_Web_Portal"
        'almProjNames(26) = "ProjectOne"
        'almProjNames(27) = "RAC_SSR"
        'almProjNames(28) = "Regional_Acceptance_Scorecard"
        'almProjNames(29) = "Retail_Check_and_Item_Process"
        'almProjNames(30) = "Retail_Lending_Platform"
        'almProjNames(31) = "Retail_Paperless"
        'almProjNames(32) = "Sheffield_Financial"
        'almProjNames(33) = "TAF"
        'almProjNames(34) = "TCH_Real_Time_Payments"
        'almProjNames(35) = "Tech_Integration_and_Stability"
        'almProjNames(36) = "Treasury_Onboarding_Servicing"
        'almProjNames(37) = "Treasury_Solutions_Technology"
        'almProjNames(38) = "Wire_xfer_PWI"
        'almProjNames(39) = "Wire_xfer_WPI_MTS"
        'almProjNames(40) = "Worksoft_POC"
        'almProjNames(41) = "Derivatives_Portfolio"
        'almProjNames(42) = "EIS"
        'almProjNames(43) = "MOE"

        'nAreas = 44

        ' For Dry Runs, use these settings...

        almDomNames(0) = "BBT"
        almDomNames(1) = "TRUIST"

        almProjNames(0) = "BSA_AML_ERCM_Copy"
        almProjNames(1) = "MOE_Test_Copy"

        nAreas = 2

        ' Check the command line for any argument...
        ' Note:  MUST be object-specific here as the OTA API also has a "Command" method...

        strcommandLine = Microsoft.VisualBasic.Interaction.Command

        If strcommandLine <> "" Then

            ' This is a batch run...fetch the tokens...
            Call GetTokens()
            Call GetRunTag()

            sDomain = cmbDomain.Text
            sProject = cmbProject.Text

            firstRun = True

            ' In batch mode, we always "do all projects"...
            doAllProjects.Checked = True

            ' In batch mode, "from" is lastChecked and "to" is current date...
            checkFrom.Checked = True

            Try

                ' Log in to the target...
                tdconTarget.InitConnectionEx(cmbURL.Text)
                tdconTarget.Login(txtUser.Text, txtPassword.Text)
                tdconTarget.Connect(cmbDomain.Text, cmbProject.Text)

                ' Log in to the source, but not a specific project...
                tdconSource.InitConnectionEx(cmbURL.Text)
                tdconSource.Login(txtUser.Text, txtPassword.Text)

                ' Do the run...

                firstRun = True

                Call doMOESynch_Click(Me, New System.Windows.Forms.FormClosedEventArgs(CloseReason.None))

                Call SaveRunTag()

                Call cmdExit_Click(Me, New System.Windows.Forms.FormClosedEventArgs(CloseReason.None))

            Catch ex As Exception

            End Try

        Else

            ' Any additional interactive pre-run set up goes here...

            Call GetRunTag()

            sDomain = cmbDomain.Text
            sProject = cmbProject.Text

            checkFrom.Checked = True

            firstRun = True

        End If

    End Sub

    Private Sub ticketsAfter_ValueChanged(sender As Object, e As EventArgs) Handles ticketsAfter.ValueChanged

        lastChecked = ticketsAfter.Value.ToString("yyyy-MM-dd HH:mm:ss")
        checkFromDate = lastChecked

    End Sub

    Private Sub ticketsTo_ValueChanged(sender As Object, e As EventArgs) Handles ticketsTo.ValueChanged

        checkToDate = ticketsTo.Value.ToString("yyyy-MM-dd HH:mm:ss")

    End Sub

    Private Sub doMOESynch_Click(sender As Object, e As EventArgs) Handles doMOESynch.Click

        RunStatus.Text = "Starting processes..."
        Application.DoEvents()

        ' Get all of the ALM information before processing the files...

        If firstRun Then

            ' Fetch all of the current users from the target database...

            SASource = cmbURL.Text
            SAClientSource.Login(SASource, txtUser.Text, txtPassword.Text)

            saReply = SAClientSource.GetAllUsers

            RunStatus.Text = "Writing temporary XML file of users..."
            Application.DoEvents()

            ' Write out to temporary text file in XML format...
            oWrite = IO.File.CreateText(almFlat_DIR & "\" & "wb1.xml")
            oWrite.Write(saReply)
            oWrite.Close()

            RunStatus.Text = "Importing user XML into Excel..."
            Application.DoEvents()

            ' Import the XML into Excel...
            wa1.Workbooks.Add()
            wa1.Workbooks.Add()
            wb1 = wa1.ActiveWorkbook
            ws1 = wb1.Worksheets(1)

            wa1.ActiveWorkbook.XmlImport(Url:=almFlat_DIR & "\" & "wb1.xml", ImportMap:=Nothing, Overwrite:=True, Destination:=wa1.Range("$A$1"))
            IO.File.Delete(almFlat_DIR & "wb1.xml")

            ' Remove extraneous data...

            wRange = ws1.Columns("A")
            wRange.Select()
            wRange.Delete()
            wRange = ws1.Columns("C")
            wRange.Select()
            wRange.Delete()
            wRange = ws1.Columns("F")
            wRange.Select()
            wRange.Delete()
            wRange = ws1.Columns("F")
            wRange.Select()
            wRange.Delete()
            wRange = ws1.Columns("F")
            wRange.Select()
            wRange.Delete()
            wRange = ws1.Columns("F")
            wRange.Select()
            wRange.Delete()
            wRange = ws1.Columns("F")
            wRange.Select()
            wRange.Delete()

            ' Change/add titles...
            ws1.Cells(1, 1) = "RACFID"
            ws1.Cells(1, 2) = "User Name"
            ws1.Cells(1, 3) = "Email Address"
            ws1.Cells(1, 4) = "Phone #"
            ws1.Cells(1, 5) = "Description"
            ws1.Cells(1, 6) = "Quality Center Access Group"
            ws1.Cells(1, 7) = "Exchange Status"

            RunStatus.Text = "Fetching ALM check lists..."
            Application.DoEvents()

            ' Load the list of lists...
            cust = tdconTarget.Customization
            cust.Load()
            custLists = cust.Lists

            'Project...
            workingList = custLists.List("ProjectName")
            ndx1 = workingList.RootNode.ChildrenCount
            For icount = 1 To ndx1
                projectName(icount) = workingList.RootNode.Children.Item(icount).name
            Next

            'Release...
            workingList = custLists.List("Release")
            ndx1 = workingList.RootNode.ChildrenCount
            ndx3 = 1
            For icount = 1 To ndx1

                custListNode = workingList.RootNode.Children.Item(icount)

                If custListNode.ChildrenCount > 0 Then

                    ndx2 = custListNode.ChildrenCount

                    For icount2 = 1 To ndx2

                        relName(ndx3) = custListNode.Children.Item(icount2).name
                        ndx3 = ndx3 + 1

                    Next

                End If

            Next

            'Application...
            workingList = custLists.List("ApplicationName")
            ndx1 = workingList.RootNode.ChildrenCount
            For icount = 1 To ndx1
                appName(icount) = workingList.RootNode.Children.Item(icount).name
            Next

            'Defect Status...
            workingList = custLists.List("Bug Status")
            ndx1 = workingList.RootNode.ChildrenCount
            For icount = 1 To ndx1
                defectState(icount) = workingList.RootNode.Children.Item(icount).name
            Next

            'Test Phase...
            workingList = custLists.List("TestPhases")
            ndx1 = workingList.RootNode.ChildrenCount
            For icount = 1 To ndx1
                testPhase(icount) = workingList.RootNode.Children.Item(icount).name
            Next

            'Severity...
            workingList = custLists.List("Severity")
            ndx1 = workingList.RootNode.ChildrenCount
            For icount = 1 To ndx1
                severity(icount) = workingList.RootNode.Children.Item(icount).name
            Next

            'Priority...
            workingList = custLists.List("Priority")
            ndx1 = workingList.RootNode.ChildrenCount
            For icount = 1 To ndx1
                almPriority(icount) = workingList.RootNode.Children.Item(icount).name
            Next

            RunStatus.Text = "Set up complete..."
            Application.DoEvents()

        End If

        If doAllProjects.Checked Then

            ' Now process the projects in the list...

            For ndx = 0 To nAreas - 1

                sDomain = almDomNames(ndx)
                sProject = almProjNames(ndx)

                If sDomain <> "Do Not Synch" Then

                    ' Set up the report file...

                    strDate = DateTime.Now.ToString("yyyy-MM-dd")

                    filePath2 = almFlat_DIR & "\" & "ALM-" & sProject & "-Merge_" & strDate & ".txt"

                    ' Set up report file...
                    reportWrite = IO.File.CreateText(filePath2)

                    reportWrite.WriteLine("ALM Data Merge" & vbCrLf & "------------------------------")
                    reportWrite.WriteLine("  Date Last Run : " & lastChecked)

                    If checkFrom.Checked Then

                        reportWrite.WriteLine("  Data checked from date: " & ticketsAfter.Text)

                        If checkTo.Checked Then
                            reportWrite.WriteLine("  Data checked to date  : " & ticketsTo.Text)

                        End If

                    End If

                    reportWrite.WriteLine("     Source ALM : " & cmbURL.Text)
                    reportWrite.WriteLine("         Domain : " & sDomain & " Project: " & sProject)
                    reportWrite.WriteLine("     Target ALM : " & cmbURL.Text)
                    reportWrite.WriteLine("         Domain : " & cmbDomain.Text & " Project: " & cmbProject.Text)

                    ' Log in to the specific source...

                    tdconSource.Connect(sDomain, sProject)

                    If doReqs.Checked Then

                        reportWrite.WriteLine(vbCrLf & "--->  Processing Requirements...")

                        If sDomain = "BBT" Then Call processBBTALMReqs(sDomain, sProject)
                        If sDomain = "STRH_CIB" Then Call processSTRHALMReqs(sDomain, sProject)
                        If sDomain = "SUNTRUST_BANK" Then Call processSTIALMReqs(sDomain, sProject)
                        If sDomain = "TRUIST" Then Call processTruistALMReqs(sDomain, sProject)

                    End If

                    If doTests.Checked Then

                        reportWrite.WriteLine(vbCrLf & "--->  Processing Tests...")

                        If sDomain = "BBT" Then Call processBBTALMTests(sDomain, sProject)
                        If sDomain = "STRH_CIB" Then Call processSTRHALMTests(sDomain, sProject)
                        If sDomain = "SUNTRUST_BANK" Then Call processSTIALMTests(sDomain, sProject)
                        If sDomain = "TRUIST" Then Call processTruistALMTests(sDomain, sProject)

                    End If

                    If doTestSets.Checked Then

                        reportWrite.WriteLine(vbCrLf & "--->  Processing Test Setss...")

                        If sDomain = "BBT" Then Call processBBTALMTestSets(sDomain, sProject)
                        If sDomain = "STRH_CIB" Then Call processSTRHALMTestSets(sDomain, sProject)
                        If sDomain = "SUNTRUST_BANK" Then Call processSTIALMTestSets(sDomain, sProject)
                        If sDomain = "TRUIST" Then Call processTruistALMTestSets(sDomain, sProject)

                    End If

                    If doDefects.Checked Then

                        reportWrite.WriteLine(vbCrLf & "--->  Processing Defects...")

                        If sDomain = "BBT" Then Call processBBTALMDefects(sDomain, sProject)
                        If sDomain = "STRH_CIB" Then Call processSTRHALMDefects(sDomain, sProject)
                        If sDomain = "SUNTRUST_BANK" Then Call processSTIALMDefects(sDomain, sProject)
                        If sDomain = "TRUIST" Then Call processTruistALMDefects(sDomain, sProject)

                    End If

                    ' Write out the summary...
                    reportWrite.WriteLine(ControlChars.CrLf & "ALM data merge completed!")

                    reportWrite.Close()

                    RunStatus.Text = "Processing for " & sProject & " complete!"
                    Application.DoEvents()

                    ' Log out of this project...
                    tdconSource.DisconnectProject()

                    ' ...and log on to do the next one...
                    tdconSource.Login(txtUser.Text, txtPassword.Text)

                End If

            Next

        Else

            ' Do the individual project selected...

            sDomain = cmbDomain2.Text
            sProject = cmbProject2.Text

            ' Set up the report file...

            strDate = DateTime.Now.ToString("yyyy-MM-dd")

            filePath2 = almFlat_DIR & "\" & "ALM-" & sProject & "-Merge_" & strDate & ".txt"

            reportWrite = IO.File.CreateText(filePath2)

            reportWrite.WriteLine("ALM to ALM Merge" & vbCrLf & "------------------------------")
            reportWrite.WriteLine("  Date Last Run : " & lastChecked)

            If checkFrom.Checked Then

                reportWrite.WriteLine("  Data checked from date: " & ticketsAfter.Text)

                If checkTo.Checked Then
                    reportWrite.WriteLine("  Data checked to date  : " & ticketsTo.Text)

                End If

            End If

            reportWrite.WriteLine("     Source ALM : " & cmbURL.Text)
            reportWrite.WriteLine("         Domain : " & cmbDomain2.Text & " Project: " & cmbProject2.Text)
            reportWrite.WriteLine("     Target ALM : " & cmbURL.Text)
            reportWrite.WriteLine("         Domain : " & cmbDomain.Text & " Project: " & cmbProject.Text)

            ' Log in to the specific source...
            tdconSource.Connect(sDomain, sProject)

            If doReqs.Checked Then

                reportWrite.WriteLine(vbCrLf & "--->  Processing Requirements...")

                If sDomain = "BBT" Then Call processBBTALMReqs(sDomain, sProject)
                If sDomain = "STRH_CIB" Then Call processSTRHALMReqs(sDomain, sProject)
                If sDomain = "SUNTRUST_BANK" Then Call processSTIALMReqs(sDomain, sProject)
                If sDomain = "TRUIST" Then Call processTruistALMReqs(sDomain, sProject)

            End If

            If doTests.Checked Then

                reportWrite.WriteLine(vbCrLf & "--->  Processing Tests...")

                If sDomain = "BBT" Then Call processBBTALMTests(sDomain, sProject)
                If sDomain = "STRH_CIB" Then Call processSTRHALMTests(sDomain, sProject)
                If sDomain = "SUNTRUST_BANK" Then Call processSTIALMTests(sDomain, sProject)
                If sDomain = "TRUIST" Then Call processTruistALMTests(sDomain, sProject)

            End If

            If doDefects.Checked Then

                reportWrite.WriteLine(vbCrLf & "--->  Processing Defects...")

                If sDomain = "BBT" Then Call processBBTALMDefects(sDomain, sProject)
                If sDomain = "STRH_CIB" Then Call processSTRHALMDefects(sDomain, sProject)
                If sDomain = "SUNTRUST_BANK" Then Call processSTIALMDefects(sDomain, sProject)
                If sDomain = "TRUIST" Then Call processTruistALMDefects(sDomain, sProject)

            End If

            ' Write out the summary...
            reportWrite.WriteLine(ControlChars.CrLf & "ALM Merge completed")

            reportWrite.Close()

            RunStatus.Text = "Processing for " & sProject & " complete!"
            Application.DoEvents()

        End If

        RunStatus.Text = "All processing completed"
        fileProgress.Value = 100
        Application.DoEvents()
        firstRun = False

        ' Re-enable Logout buttons to allow for multiple passes...
        cmdLogout.Enabled = True

        ' Write out the time/date stamp for the next pass...

        Call SaveRunTag()

    End Sub
    Sub processBBTALMReqs(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount As Integer

        ' Set the initial destination for all new requirements to the 001_SynchTemp folder...

        curSource = "hBBT ALM"

        tdconTargetReqFactory = tdconTarget.ReqFactory
        tdconSourceReqFactory = tdconSource.ReqFactory

        curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", "001_SynchTemp", 16)
        tempString = curLocation.Item(1)
        tempArray = Split(tempString, ",")
        moveToFolderID = tempArray(0)

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select rq_req_id from req where (rq_vts >= '" & checkFromDate & "' and rq_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and RQ_TYPE_ID <> 1 and RQ_USER_TEMPLATE_13 Like '2022%' order by rq_req_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select rq_req_id from req where rq_vts >= '" & lastChecked & "' and RQ_TYPE_ID <> 1 and RQ_USER_TEMPLATE_13 like '2022%' order by rq_req_id"

        End If

        Try

            tdconCommand = tdconSource.Command
            tdconCommand.CommandText = sqlString
            tdconRecSet = tdconCommand.Execute

            If tdconRecSet.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

                ndx1 = 1

                While ndx1 <= tdconRecSet.RecordCount

                    sourceReqID = tdconRecSet.FieldValue(0)
                    sourceReq = tdconSourceReqFactory.Item(sourceReqID)

                    RunStatus.Text = "Processing requirement # " & sourceReq.ID & " from " & sProject & "..."
                    Application.DoEvents()

                    badRecord = False

                    ' Verify the straight assign fields...

                    If sourceReq.Field("RQ_USER_TEMPLATE_05") <> "" Then

                        If projectName.Contains(sourceReq.Field("RQ_USER_TEMPLATE_05")) Then
                            ' Project Name is right...
                        Else
                            ' Project Name is wrong...
                            reportWrite.WriteLine(sourceReqID & ": Invalid project name: " & sourceReq.Field("RQ_USER_TEMPLATE_05"))
                            badRecord = True
                        End If

                    Else

                        ' Project Name is missing...
                        reportWrite.WriteLine(sourceReqID & ": Missing project name")
                        badRecord = True

                    End If

                    If sourceReq.Field("RQ_USER_TEMPLATE_13") <> "" Then

                        If relName.Contains(sourceReq.Field("RQ_USER_TEMPLATE_13")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceReqID & ": Invalid release name: " & sourceReq.Field("RQ_USER_TEMPLATE_13"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceReqID & ": Missing release name")
                        badRecord = True

                    End If

                    If sourceReq.Field("RQ_USER_TEMPLATE_03") <> "" Then

                        If appName.Contains(sourceReq.Field("RQ_USER_TEMPLATE_03")) Then
                            ' Application Name is right...
                        Else
                            ' Application Name is wrong...
                            reportWrite.WriteLine(sourceReqID & ": Invalid application name: " & sourceReq.Field("RQ_USER_TEMPLATE_03"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceReqID & ": Missing application name")
                        badRecord = True

                    End If

                    ' Map these fields to the target values...

                    ' Requirement status...
                    Custom_State = ""

                    Select Case sourceReq.Field("RQ_USER_TEMPLATE_02")

                        Case "Accepted", "Approved", "Completed", "Deferred", "In Review", "Incorporated", "Non-compliant", "Obsolete", "Proposed", "Rejected"
                            Custom_State = sourceReq.Field("RQ_USER_TEMPLATE_02")
                        Case "Implement", "SIT", "UAT"
                            Custom_State = "Approved"
                        Case "Initiate"
                            Custom_State = "Proposed"
                        Case "Build"
                            Custom_State = "Accepted"
                        Case "Closed"
                            Custom_State = "Incorporated"
                        Case "Plan"
                            Custom_State = "In Review"
                        Case Else

                            reportWrite.WriteLine(sourceReqID & ": Invalid requirement state: '" & sourceReq.Field("RQ_USER_TEMPLATE_02") & "'")
                            badRecord = True

                    End Select

                    ' Requirement type...
                    Custom_Type = ""

                    Select Case sourceReq.Field("RQ_TYPE_ID")

                        Case "Undefined"
                            Custom_Type = "User Story"
                        Case "Functional"
                            Custom_Type = "System Functional"
                        Case "Business"
                            Custom_Type = "Business Functional"
                        Case "Testing", "Performance"
                            Custom_Type = "User Story"
                        Case Else

                            reportWrite.WriteLine(sourceReqID & ": Invalid requirement type: '" & sourceReq.Field("RQ_TYPE_ID") & "'")
                            badRecord = True

                    End Select

                    If badRecord = False Then

                        ' Check to see if the requirement is already in...look in Related ID field...

                        sqlString2 = "select RQ_REQ_ID from req where RQ_USER_08 = '" & sProject & "' and RQ_USER_04 = '" & sourceReqID & "'"

                        tdconCommand2 = tdconTarget.Command
                        tdconCommand2.CommandText = sqlString2
                        tdconRecSet2 = tdconCommand2.Execute

                        If tdconRecSet2.RecordCount > 0 Then

                            foundGood = False

                            If tdconRecSet2.RecordCount > 1 Then

                                ' As the source is hBBT ALM, we need to be sure there's only ONE active synch target...
                                ' If there is more than one, then there are dupes and we have to find the specific active one...

                                ndx2 = 1

                                While ndx2 <= tdconRecSet2.RecordCount

                                    tempReqID = tdconRecSet2.FieldValue(0)
                                    tempReq = tdconTargetReqFactory.Item(tempReqID)

                                    If tempReq.Field("RQ_USER_06") <> "Obsolete" Then

                                        ' Found a non-duplicate...exit the loop...
                                        foundGood = True
                                        Exit While

                                    End If

                                    tdconRecSet2.Next()

                                    ndx2 = ndx2 + 1

                                End While

                            Else

                                ' Just one record is already in...fetch it and check for updates...
                                foundGood = True
                                tempReqID = tdconRecSet2.FieldValue(0)
                                tempReq = tdconTargetReqFactory.Item(tempReqID)

                            End If

                            ' Correct source defect found...proceed with processing...

                            If foundGood Then

                                Try

                                    wasChanged = False

                                    ' Compare and change just what's changed so the audit table reads right...

                                    If tempReq.Field("RQ_USER_07") <> sProject Then
                                        tempReq.Field("RQ_USER_07") = sProject
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_COMMENT") <> sourceReq.Field("RQ_REQ_COMMENT") Then
                                        tempReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                                        wasChanged = True
                                    End If

                                    If Custom_Type <> "Business Functional" Then

                                        If tempReq.Field("RQ_REQ_STATUS") <> sourceReq.Field("RQ_REQ_STATUS") Then
                                            tempReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                                            wasChanged = True
                                        End If

                                    End If

                                    If tempReq.Field("RQ_USER_06") <> Custom_State Then
                                        tempReq.Field("RQ_USER_06") = Custom_State
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_01") <> sourceReq.Field("RQ_USER_TEMPLATE_05") Then
                                        tempReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_TEMPLATE_05")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_02") <> sourceReq.Field("RQ_USER_TEMPLATE_13") Then
                                        tempReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_TEMPLATE_13")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_03") <> sourceReq.Field("RQ_USER_TEMPLATE_03") Then
                                        tempReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_TEMPLATE_03")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_AUTHOR") <> sourceReq.Field("RQ_REQ_AUTHOR") Then
                                        If sourceReq.Field("RQ_REQ_AUTHOR") = "" Then
                                            tempReq.Field("RQ_REQ_AUTHOR") = "sv-alm-syncprod"
                                        Else
                                            tempReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                        End If
                                        tempReq.Field("RQ_USER_12") = tempReq.Field("RQ_REQ_AUTHOR")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_DATE") <> sourceReq.Field("RQ_REQ_DATE") Then
                                        tempReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_NAME") <> sourceReq.Field("RQ_REQ_NAME") Then

                                        origName = tempReq.Field("RQ_REQ_NAME")

                                        If origName.Contains(" - Duplicate # ") Then

                                            ' We don't rename duplicates...it causes issues later...

                                        Else

                                            ' If the name is unique, it can be renamed...

                                            tempReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                            wasChanged = True

                                        End If

                                    End If

                                    If tempReq.Field("RQ_REQ_PRIORITY") <> sourceReq.Field("RQ_REQ_PRIORITY") Then
                                        tempReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")
                                        wasChanged = True
                                    End If

                                    ' Post the requirement...
                                    If wasChanged Then

                                        tempReq.Post()
                                        reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " updated")

                                    End If

                                Catch ex As Exception

                                    reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " not updated: " & ex.Message)

                                End Try

                            Else

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not updated - more than one found active, or related requirement deleted!")

                            End If

                        Else

                            Try

                                ' It's not...create new from the fields...
                                newReq = tdconTargetReqFactory.AddItem(System.DBNull.Value)

                                newReq.Field("RQ_TYPE_ID") = Custom_Type

                                newReq.Field("RQ_USER_04") = sourceReq.ID
                                newReq.Field("RQ_USER_05") = curSource
                                newReq.Field("RQ_USER_07") = sProject
                                newReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")

                                newReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")

                                newReq.Field("RQ_USER_06") = Custom_State
                                newReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_TEMPLATE_05")
                                newReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_TEMPLATE_13")
                                newReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_TEMPLATE_03")

                                If sourceReq.Field("RQ_REQ_AUTHOR") = "" Then
                                    newReq.Field("RQ_REQ_AUTHOR") = "sv-alm-syncprod"
                                    newReq.Field("RQ_USER_12") = "sv-alm-syncprod"
                                Else
                                    newReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                    newReq.Field("RQ_USER_12") = sourceReq.Field("RQ_REQ_AUTHOR")
                                End If

                                newReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                newReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                newReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")

                                ' Post the requiremenet...

                                newReq.Post()
                                reportWrite.WriteLine(sourceReqID & ": New related ALM requirement created")

                                ' Now move it to the synch temp folder...

                                notMoved = True
                                dupeCount = 0
                                origName = newReq.Field("RQ_REQ_NAME")

                                While notMoved

                                    Try

                                        newReq.Move(moveToFolderID, -4)
                                        notMoved = False

                                    Catch ex As Exception

                                        ' Means one with that name is already in the SynchTemp...
                                        dupeCount = dupeCount + 1
                                        newReq.Field("RQ_REQ_NAME") = origName & " - Duplicate # " & dupeCount
                                        newReq.Post()

                                    End Try

                                End While

                                ' ...and now try moving it to the correct location...

                                Try

                                    moveToFolderID = setReqFolder(newReq.ID)
                                    newReq.Move(moveToFolderID, -4)

                                Catch ex2 As Exception

                                    reportWrite.WriteLine(sourceReqID & ": Related requirement not moved: " & ex2.Message)

                                End Try

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not created: " & ex.Message)

                            End Try

                        End If

                    End If

                    ' Update the status bars...

                    tdconRecSet.Next()

                    fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                End While

            End If

        Catch ex As Exception

            reportWrite.WriteLine("Error: Requirements not processed: " & ex.Message)

        End Try

    End Sub

    Sub processBBTALMTests(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        tdconTargetTestFactory = tdconTarget.TestFactory
        tdconSourceTestFactory = tdconSource.TestFactory

        curSource = "hBBT ALM"

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        testTreeMgr = tdconTarget.TreeManager
        workingFolder = testTreeMgr.NodeByPath("Subject\001_SynchTemp")
        moveToFolderID = workingFolder.NodeID
        tdconTargetTestFactory = workingFolder.TestFactory

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select ts_test_id from test where (ts_vts >= '" & checkFromDate & "' and ts_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and TS_USER_TEMPLATE_05 like '2022%' order by ts_test_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select ts_test_id from test where ts_vts > '" & lastChecked & "' and TS_USER_TEMPLATE_05 like '2022%' order by ts_test_id"

        End If

        Try

            tdconCommand = tdconSource.Command
            tdconCommand.CommandText = sqlString
            tdconRecSet = tdconCommand.Execute

            If tdconRecSet.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

                ndx1 = 1

                While ndx1 <= tdconRecSet.RecordCount

                    sourceTestID = tdconRecSet.FieldValue(0)
                    sourceTest = tdconSourceTestFactory.Item(sourceTestID)

                    RunStatus.Text = "Processing Test # " & sourceTestSet.ID & " from " & sProject & "..."
                    Application.DoEvents()

                    badRecord = False

                    ' Verify the straight assign fields...

                    If sourceTestSet.Field("TS_USER_TEMPLATE_04") <> "" Then

                        If projectName.Contains(sourceTestSet.Field("TS_USER_TEMPLATE_04")) Then
                            ' Project Name is right...
                        Else
                            ' Project Name is wrong...
                            reportWrite.WriteLine(sourceTestID & ": Invalid project name: " & sourceTestSet.Field("TS_USER_TEMPLATE_04"))
                            badRecord = True
                        End If

                    Else

                        ' Project Name is missing...
                        reportWrite.WriteLine(sourceTestID & ": Missing project name")
                        badRecord = True

                    End If

                    If sourceTestSet.Field("TS_USER_TEMPLATE_05") <> "" Then

                        If relName.Contains(sourceTestSet.Field("TS_USER_TEMPLATE_05")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceTestID & ": Invalid release name: " & sourceTestSet.Field("TS_USER_TEMPLATE_05"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceTestID & ": Missing release name")
                        badRecord = True

                    End If

                    If sourceTestSet.Field("TS_USER_TEMPLATE_15") <> "" Then

                        If appName.Contains(sourceTestSet.Field("TS_USER_TEMPLATE_15")) Then
                            ' Application Name is right...
                        Else
                            ' Application Name is wrong...
                            reportWrite.WriteLine(sourceTestID & ": Invalid application name: " & sourceTestSet.Field("TS_USER_TEMPLATE_15"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceTestID & ": Missing application name")
                        badRecord = True

                    End If

                    ' Map these fields to the target values...

                    If badRecord = False Then

                        ' Check to see if the Test is already in...look in Related ID field...

                        sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                        tdconCommand2 = tdconTarget.Command
                        tdconCommand2.CommandText = sqlString2
                        tdconRecSet2 = tdconCommand2.Execute

                        If tdconRecSet2.RecordCount > 0 Then

                            foundGood = False

                            If tdconRecSet2.RecordCount > 1 Then

                                ' As the source is hBBT ALM, we need to be sure there's only ONE active synch target...
                                ' If there is more than one, then there are dupes and we have to find the specific active one...

                                ndx2 = 1

                                While ndx2 <= tdconRecSet2.RecordCount

                                    tempTestID = tdconRecSet2.FieldValue(0)
                                    tempTest = tdconTargetTestFactory.Item(tempTestID)

                                    If tempTest.Field("TS_USER_06") <> "Obsolete" Then

                                        ' Found a non-duplicate...exit the loop...
                                        foundGood = True
                                        Exit While

                                    End If

                                    tdconRecSet2.Next()

                                    ndx2 = ndx2 + 1

                                End While

                            Else

                                ' Just one record is already in...fetch it and check for updates...
                                foundGood = True
                                tempTestID = tdconRecSet2.FieldValue(0)
                                tempTest = tdconTargetTestFactory.Item(tempTestID)

                            End If

                            ' Correct source defect found...proceed with processing...

                            If foundGood Then

                                Try

                                    wasChanged = False

                                    ' Compare and change just what's changed so the audit table reads right...

                                    If tempTest.Field("TS_USER_07") <> sProject Then
                                        tempTest.Field("TS_USER_07") = sProject
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_DESCRIPTION") <> sourceTestSet.Field("TS_DESCRIPTION") Then
                                        tempTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_EXEC_STATUS") <> sourceTestSet.Field("TS_EXEC_STATUS") Then
                                        tempTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_STATUS") <> sourceTestSet.Field("TS_STATUS") Then
                                        tempTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_DEV_COMMENTS") <> sourceTestSet.Field("TS_DEV_COMMENTS") Then
                                        tempTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_TYPE") <> sourceTestSet.Field("TS_TYPE") Then
                                        tempTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_01") <> sourceTestSet.Field("TS_USER_TEMPLATE_04") Then
                                        tempTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_TEMPLATE_04")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_02") <> sourceTestSet.Field("TS_USER_TEMPLATE_05") Then
                                        tempTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_TEMPLATE_05")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_03") <> sourceTestSet.Field("TS_USER_TEMPLATE_15") Then
                                        tempTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_TEMPLATE_15")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_12") <> sourceTestSet.Field("TS_USER_TEMPLATE_03") Then
                                        tempTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_TEMPLATE_03")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_RESPONSIBLE") <> sourceTestSet.Field("TS_RESPONSIBLE") Then
                                        If sourceTestSet.Field("TS_RESPONSIBLE") = "" Then
                                            tempTest.Field("TS_RESPONSIBLE") = "sv-alm-syncprod"
                                        Else
                                            tempTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")
                                        End If
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_CREATION_DATE") <> sourceTestSet.Field("TS_CREATION_DATE") Then
                                        tempTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_NAME") <> sourceTestSet.Field("TS_NAME") Then

                                        origName = tempTest.Field("TS_NAME")

                                        If origName.Contains(" - Duplicate # ") Then

                                            ' We don't rename duplicates...it causes issues later...

                                        Else

                                            ' If the name is unique, it can be renamed...

                                            tempTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")
                                            wasChanged = True

                                        End If

                                    End If

                                    ' Post the test...
                                    If wasChanged Then

                                        tempTest.Post()
                                        reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " updated")

                                    End If

                                    ' Test processed...now work with the Design Steps...

                                    If sourceTestSet.DesStepsNum > 0 Then

                                        ' This test has design steps...see if there were changes...

                                        Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                    End If

                                    ' If Automated Tests option selected, perform the repo copy...

                                    If doAutoTests.Checked Then

                                        Try

                                            RunStatus.Text = "Starting the test repo copy..."
                                            Application.DoEvents()

                                            sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                            testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                            sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                            sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                            ' Bring locally the test's repo...
                                            testSourceExtendedStorage.Load("-r *.*", True)

                                            testTargetExtendedStorage = newTest.ExtendedStorage

                                            targetTestClientPath = testTargetExtendedStorage.ClientPath
                                            targetTestServerPath = testTargetExtendedStorage.ServerPath

                                            testTargetExtendedStorage.Load("-r *.*", True)

                                            ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                            My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                            ' Save the repo...
                                            testTargetExtendedStorage.Save("-r *.*", True)

                                            tempTest.Post()

                                            ' If successful, delete the local copies to keep space usage low...

                                            My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                            My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                        Catch ex2 As Exception

                                            reportWrite.WriteLine(sourceTestID & ": Related Test's repo not updated:", ex2.Message)

                                        End Try

                                    End If

                                Catch ex As Exception

                                    reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " not updated: " & ex.Message)

                                End Try

                            Else

                                reportWrite.WriteLine(sourceTestID & ": Related Test not updated - more than one found active, or related Test deleted!")

                            End If

                        Else

                            Try

                                ' It's not...create new from the fields...
                                newTest = tdconTargetTestFactory.AddItem(System.DBNull.Value)

                                newTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")

                                newTest.Field("TS_USER_04") = sourceTestSet.ID
                                newTest.Field("TS_USER_05") = curSource
                                newTest.Field("TS_USER_07") = sProject
                                newTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_TEMPLATE_03")
                                newTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                newTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")

                                newTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                newTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")

                                newTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_TEMPLATE_04")
                                newTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_TEMPLATE_05")
                                newTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_TEMPLATE_15")
                                newTest.Field("TS_USER_25") = "N/A"

                                If sourceTestSet.Field("TS_RESPONSIBLE") = "" Then
                                    newTest.Field("TS_RESPONSIBLE") = "sv-alm-syncprod"
                                Else
                                    newTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")
                                End If

                                newTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                newTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")

                                ' Post the test...

                                newTest.Post()
                                reportWrite.WriteLine(sourceTestID & ": New related ALM Test created")

                                ' ...and now move it to the correct location...

                                moveToFolderID = setTestFolder(newTest.ID)

                                tempTestID = newTest.ID
                                sqlString = "update test set ts_subject = " & moveToFolderID & " where ts_test_id = " & tempTestID

                                tdconCommand2 = tdconTarget.Command
                                tdconCommand2.CommandText = sqlString
                                tdconRecSet2 = tdconCommand2.Execute

                                ' Test created...now work with the Design Steps...

                                If sourceTestSet.DesStepsNum > 0 Then

                                    ' This test has design steps...see if there were changes...

                                    Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                End If

                                ' If Automated Tests option selected, perform the repo copy...

                                If doAutoTests.Checked Then

                                    Try

                                        RunStatus.Text = "Starting the test repo copy..."
                                        Application.DoEvents()

                                        sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                        testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                        sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                        sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                        ' Bring locally the test's repo...
                                        testSourceExtendedStorage.Load("-r *.*", True)

                                        testTargetExtendedStorage = newTest.ExtendedStorage

                                        targetTestClientPath = testTargetExtendedStorage.ClientPath
                                        targetTestServerPath = testTargetExtendedStorage.ServerPath

                                        testTargetExtendedStorage.Load("-r *.*", True)

                                        ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                        My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                        ' Save the repo...
                                        testTargetExtendedStorage.Save("-r *.*", True)

                                        newTest.Post()

                                        ' If successful, delete the local copies to keep space usage low...

                                        My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                        My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                    Catch ex2 As Exception

                                        reportWrite.WriteLine(sourceTestID & ": Related Test's repo not created:", ex2.Message)

                                    End Try

                                End If

                                ' Link test to requirement...

                                ' testNum = newTest.ID
                                ' Call AddTestToCoverage(reqNum, testNum)

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestID & ": Related Test not created: " & ex.Message)

                            End Try

                        End If

                    End If

                    ' Update the status bars...

                    tdconRecSet.Next()

                    fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                End While

            End If

        Catch ex As Exception

            reportWrite.WriteLine("Error: Tests not processed: " & ex.Message)

        End Try

    End Sub

    Sub processBBTALMTestSets(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        curSource = "hBBT ALM"

        tdconTargetTestFactory = tdconTarget.TestFactory

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        tdconTargetTSFolderFactory = tdconTarget.TestLabFolderFactory
        targetTSFilter = tdconTargetTSFolderFactory.Filter
        targetTSFilter.Filter("CF_ITEM_NAME") = "001_SynchTemp"

        targetTSFList = targetTSFilter.NewList()

        If targetTSFList.Count > 0 Then

            targetTestSetFolder = targetTSFList.Item(1)
            tdconTargetTestSetFactory = targetTestSetFolder.TestSetFactory

        End If

        tdconSourceTestSetFactory = tdconSource.TestSetFactory

        ' Get the list of test sets modified in the source since the last run or by the specified date range...

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select cy_cycle_id from cycle where (cy_vts >= '" & checkFromDate & "' and cy_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and CY_USER_TEMPLATE_03 like '2022%' order by cy_cycle_id"

        Else

            ' Just fetch all test sets in the current source since the last run...

            sqlString = "select cy_cycle_id from cycle where cy_vts > '" & lastChecked & "' and CY_USER_TEMPLATE_03 like '2022%' order by cy_cycle_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestSetID = tdconRecSet.FieldValue(0)
                sourceTestSet = tdconSourceTestSetFactory.Item(sourceTestSetID)

                RunStatus.Text = "Processing Test Set # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("CY_USER_TEMPLATE_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("CY_USER_TEMPLATE_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid project name: " & sourceTestSet.Field("CY_USER_TEMPLATE_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_TEMPLATE_03") <> "" Then

                    If relName.Contains(sourceTestSet.Field("CY_USER_TEMPLATE_03")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid release name: " & sourceTestSet.Field("CY_USER_TEMPLATE_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_TEMPLATE_04") <> "" Then

                    If appName.Contains(sourceTestSet.Field("CY_USER_TEMPLATE_04")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid application name: " & sourceTestSet.Field("CY_USER_TEMPLATE_04"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing application name")
                    badRecord = True

                End If

                ' Test Phase...
                Custom_TestPhase = "UAT"

                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test Set is already in...look in Related ID field...

                    sqlString2 = "select CY_CYCLE_ID from Cycle where CY_USER_08 = '" & sProject & "' and CY_USER_04 = '" & sourceTestID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        ' Just one record is already in...fetch it and check for updates...

                        foundGood = True
                        tempTestSetID = tdconRecSet2.FieldValue(0)
                        tempTestSet = tdconTargetTestFactory.Item(tempTestSetID)

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTestSet.Field("CY_CYCLE") <> sourceTestSet.Field("CY_CYCLE") Then
                                    tempTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_SUBTYPE_ID") <> sourceTestSet.Field("CY_SUBTYPE_ID") Then
                                    tempTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_STATUS") <> sourceTestSet.Field("CY_STATUS") Then
                                    tempTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_COMMENT") <> sourceTestSet.Field("CY_COMMENT") Then
                                    tempTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_TYPE") <> sourceTestSet.Field("CY_TYPE") Then
                                    tempTestSet.Field("CY_TYPE") = sourceTestSet.Field("CY_TYPE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_01") <> sourceTestSet.Field("CY_USER_TEMPLATE_01") Then
                                    tempTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_TEMPLATE_01")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_02") <> sourceTestSet.Field("CY_USER_TEMPLATE_03") Then
                                    tempTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_TEMPLATE_03")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_03") <> sourceTestSet.Field("CY_USER_TEMPLATE_04") Then
                                    tempTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_TEMPLATE_04")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_04") <> sourceTestSet.ID Then
                                    tempTestSet.Field("CY_USER_04") = sourceTestSet.ID
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_05") <> curSource Then
                                    tempTestSet.Field("CY_USER_05") = curSource
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_08") <> sProject Then
                                    tempTestSet.Field("CY_USER_08") = sProject
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_07") <> Custom_TestPhase Then
                                    tempTestSet.Field("CY_USER_07") = Custom_TestPhase
                                    wasChanged = True
                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTestSet.Post()
                                    reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestSetID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test Set not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' Create new test set from the fields...
                            newTestSet = tdconTargetTestSetFactory.AddItem(System.DBNull.Value)

                            newTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                            newTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")

                            newTestSet.Field("CY_USER_04") = sourceTestSet.ID
                            newTestSet.Field("CY_USER_05") = curSource
                            newTestSet.Field("CY_USER_07") = Custom_TestPhase
                            newTestSet.Field("CY_USER_08") = sProject
                            newTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")

                            newTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")

                            newTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_TEMPLATE_01")
                            newTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_TEMPLATE_03")
                            newTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_TEMPLATE_04")

                            ' Post the test set...

                            newTestSet.Post()

                            reportWrite.WriteLine(sourceTestSetID & ": New related ALM Test Set created")

                            ' ...now loop over the source test set test factory to add known ones to this new test set...

                            sourceTSTFactory = sourceTestSet.TSTestFactory
                            sourceTSTFList = sourceTSTFactory.NewList("")

                            targetTSTFactory = newTestSet.TSTestFactory

                            For Each sourceTSTest In sourceTSTFList

                                sourceTestID = sourceTSTest.TestId

                                ' See if this test is already in the target...

                                sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                                tdconCommand2 = tdconTarget.Command
                                tdconCommand2.CommandText = sqlString2
                                tdconRecSet2 = tdconCommand2.Execute

                                If tdconRecSet2.RecordCount > 0 Then

                                    ' Found the test...

                                    tempTestID = tdconRecSet2.FieldValue(0)
                                    tempTest = tdconTargetTestFactory.Item(tempTestID)

                                    targetTSTFactory.AddItem(tempTest)

                                Else

                                    RunStatus.Text = "Error:  Source test # " & sourceTestID & " not found in target..."
                                    Application.DoEvents()

                                End If

                            Next

                            ' ...and now move it to the correct folder...

                            RunStatus.Text = "Moving the test set from the temp synch folder..."
                            Application.DoEvents()

                            moveToFolderID = setTestSetFolder(newTestSet.ID)

                            tempTestSetID = newTestSet.ID
                            sqlString = "update cycle set cy_folder_id = " & moveToFolderID & " where cy_cycle_id = " & tempTestSetID

                            tdconCommand2 = tdconTarget.Command
                            tdconCommand2.CommandText = sqlString
                            tdconRecSet2 = tdconCommand2.Execute

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub
    Sub processBBTALMDefects(sDomain, sProject)

        Dim foundGood As Boolean

        curSource = "hBBT ALM"

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select bg_bug_id from bug where (bg_vts >= '" & checkFromDate & "' and bg_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and BG_USER_TEMPLATE_48 like '2022%' order by bg_bug_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select bg_bug_id from bug where bg_vts > '" & lastChecked & "' and BG_USER_TEMPLATE_48 like '2022%' order by bg_bug_id"

        End If

        Try

            tdconCommand = tdconSource.Command
            tdconCommand.CommandText = sqlString
            tdconRecSet = tdconCommand.Execute

            If tdconRecSet.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

                ndx1 = 1

                While ndx1 <= tdconRecSet.RecordCount

                    sourceBugID = tdconRecSet.FieldValue(0)
                    sourceBug = tdconSource.BugFactory.Item(sourceBugID)

                    RunStatus.Text = "Processing defect # " & sourceBug.ID & " from " & sProject & "..."
                    Application.DoEvents()

                    badRecord = False

                    ' Verify the straight assign fields...

                    If sourceBug.Field("BG_USER_TEMPLATE_15") <> "" Then

                        If projectName.Contains(sourceBug.Field("BG_USER_TEMPLATE_15")) Then
                            ' Project Name is right...
                        Else
                            ' Project Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid project name: " & sourceBug.Field("BG_USER_TEMPLATE_15"))
                            badRecord = True
                        End If

                    Else

                        ' Project Name is missing...
                        reportWrite.WriteLine(sourceBugID & ": Missing project name")
                        badRecord = True

                    End If

                    If sourceBug.Field("BG_USER_TEMPLATE_48") <> "" Then

                        If relName.Contains(sourceBug.Field("BG_USER_TEMPLATE_48")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid release name: " & sourceBug.Field("BG_USER_TEMPLATE_48"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceBugID & ": Missing release name")
                        badRecord = True

                    End If

                    If sourceBug.Field("BG_USER_TEMPLATE_30") <> "" Then

                        If appName.Contains(sourceBug.Field("BG_USER_TEMPLATE_30")) Then
                            ' Application Name is right...
                        Else
                            ' Application Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid application name: " & sourceBug.Field("BG_USER_TEMPLATE_30"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceBugID & ": Missing application name")
                        badRecord = True

                    End If

                    ' Map these fields to the target values...

                    ' Defect status...
                    Custom_State = ""

                    Select Case sourceBug.Field("BG_STATUS")

                        Case "New", "Closed", "Deferred", "Fixed", "Open", "Rejected", "Retest"
                            Custom_State = sourceBug.Field("BG_STATUS")
                        Case "Active", "Plan", "SIT", "UAT"
                            Custom_State = "Open"
                        Case "Initiate"
                            Custom_State = "New"
                        Case "Resolved"
                            Custom_State = "Closed"
                        Case "Bug Deferred"
                            Custom_State = "Deferred"
                        Case "Bug Reject"
                            Custom_State = "Rejected"
                        Case "Build", "Ready for Test"
                            Custom_State = "Fixed"
                        Case "Implement", "Ready for SIT", "Ready for UAT", "Test"
                            Custom_State = "Retest"
                        Case Else

                            reportWrite.WriteLine(sourceBugID & ": Invalid defect state: '" & sourceBug.Field("BG_STATUS") & "'")
                            badRecord = True

                    End Select

                    ' Test Phase...
                    Custom_TestPhase = ""

                    Select Case sourceBug.Field("BG_USER_TEMPLATE_18")
                        Case "Pre-SIT", "SIT", "UAT", "Regression", "Security", "Performance – PLT Only", "Dress Rehearsal", "Production", "Warranty"
                            Custom_TestPhase = sourceBug.Field("BG_USER_TEMPLATE_18")
                        Case "Pilot"
                            Custom_TestPhase = "Dress Rehearsal"
                        Case "Re-execution"
                            Custom_TestPhase = "Regression"
                        Case Else

                            reportWrite.WriteLine(sourceBugID & ": Invalid test phase: '" & sourceBug.Field("BG_USER_TEMPLATE_18") & "'")
                            badRecord = True

                    End Select

                    If badRecord = False Then

                        ' Check to see if the defect is already in...look in Related ID field...

                        sqlString2 = "select BG_BUG_ID from bug where BG_USER_07 = '" & sProject & "' and BG_USER_04 = '" & sourceBugID & "'"

                        tdconCommand2 = tdconTarget.Command
                        tdconCommand2.CommandText = sqlString2
                        tdconRecSet2 = tdconCommand2.Execute

                        If tdconRecSet2.RecordCount > 0 Then

                            foundGood = False

                            If tdconRecSet2.RecordCount > 1 Then

                                ' As the source is hBBT ALM, we need to be sure there's only ONE active synch target...
                                ' If there is more than one, then there are dupes and we have to find the specific active one...

                                ndx2 = 1

                                While ndx2 <= tdconRecSet2.RecordCount

                                    tempBugID = tdconRecSet2.FieldValue(0)
                                    tempBug = tdconTarget.BugFactory.Item(tempBugID)

                                    If tempBug.Field("BG_USER_13") <> "Duplicate Defect" Then

                                        ' Found a non-duplicate...exit the loop...
                                        foundGood = True
                                        Exit While

                                    End If

                                    tdconRecSet2.Next()

                                    ndx2 = ndx2 + 1

                                End While

                            Else

                                ' Just one record is already in...fetch it and check for updates...
                                foundGood = True
                                tempBugID = tdconRecSet2.FieldValue(0)
                                tempBug = tdconTarget.BugFactory.Item(tempBugID)

                            End If

                            ' Correct source defect found...proceed with processing...

                            If foundGood Then

                                Try

                                    wasChanged = False

                                    'Compare and change just what's changed so the audit table reads right...

                                    If tempBug.Field("BG_USER_07") <> sProject Then
                                        tempBug.Field("BG_USER_07") = sProject
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_DESCRIPTION") <> sourceBug.Field("BG_DESCRIPTION") Then
                                        tempBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_STATUS") <> Custom_State Then
                                        tempBug.Field("BG_STATUS") = Custom_State
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_01") <> sourceBug.Field("BG_USER_TEMPLATE_15") Then
                                        tempBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_TEMPLATE_15")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_02") <> sourceBug.Field("BG_USER_TEMPLATE_48") Then
                                        tempBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_TEMPLATE_48")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_03") <> sourceBug.Field("BG_USER_TEMPLATE_30") Then
                                        tempBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_TEMPLATE_30")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_DETECTED_BY") <> sourceBug.Field("BG_DETECTED_BY") Then
                                        If sourceBug.Field("BG_DETECTED_BY") = "" Then
                                            tempBug.Field("BG_DETECTED_BY") = "sv-alm-syncprod"
                                        Else
                                            tempBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                        End If
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_DETECTION_DATE") <> sourceBug.Field("BG_DETECTION_DATE") Then
                                        tempBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_13") <> Custom_TestPhase Then
                                        tempBug.Field("BG_USER_13") = Custom_TestPhase
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_14") <> sourceBug.Field("BG_USER_TEMPLATE_50") Then
                                        tempBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_TEMPLATE_50")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_15") <> sourceBug.Field("BG_USER_TEMPLATE_38") Then
                                        tempBug.Field("BG_USER_15") = sourceBug.Field("BG_USER_TEMPLATE_38")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_16") <> sourceBug.Field("BG_USER_TEMPLATE_49") Then
                                        tempBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_TEMPLATE_49")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_SEVERITY") <> sourceBug.Field("BG_SEVERITY") Then
                                        tempBug.Field("BG_SEVERITY") = sourceBug.Field("BG_SEVERITY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_SUMMARY") <> sourceBug.Field("BG_SUMMARY") Then
                                        tempBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_RESPONSIBLE") <> sourceBug.Field("BG_RESPONSIBLE") Then
                                        tempBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_PRIORITY") <> sourceBug.Field("BG_PRIORITY") Then
                                        tempBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_CLOSING_DATE") <> sourceBug.Field("BG_CLOSING_DATE") Then
                                        tempBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")
                                        wasChanged = True
                                    End If

                                    ' Post the defect...
                                    If wasChanged Then

                                        tempBug.Post()
                                        reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " updated")

                                    End If

                                Catch ex As Exception

                                    reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " not updated: " & ex.Message)

                                End Try

                            Else

                                reportWrite.WriteLine(sourceBugID & ": Related defect not updated - more than one found active, or related defect deleted!")

                            End If

                        Else

                            Try

                                ' It's not...create new from the fields...
                                newBug = tdconTarget.BugFactory.AddItem(System.DBNull.Value)

                                newBug.Field("BG_USER_04") = sourceBug.ID
                                newBug.Field("BG_USER_05") = curSource
                                newBug.Field("BG_USER_07") = sProject
                                newBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                newBug.Field("BG_STATUS") = Custom_State
                                newBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_TEMPLATE_15")
                                newBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_TEMPLATE_48")
                                newBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_TEMPLATE_30")

                                If sourceBug.Field("BG_DETECTED_BY") = "" Then
                                    newBug.Field("BG_DETECTED_BY") = "sv-alm-syncprod"
                                Else
                                    newBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                End If

                                newBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                newBug.Field("BG_USER_13") = Custom_TestPhase
                                newBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_TEMPLATE_50")
                                newBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_TEMPLATE_49")
                                newBug.Field("BG_SEVERITY") = sourceBug.Field("BG_SEVERITY")
                                newBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                newBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                newBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                                newBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")

                                ' Post the defect...

                                newBug.Post()
                                reportWrite.WriteLine(sourceBugID & ": New related ALM defect created")

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceBugID & ": Related defect not created: " & ex.Message)

                            End Try

                        End If

                    End If

                    ' Update the status bars...

                    tdconRecSet.Next()

                    fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                End While

            End If

        Catch ex As Exception

            reportWrite.WriteLine("Error: Defects not processed: " & ex.Message)

        End Try

    End Sub

    Sub processSTRHALMReqs(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount As Integer

        curSource = "hSTI ALM"

        ' Set the initial destination for all new requirements to the 001_SynchTemp folder...

        tdconTargetReqFactory = tdconTarget.ReqFactory
        tdconSourceReqFactory = tdconSource.ReqFactory

        curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", "001_SynchTemp", 16)
        tempString = curLocation.Item(1)
        tempArray = Split(tempString, ",")
        moveToFolderID = tempArray(0)

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select rq_req_id from req where (rq_vts >= '" & checkFromDate & "' and rq_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%' order by rq_req_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select rq_req_id from req where rq_vts > '" & lastChecked & "' and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%' order by rq_req_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceReqID = tdconRecSet.FieldValue(0)
                sourceReq = tdconSourceReqFactory.Item(sourceReqID)

                RunStatus.Text = "Processing requirement # " & sourceReq.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceReq.Field("RQ_USER_01") <> "" Then

                    If projectName.Contains(sourceReq.Field("RQ_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid project name: " & sourceReq.Field("RQ_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing project name")
                    badRecord = True

                End If

                If sourceReq.Field("RQ_USER_02") <> "" Then

                    If relName.Contains(sourceReq.Field("RQ_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid release name: " & sourceReq.Field("RQ_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing release name")
                    badRecord = True

                End If

                If sourceReq.Field("RQ_USER_03") <> "" Then

                    If appName.Contains(sourceReq.Field("RQ_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid application name: " & sourceReq.Field("RQ_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                ' Requirement status...
                Custom_State = ""

                Select Case sourceReq.Field("RQ_USER_04")

                    Case "Accepted", "Approved", "Completed", "Deferred", "In Review", "Incorporated", "Non-compliant", "Obsolete", "Proposed", "Rejected"
                        Custom_State = sourceReq.Field("RQ_USER_04")

                    Case Else

                        reportWrite.WriteLine(sourceReqID & ": Invalid requirement state: '" & sourceReq.Field("RQ_USER_04") & "'")
                        badRecord = True

                End Select

                ' Requirement status...
                Custom_Type = ""

                Select Case sourceReq.Field("RQ_TYPE_ID")

                    Case "Functional"
                        Custom_Type = "System Functional"
                    Case "Business"
                        Custom_Type = "Business Functional"
                    Case "Testing", "Performance"
                        Custom_Type = "User Story"
                    Case Else

                        reportWrite.WriteLine(sourceReqID & ": Invalid requirement type: '" & sourceReq.Field("RQ_TYPE_ID") & "'")
                        badRecord = True

                End Select

                If badRecord = False Then

                    ' Check to see if the requirement is already in...look in Related ID field...

                    sqlString2 = "select RQ_REQ_ID from req where RQ_USER_08 = '" & sProject & "' and RQ_USER_04 = '" & sourceReqID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet2.RecordCount > 1 Then

                            ' As the source is STRH ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet2.RecordCount

                                tempReqID = tdconRecSet2.FieldValue(0)
                                tempReq = tdconTargetReqFactory.Item(tempReqID)

                                If tempReq.Field("RQ_USER_06") <> "Obsolete" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet2.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempReqID = tdconRecSet2.FieldValue(0)
                            tempReq = tdconTargetReqFactory.Item(tempReqID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempReq.Field("RQ_USER_07") <> sProject Then
                                    tempReq.Field("RQ_USER_07") = sProject
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_COMMENT") <> sourceReq.Field("RQ_REQ_COMMENT") Then
                                    tempReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_STATUS") <> sourceReq.Field("RQ_REQ_STATUS") Then
                                    tempReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_06") <> Custom_State Then
                                    tempReq.Field("RQ_USER_06") = Custom_State
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_01") <> sourceReq.Field("RQ_USER_01") Then
                                    tempReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_02") <> sourceReq.Field("RQ_USER_02") Then
                                    tempReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_03") <> sourceReq.Field("RQ_USER_03") Then
                                    tempReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_AUTHOR") <> sourceReq.Field("RQ_REQ_AUTHOR") Then
                                    If sourceReq.Field("RQ_REQ_AUTHOR") = "" Then
                                        tempReq.Field("RQ_REQ_AUTHOR") = "sv-alm-syncprod"
                                    Else
                                        tempReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                    End If
                                    tempReq.Field("RQ_USER_12") = tempReq.Field("RQ_REQ_AUTHOR")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_DATE") <> sourceReq.Field("RQ_REQ_DATE") Then
                                    tempReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_NAME") <> sourceReq.Field("RQ_REQ_NAME") Then

                                    origName = tempReq.Field("RQ_REQ_NAME")

                                    If origName.Contains(" - Duplicate # ") Then

                                        ' We don't rename duplicates...it causes issues later...

                                    Else

                                        ' If the name is unique, it can be renamed...

                                        tempReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                        wasChanged = True

                                    End If

                                End If

                                If tempReq.Field("RQ_REQ_PRIORITY") <> sourceReq.Field("RQ_REQ_PRIORITY") Then
                                    tempReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")
                                    wasChanged = True
                                End If

                                ' Post the requirement...
                                If wasChanged Then

                                    tempReq.Post()
                                    reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceReqID & ": Related requirement not updated - more than one found active, or related requirement deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newReq = tdconTargetReqFactory.AddItem(System.DBNull.Value)

                            newReq.Field("RQ_TYPE_ID") = Custom_Type

                            newReq.Field("RQ_USER_04") = sourceReq.ID
                            newReq.Field("RQ_USER_05") = curSource
                            newReq.Field("RQ_USER_07") = sProject
                            newReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                            newReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")

                            newReq.Field("RQ_USER_06") = Custom_State
                            newReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                            newReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                            newReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")

                            newReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                            newReq.Field("RQ_USER_12") = sourceReq.Field("RQ_REQ_AUTHOR")

                            newReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                            newReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                            newReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")

                            ' Post the requirement...

                            newReq.Post()
                            reportWrite.WriteLine(sourceReqID & ": New related ALM requirement created")

                            ' Now move it to the synch temp folder...

                            notMoved = True
                            dupeCount = 0
                            origName = newReq.Field("RQ_REQ_NAME")

                            While notMoved

                                Try

                                    newReq.Move(moveToFolderID, -4)
                                    notMoved = False

                                Catch ex As Exception

                                    ' Means one with that name is already in the SynchTemp...
                                    dupeCount = dupeCount + 1
                                    newReq.Field("RQ_REQ_NAME") = origName & " - Duplicate # " & dupeCount
                                    newReq.Post()

                                End Try

                            End While

                            ' ...and now try moving it to the correct location...

                            Try

                                moveToFolderID = setReqFolder(newReq.ID)
                                newReq.Move(moveToFolderID, -4)

                            Catch ex2 As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not moved: " & ex2.Message)

                            End Try

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceReqID & ": Related requirement not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTRHALMTests(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        tdconTargetTestFactory = tdconTarget.TestFactory
        tdconSourceTestFactory = tdconSource.TestFactory

        curSource = "hSTI ALM"

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        testTreeMgr = tdconTarget.TreeManager
        workingFolder = testTreeMgr.NodeByPath("Subject\001_SynchTemp")
        moveToFolderID = workingFolder.NodeID
        tdconTargetTestFactory = workingFolder.TestFactory

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select ts_test_id from test where (ts_vts >= '" & checkFromDate & "' and ts_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and TS_USER_02 like '2022%' order by ts_test_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select ts_test_id from test where ts_vts > '" & lastChecked & "' and TS_USER_02 like '2022%' order by ts_test_id"

        End If

        sqlString = "select ts_test_id from test where ts_vts > '" & lastChecked & "' and TS_USER_02 like '2022%' order by ts_test_id"

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestID = tdconRecSet.FieldValue(0)
                sourceTest = tdconSourceTestFactory.Item(sourceTestID)

                RunStatus.Text = "Processing Test # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("TS_USER_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("TS_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid project name: " & sourceTestSet.Field("TS_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("TS_USER_02") <> "" Then

                    If relName.Contains(sourceTestSet.Field("TS_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid release name: " & sourceTestSet.Field("TS_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("TS_USER_03") <> "" Then

                    If appName.Contains(sourceTestSet.Field("TS_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid application name: " & sourceTestSet.Field("TS_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test is already in...look in Related ID field...

                    sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet2.RecordCount > 1 Then

                            ' As the source is STRH ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet2.RecordCount

                                tempTestID = tdconRecSet2.FieldValue(0)
                                tempTest = tdconTargetTestFactory.Item(tempTestID)

                                If tempTest.Field("TS_USER_06") <> "Obsolete" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet2.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempTestID = tdconRecSet2.FieldValue(0)
                            tempTest = tdconTargetTestFactory.Item(tempTestID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTest.Field("TS_USER_07") <> sProject Then
                                    tempTest.Field("TS_USER_07") = sProject
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_DESCRIPTION") <> sourceTestSet.Field("TS_DESCRIPTION") Then
                                    tempTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_EXEC_STATUS") <> sourceTestSet.Field("TS_EXEC_STATUS") Then
                                    tempTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_STATUS") <> sourceTestSet.Field("TS_STATUS") Then
                                    tempTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_DEV_COMMENTS") <> sourceTestSet.Field("TS_DEV_COMMENTS") Then
                                    tempTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_TYPE") <> sourceTestSet.Field("TS_TYPE") Then
                                    tempTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_01") <> sourceTestSet.Field("TS_USER_01") Then
                                    tempTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_02") <> sourceTestSet.Field("TS_USER_02") Then
                                    tempTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_03") <> sourceTestSet.Field("TS_USER_03") Then
                                    tempTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_12") <> sourceTestSet.Field("TS_USER_04") Then
                                    tempTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_04")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_25") <> sourceTestSet.Field("TS_USER_25") Then
                                    tempTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_25")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_RESPONSIBLE") <> sourceTestSet.Field("TS_RESPONSIBLE") Then
                                    tempTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_CREATION_DATE") <> sourceTestSet.Field("TS_CREATION_DATE") Then
                                    tempTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_NAME") <> sourceTestSet.Field("TS_NAME") Then

                                    origName = tempTest.Field("TS_NAME")

                                    If origName.Contains(" - Duplicate # ") Then

                                        ' We don't rename duplicates...it causes issues later...

                                    Else

                                        ' If the name is unique, it can be renamed...

                                        tempTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")
                                        wasChanged = True

                                    End If

                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTest.Post()
                                    reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " updated")

                                End If

                                ' Test processed...now work with the Design Steps...

                                If sourceTestSet.DesStepsNum > 0 Then

                                    ' This test has design steps...see if there were changes...

                                    Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                End If


                                ' If Automated Tests option selected, perform the repo copy...

                                If doAutoTests.Checked Then

                                    Try

                                        RunStatus.Text = "Starting the test repo copy..."
                                        Application.DoEvents()

                                        sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                        testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                        sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                        sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                        ' Bring locally the test's repo...
                                        testSourceExtendedStorage.Load("-r *.*", True)

                                        testTargetExtendedStorage = newTest.ExtendedStorage

                                        targetTestClientPath = testTargetExtendedStorage.ClientPath
                                        targetTestServerPath = testTargetExtendedStorage.ServerPath

                                        testTargetExtendedStorage.Load("-r *.*", True)

                                        ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                        My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                        ' Save the repo...
                                        testTargetExtendedStorage.Save("-r *.*", True)

                                        tempTest.Post()

                                        ' If successful, delete the local copies to keep space usage low...

                                        My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                        My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                    Catch ex2 As Exception

                                        reportWrite.WriteLine(sourceTestID & ": Related Test's repo not updated:", ex2.Message)

                                    End Try

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestID & ": Related Test not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newTest = tdconTargetTestFactory.AddItem(System.DBNull.Value)

                            newTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")

                            newTest.Field("TS_USER_04") = sourceTestSet.ID
                            newTest.Field("TS_USER_05") = curSource
                            newTest.Field("TS_USER_07") = sProject
                            newTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_04")
                            newTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                            newTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")

                            newTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                            newTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")

                            newTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                            newTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                            newTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")

                            If sourceTestSet.Field("TS_USER_25") = "" Then
                                newTest.Field("TS_USER_25") = "N/A"
                            Else
                                newTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_25")
                            End If

                            newTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")

                            newTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                            newTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")

                            ' Post the test...

                            newTest.Post()
                            reportWrite.WriteLine(sourceTestID & ": New related ALM Test created")

                            ' ...and now move it to the correct location...

                            moveToFolderID = setTestFolder(newTest.ID)

                            tempTestID = newTest.ID
                            sqlString = "update test set ts_subject = " & moveToFolderID & " where ts_test_id = " & tempTestID

                            tdconCommand2 = tdconTarget.Command
                            tdconCommand2.CommandText = sqlString
                            tdconRecSet2 = tdconCommand2.Execute

                            ' Test created...now work with the Design Steps...

                            If sourceTestSet.DesStepsNum > 0 Then

                                ' This test has design steps...see if there were changes...

                                Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                            End If

                            ' If Automated Tests option selected, perform the repo copy...

                            If doAutoTests.Checked Then

                                Try

                                    RunStatus.Text = "Starting the test repo copy..."
                                    Application.DoEvents()

                                    sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                    testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                    sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                    sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                    ' Bring locally the test's repo...
                                    testSourceExtendedStorage.Load("-r *.*", True)

                                    testTargetExtendedStorage = newTest.ExtendedStorage

                                    targetTestClientPath = testTargetExtendedStorage.ClientPath
                                    targetTestServerPath = testTargetExtendedStorage.ServerPath

                                    testTargetExtendedStorage.Load("-r *.*", True)

                                    ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                    My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                    ' Save the repo...
                                    testTargetExtendedStorage.Save("-r *.*", True)

                                    newTest.Post()

                                    ' If successful, delete the local copies to keep space usage low...

                                    My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                    My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                Catch ex2 As Exception

                                    reportWrite.WriteLine(sourceTestID & ": Related Test's repo not created:", ex2.Message)

                                End Try

                            End If

                            ' Link test to requirement...

                            ' testNum = newTest.ID
                            ' Call AddTestToCoverage(reqNum, testNum)

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTRHALMTestSets(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        curSource = "hBBT ALM"

        tdconTargetTestFactory = tdconTarget.TestFactory

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        tdconTargetTSFolderFactory = tdconTarget.TestLabFolderFactory
        targetTSFilter = tdconTargetTSFolderFactory.Filter
        targetTSFilter.Filter("CF_ITEM_NAME") = "001_SynchTemp"

        targetTSFList = targetTSFilter.NewList()

        If targetTSFList.Count > 0 Then

            targetTestSetFolder = targetTSFList.Item(1)
            tdconTargetTestSetFactory = targetTestSetFolder.TestSetFactory

        End If

        tdconSourceTestSetFactory = tdconSource.TestSetFactory

        ' Get the list of test sets modified in the source since the last run or by the specified date range...

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select cy_cycle_id from cycle where (cy_vts >= '" & checkFromDate & "' and cy_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and CY_USER_TEMPLATE_03 like '2022%' order by cy_cycle_id"

        Else

            ' Just fetch all test sets in the current source since the last run...

            sqlString = "select cy_cycle_id from cycle where cy_vts > '" & lastChecked & "' and CY_USER_TEMPLATE_03 like '2022%' order by cy_cycle_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestSetID = tdconRecSet.FieldValue(0)
                sourceTestSet = tdconSourceTestSetFactory.Item(sourceTestSetID)

                RunStatus.Text = "Processing Test Set # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("CY_USER_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("CY_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid project name: " & sourceTestSet.Field("CY_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_02") <> "" Then

                    If relName.Contains(sourceTestSet.Field("CY_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid release name: " & sourceTestSet.Field("CY_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_03") <> "" Then

                    If appName.Contains(sourceTestSet.Field("CY_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid application name: " & sourceTestSet.Field("CY_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing application name")
                    badRecord = True

                End If

                ' Test Phase...
                Custom_TestPhase = "UAT"

                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test Set is already in...look in Related ID field...

                    sqlString2 = "select CY_CYCLE_ID from Cycle where CY_USER_08 = '" & sProject & "' and CY_USER_04 = '" & sourceTestID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        ' Just one record is already in...fetch it and check for updates...

                        foundGood = True
                        tempTestSetID = tdconRecSet2.FieldValue(0)
                        tempTestSet = tdconTargetTestFactory.Item(tempTestSetID)

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTestSet.Field("CY_CYCLE") <> sourceTestSet.Field("CY_CYCLE") Then
                                    tempTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_SUBTYPE_ID") <> sourceTestSet.Field("CY_SUBTYPE_ID") Then
                                    tempTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_STATUS") <> sourceTestSet.Field("CY_STATUS") Then
                                    tempTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_COMMENT") <> sourceTestSet.Field("CY_COMMENT") Then
                                    tempTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_TYPE") <> sourceTestSet.Field("CY_TYPE") Then
                                    tempTestSet.Field("CY_TYPE") = sourceTestSet.Field("CY_TYPE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_01") <> sourceTestSet.Field("CY_USER_01") Then
                                    tempTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_01")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_02") <> sourceTestSet.Field("CY_USER_02") Then
                                    tempTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_02")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_03") <> sourceTestSet.Field("CY_USER_03") Then
                                    tempTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_03")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_04") <> sourceTestSet.ID Then
                                    tempTestSet.Field("CY_USER_04") = sourceTestSet.ID
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_05") <> curSource Then
                                    tempTestSet.Field("CY_USER_05") = curSource
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_08") <> sProject Then
                                    tempTestSet.Field("CY_USER_08") = sProject
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_07") <> Custom_TestPhase Then
                                    tempTestSet.Field("CY_USER_07") = Custom_TestPhase
                                    wasChanged = True
                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTestSet.Post()
                                    reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestSetID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test Set not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' Create new test set from the fields...
                            newTestSet = tdconTargetTestSetFactory.AddItem(System.DBNull.Value)

                            newTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                            newTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")

                            newTestSet.Field("CY_USER_04") = sourceTestSet.ID
                            newTestSet.Field("CY_USER_05") = curSource
                            newTestSet.Field("CY_USER_07") = Custom_TestPhase
                            newTestSet.Field("CY_USER_08") = sProject
                            newTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")

                            newTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")

                            newTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_01")
                            newTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_02")
                            newTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_03")

                            ' Post the test set...

                            newTestSet.Post()

                            reportWrite.WriteLine(sourceTestSetID & ": New related ALM Test Set created")

                            ' ...now loop over the source test set test factory to add known ones to this new test set...

                            sourceTSTFactory = sourceTestSet.TSTestFactory
                            sourceTSTFList = sourceTSTFactory.NewList("")

                            targetTSTFactory = newTestSet.TSTestFactory

                            For Each sourceTSTest In sourceTSTFList

                                sourceTestID = sourceTSTest.TestId

                                ' See if this test is already in the target...

                                sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                                tdconCommand2 = tdconTarget.Command
                                tdconCommand2.CommandText = sqlString2
                                tdconRecSet2 = tdconCommand2.Execute

                                If tdconRecSet2.RecordCount > 0 Then

                                    ' Found the test...

                                    tempTestID = tdconRecSet2.FieldValue(0)
                                    tempTest = tdconTargetTestFactory.Item(tempTestID)

                                    targetTSTFactory.AddItem(tempTest)

                                Else

                                    RunStatus.Text = "Error:  Source test # " & sourceTestID & " not found in target..."
                                    Application.DoEvents()

                                End If

                            Next

                            ' ...and now move it to the correct folder...

                            RunStatus.Text = "Moving the test set from the temp synch folder..."
                            Application.DoEvents()

                            moveToFolderID = setTestSetFolder(newTestSet.ID)

                            tempTestSetID = newTestSet.ID
                            sqlString = "update cycle set cy_folder_id = " & moveToFolderID & " where cy_cycle_id = " & tempTestSetID

                            tdconCommand2 = tdconTarget.Command
                            tdconCommand2.CommandText = sqlString
                            tdconRecSet2 = tdconCommand2.Execute

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTRHALMDefects(sDomain, sProject)

        Dim foundGood As Boolean

        curSource = "hSTI ALM"

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select bg_bug_id from bug where (bg_vts >= '" & checkFromDate & "' and bg_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and BG_USER_05 like '2022%' order by bg_bug_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select bg_bug_id from bug where bg_vts > '" & lastChecked & "' and BG_USER_05 like '2022%' order by bg_bug_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceBugID = tdconRecSet.FieldValue(0)
                sourceBug = tdconSource.BugFactory.Item(sourceBugID)

                RunStatus.Text = "Processing defect # " & sourceBug.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceBug.Field("BG_USER_04") <> "" Then

                    If projectName.Contains(sourceBug.Field("BG_USER_04")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid project name: " & sourceBug.Field("BG_USER_04"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing project name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_05") <> "" Then

                    If relName.Contains(sourceBug.Field("BG_USER_05")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid release name: " & sourceBug.Field("BG_USER_05"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing release name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_06") <> "" Then

                    If appName.Contains(sourceBug.Field("BG_USER_06")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid application name: " & sourceBug.Field("BG_USER_06"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                ' Defect status...
                Custom_State = ""

                Select Case sourceBug.Field("BG_STATUS")

                    Case "New", "Closed", "Deferred", "Fixed", "Open", "Rejected", "Retest"
                        Custom_State = sourceBug.Field("BG_STATUS")
                    Case "PendingApproval"
                        Custom_State = "New"
                    Case "Hold"
                        Custom_State = "Deferred"
                    Case "Reopen"
                        Custom_State = "Retest"
                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid defect state: '" & sourceBug.Field("BG_STATUS") & "'")
                        badRecord = True

                End Select

                ' Severity...
                Custom_Severity = ""

                Select Case sourceBug.Field("BG_SEVERITY")

                    Case "4-Low"
                        Custom_Severity = "4-Low"
                    Case "3-Medium"
                        Custom_Severity = "3-Medium"
                    Case "2-High"
                        Custom_Severity = "2-High"
                    Case "0-Urgent", "1-Critical"
                        Custom_Severity = "1-Critical"
                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid severity: '" & sourceBug.Field("BG_SEVERITY") & "'")
                        badRecord = True

                End Select

                ' Test Phase...
                Custom_TestPhase = ""

                Select Case sourceBug.Field("BG_USER_07")
                    Case "Pre-SIT", "SIT", "UAT", "Regression"
                        Custom_TestPhase = sourceBug.Field("BG_USER_07")
                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid test phase: '" & sourceBug.Field("BG_USER_07") & "'")
                        badRecord = True

                End Select

                If badRecord = False Then

                    ' Check to see if the defect is already in...look in Related ID field...

                    sqlString2 = "select BG_BUG_ID from bug where BG_USER_07 = '" & sProject & "' and BG_USER_04 = '" & sourceBugID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet2.RecordCount > 1 Then

                            ' As the source is STRH ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet2.RecordCount

                                tempBugID = tdconRecSet2.FieldValue(0)
                                tempBug = tdconTarget.BugFactory.Item(tempBugID)

                                If tempBug.Field("BG_USER_13") <> "Duplicate Defect" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet2.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempBugID = tdconRecSet2.FieldValue(0)
                            tempBug = tdconTarget.BugFactory.Item(tempBugID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                'Compare and change just what's changed so the audit table reads right...

                                If tempBug.Field("BG_USER_07") <> sProject Then
                                    tempBug.Field("BG_USER_07") = sProject
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DESCRIPTION") <> sourceBug.Field("BG_DESCRIPTION") Then
                                    tempBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_STATUS") <> Custom_State Then
                                    tempBug.Field("BG_STATUS") = Custom_State
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_01") <> sourceBug.Field("BG_USER_04") Then
                                    tempBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_04")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_02") <> sourceBug.Field("BG_USER_05") Then
                                    tempBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_05")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_03") <> sourceBug.Field("BG_USER_06") Then
                                    tempBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_06")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DETECTED_BY") <> sourceBug.Field("BG_DETECTED_BY") Then
                                    tempBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DETECTION_DATE") <> sourceBug.Field("BG_DETECTION_DATE") Then
                                    tempBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_13") <> Custom_TestPhase Then
                                    tempBug.Field("BG_USER_13") = Custom_TestPhase
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_14") <> sourceBug.Field("BG_USER_08") Then
                                    tempBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_08")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_15") <> sourceBug.Field("BG_USER_09") Then
                                    tempBug.Field("BG_USER_15") = sourceBug.Field("BG_USER_09")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_SEVERITY") <> Custom_Severity Then
                                    tempBug.Field("BG_SEVERITY") = Custom_Severity
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_SUMMARY") <> sourceBug.Field("BG_SUMMARY") Then
                                    tempBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_RESPONSIBLE") <> sourceBug.Field("BG_RESPONSIBLE") Then
                                    tempBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_PRIORITY") <> sourceBug.Field("BG_PRIORITY") Then
                                    tempBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_CLOSING_DATE") <> sourceBug.Field("BG_CLOSING_DATE") Then
                                    tempBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")
                                    wasChanged = True
                                End If

                                ' Post the defect...
                                If wasChanged Then

                                    tempBug.Post()
                                    reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceBugID & ": Related defect not updated - more than one found active, or related defect deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newBug = tdconTarget.BugFactory.AddItem(System.DBNull.Value)

                            newBug.Field("BG_USER_04") = sourceBug.ID
                            newBug.Field("BG_USER_05") = curSource
                            newBug.Field("BG_USER_07") = sProject
                            newBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                            newBug.Field("BG_STATUS") = Custom_State
                            newBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_04")
                            newBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_05")
                            newBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_06")

                            newBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                            newBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                            newBug.Field("BG_USER_13") = Custom_TestPhase
                            newBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_TEMPLATE_08")
                            newBug.Field("BG_SEVERITY") = Custom_Severity
                            newBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                            newBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                            newBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                            newBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")

                            ' Post the defect...

                            newBug.Post()
                            reportWrite.WriteLine(sourceBugID & ": New related ALM defect created")

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceBugID & ": Related defect not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTIALMReqs(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount As Integer

        ' Set the initial destination for all new requirements to the 001_SynchTemp folder...

        tdconTargetReqFactory = tdconTarget.ReqFactory
        tdconSourceReqFactory = tdconSource.ReqFactory

        curSource = "hSTI ALM"

        curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", "001_SynchTemp", 16)
        tempString = curLocation.Item(1)
        tempArray = Split(tempString, ",")
        moveToFolderID = tempArray(0)

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select rq_req_id from req where (rq_vts >= '" & checkFromDate & "' and rq_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%' order by rq_req_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select rq_req_id from req where rq_vts > '" & lastChecked & "' and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%' order by rq_req_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceReqID = tdconRecSet.FieldValue(0)
                sourceReq = tdconSourceReqFactory.Item(sourceReqID)

                RunStatus.Text = "Processing requirement # " & sourceReq.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceReq.Field("RQ_USER_01") <> "" Then

                    If projectName.Contains(sourceReq.Field("RQ_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid project name: " & sourceReq.Field("RQ_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing project name")
                    badRecord = True

                End If

                If sourceReq.Field("RQ_USER_02") <> "" Then

                    If relName.Contains(sourceReq.Field("RQ_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid release name: " & sourceReq.Field("RQ_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing release name")
                    badRecord = True

                End If

                If sourceReq.Field("RQ_USER_03") <> "" Then

                    If appName.Contains(sourceReq.Field("RQ_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid application name: " & sourceReq.Field("RQ_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                ' Requirement status...
                Custom_State = ""

                Select Case sourceReq.Field("RQ_USER_47")

                    Case "Accepted", "Approved", "Completed", "Deferred", "In Review", "Incorporated", "Non-compliant", "Obsolete", "Proposed", "Rejected"
                        Custom_State = sourceReq.Field("RQ_USER_47")

                    Case Else

                        reportWrite.WriteLine(sourceReqID & ": Invalid requirement state: '" & sourceReq.Field("RQ_USER_47") & "'")
                        badRecord = True

                End Select

                ' Requirement type...
                Custom_Type = ""

                Select Case sourceReq.Field("RQ_TYPE_ID")

                    Case "System Functional", "System Nonfunctional", "Business Functional", "Business Nonfunctional", "User Story"
                        Custom_Type = sourceReq.Field("RQ_TYPE_ID")

                    Case Else

                        reportWrite.WriteLine(sourceReqID & ": Invalid requirement type: '" & sourceReq.Field("RQ_TYPE_ID") & "'")
                        badRecord = True

                End Select

                If badRecord = False Then

                    ' Check to see if the requirement is already in...look in Related ID field...

                    sqlString2 = "select RQ_REQ_ID from req where RQ_USER_08 = '" & sProject & "' and RQ_USER_04 = '" & sourceReqID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet2.RecordCount > 1 Then

                            ' As the source is EIS ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet2.RecordCount

                                tempReqID = tdconRecSet2.FieldValue(0)
                                tempReq = tdconTargetReqFactory.Item(tempReqID)

                                If tempReq.Field("RQ_USER_06") <> "Obsolete" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet2.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempReqID = tdconRecSet2.FieldValue(0)
                            tempReq = tdconTargetReqFactory.Item(tempReqID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempReq.Field("RQ_USER_07") <> sProject Then
                                    tempReq.Field("RQ_USER_07") = sProject
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_COMMENT") <> sourceReq.Field("RQ_REQ_COMMENT") Then
                                    tempReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_STATUS") <> sourceReq.Field("RQ_REQ_STATUS") Then
                                    tempReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_06") <> Custom_State Then
                                    tempReq.Field("RQ_USER_06") = Custom_State
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_01") <> sourceReq.Field("RQ_USER_01") Then
                                    tempReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_02") <> sourceReq.Field("RQ_USER_02") Then
                                    tempReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_03") <> sourceReq.Field("RQ_USER_03") Then
                                    tempReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_AUTHOR") <> sourceReq.Field("RQ_REQ_AUTHOR") Then
                                    If sourceReq.Field("RQ_REQ_AUTHOR") = "" Then
                                        tempReq.Field("RQ_REQ_AUTHOR") = "sv-alm-syncprod"
                                    Else
                                        tempReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                    End If
                                    tempReq.Field("RQ_USER_12") = tempReq.Field("RQ_REQ_AUTHOR")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_DATE") <> sourceReq.Field("RQ_REQ_DATE") Then
                                    tempReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_NAME") <> sourceReq.Field("RQ_REQ_NAME") Then

                                    origName = tempReq.Field("RQ_REQ_NAME")

                                    If origName.Contains(" - Duplicate # ") Then

                                        ' We don't rename duplicates...it causes issues later...

                                    Else

                                        ' If the name is unique, it can be renamed...

                                        tempReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                        wasChanged = True

                                    End If

                                End If

                                If tempReq.Field("RQ_REQ_PRIORITY") <> sourceReq.Field("RQ_REQ_PRIORITY") Then
                                    tempReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")
                                    wasChanged = True
                                End If

                                ' Post the requirement...
                                If wasChanged Then

                                    tempReq.Post()
                                    reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceReqID & ": Related requirement not updated - more than one found active, or related requirement deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newReq = tdconTargetReqFactory.AddItem(System.DBNull.Value)

                            newReq.Field("RQ_TYPE_ID") = Custom_Type

                            newReq.Field("RQ_USER_04") = sourceReq.ID
                            newReq.Field("RQ_USER_05") = curSource
                            newReq.Field("RQ_USER_07") = sProject
                            newReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                            newReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                            newReq.Field("RQ_USER_06") = Custom_State
                            newReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                            newReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                            newReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")

                            newReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                            newReq.Field("RQ_USER_12") = sourceReq.Field("RQ_REQ_AUTHOR")

                            newReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                            newReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                            newReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")

                            ' Post the requirement...

                            newReq.Post()
                            reportWrite.WriteLine(sourceReqID & ": New related ALM requirement created")

                            ' Now move it to the synch temp folder...

                            notMoved = True
                            dupeCount = 0
                            origName = newReq.Field("RQ_REQ_NAME")

                            While notMoved

                                Try

                                    newReq.Move(moveToFolderID, -4)
                                    notMoved = False

                                Catch ex As Exception

                                    ' Means one with that name is already in the SynchTemp...
                                    dupeCount = dupeCount + 1
                                    newReq.Field("RQ_REQ_NAME") = origName & " - Duplicate # " & dupeCount
                                    newReq.Post()

                                End Try

                            End While

                            ' ...and now try moving it to the correct location...

                            Try

                                moveToFolderID = setReqFolder(newReq.ID)
                                newReq.Move(moveToFolderID, -4)

                            Catch ex2 As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not moved: " & ex2.Message)

                            End Try

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceReqID & ": Related requirement not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTIALMTests(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        tdconTargetTestFactory = tdconTarget.TestFactory
        tdconSourceTestFactory = tdconSource.TestFactory

        curSource = "hSTI ALM"

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        testTreeMgr = tdconTarget.TreeManager
        workingFolder = testTreeMgr.NodeByPath("Subject\001_SynchTemp")
        moveToFolderID = workingFolder.NodeID
        tdconTargetTestFactory = workingFolder.TestFactory

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select ts_test_id from test where (ts_vts >= '" & checkFromDate & "' and ts_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and TS_USER_02 like '2022%' order by ts_test_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select ts_test_id from test where ts_vts > '" & lastChecked & "' and TS_USER_02 like '2022%' order by ts_test_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestID = tdconRecSet.FieldValue(0)
                sourceTest = tdconSourceTestFactory.Item(sourceTestID)

                RunStatus.Text = "Processing Test # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("TS_USER_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("TS_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid project name: " & sourceTestSet.Field("TS_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("TS_USER_02") <> "" Then

                    If relName.Contains(sourceTestSet.Field("TS_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid release name: " & sourceTestSet.Field("TS_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("TS_USER_03") <> "" Then

                    If appName.Contains(sourceTestSet.Field("TS_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid application name: " & sourceTestSet.Field("TS_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test is already in...look in Related ID field...

                    sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet2.RecordCount > 1 Then

                            ' As the source is EIS ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet2.RecordCount

                                tempTestID = tdconRecSet2.FieldValue(0)
                                tempTest = tdconTargetTestFactory.Item(tempTestID)

                                If tempTest.Field("TS_USER_06") <> "Obsolete" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet2.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempTestID = tdconRecSet2.FieldValue(0)
                            tempTest = tdconTargetTestFactory.Item(tempTestID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTest.Field("TS_USER_07") <> sProject Then
                                    tempTest.Field("TS_USER_07") = sProject
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_DESCRIPTION") <> sourceTestSet.Field("TS_DESCRIPTION") Then
                                    tempTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_EXEC_STATUS") <> sourceTestSet.Field("TS_EXEC_STATUS") Then
                                    tempTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_STATUS") <> sourceTestSet.Field("TS_STATUS") Then
                                    tempTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_DEV_COMMENTS") <> sourceTestSet.Field("TS_DEV_COMMENTS") Then
                                    tempTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_TYPE") <> sourceTestSet.Field("TS_TYPE") Then
                                    tempTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_01") <> sourceTestSet.Field("TS_USER_01") Then
                                    tempTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_02") <> sourceTestSet.Field("TS_USER_02") Then
                                    tempTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_03") <> sourceTestSet.Field("TS_USER_03") Then
                                    tempTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_12") <> sourceTestSet.Field("TS_USER_09") Then
                                    tempTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_09")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_25") <> sourceTestSet.Field("TS_USER_27") Then
                                    tempTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_27")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_RESPONSIBLE") <> sourceTestSet.Field("TS_RESPONSIBLE") Then
                                    tempTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_CREATION_DATE") <> sourceTestSet.Field("TS_CREATION_DATE") Then
                                    tempTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_NAME") <> sourceTestSet.Field("TS_NAME") Then

                                    origName = tempTest.Field("TS_NAME")

                                    If origName.Contains(" - Duplicate # ") Then

                                        ' We don't rename duplicates...it causes issues later...

                                    Else

                                        ' If the name is unique, it can be renamed...

                                        tempTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")
                                        wasChanged = True

                                    End If

                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTest.Post()
                                    reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " updated")

                                End If

                                ' Test processed...now work with the Design Steps...

                                If sourceTestSet.DesStepsNum > 0 Then

                                    ' This test has design steps...see if there were changes...

                                    Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                End If

                                ' If Automated Tests option selected, perform the repo copy...

                                If doAutoTests.Checked Then

                                    Try

                                        RunStatus.Text = "Starting the test repo copy..."
                                        Application.DoEvents()

                                        sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                        testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                        sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                        sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                        ' Bring locally the test's repo...
                                        testSourceExtendedStorage.Load("-r *.*", True)

                                        testTargetExtendedStorage = newTest.ExtendedStorage

                                        targetTestClientPath = testTargetExtendedStorage.ClientPath
                                        targetTestServerPath = testTargetExtendedStorage.ServerPath

                                        testTargetExtendedStorage.Load("-r *.*", True)

                                        ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                        My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                        ' Save the repo...
                                        testTargetExtendedStorage.Save("-r *.*", True)

                                        tempTest.Post()

                                        ' If successful, delete the local copies to keep space usage low...

                                        My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                        My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                    Catch ex2 As Exception

                                        reportWrite.WriteLine(sourceTestID & ": Related Test's repo not updated:", ex2.Message)

                                    End Try

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestID & ": Related Test not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newTest = tdconTargetTestFactory.AddItem(System.DBNull.Value)

                            newTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")

                            newTest.Field("TS_USER_04") = sourceTestSet.ID
                            newTest.Field("TS_USER_05") = curSource
                            newTest.Field("TS_USER_07") = sProject
                            newTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_09")
                            newTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                            newTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")

                            newTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                            newTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")

                            newTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                            newTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                            newTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")

                            If sourceTestSet.Field("TS_USER_27") = "" Then
                                newTest.Field("TS_USER_25") = "N/A"
                            Else
                                newTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_27")
                            End If

                            newTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")

                            newTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                            newTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")

                            ' Post the test...

                            newTest.Post()
                            reportWrite.WriteLine(sourceTestID & ": New related ALM Test created")

                            ' ...and now move it to the correct location...

                            moveToFolderID = setTestFolder(newTest.ID)

                            tempTestID = newTest.ID
                            sqlString = "update test set ts_subject = " & moveToFolderID & " where ts_test_id = " & tempTestID

                            tdconCommand2 = tdconTarget.Command
                            tdconCommand2.CommandText = sqlString
                            tdconRecSet2 = tdconCommand2.Execute

                            ' Test created...now work with the Design Steps...

                            If sourceTestSet.DesStepsNum > 0 Then

                                ' This test has design steps...see if there were changes...

                                Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                            End If

                            ' If Automated Tests option selected, perform the repo copy...

                            If doAutoTests.Checked Then

                                Try

                                    RunStatus.Text = "Starting the test repo copy..."
                                    Application.DoEvents()

                                    sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                    testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                    sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                    sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                    ' Bring locally the test's repo...
                                    testSourceExtendedStorage.Load("-r *.*", True)

                                    testTargetExtendedStorage = newTest.ExtendedStorage

                                    targetTestClientPath = testTargetExtendedStorage.ClientPath
                                    targetTestServerPath = testTargetExtendedStorage.ServerPath

                                    testTargetExtendedStorage.Load("-r *.*", True)

                                    ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                    My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                    ' Save the repo...
                                    testTargetExtendedStorage.Save("-r *.*", True)

                                    newTest.Post()

                                    ' If successful, delete the local copies to keep space usage low...

                                    My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                    My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                Catch ex2 As Exception

                                    reportWrite.WriteLine(sourceTestID & ": Related Test's repo not created:", ex2.Message)

                                End Try

                            End If

                            ' Link test to requirement...

                            ' testNum = newTest.ID
                            ' Call AddTestToCoverage(reqNum, testNum)

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTIALMTestSets(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        curSource = "hSTI ALM"

        tdconTargetTestFactory = tdconTarget.TestFactory

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        tdconTargetTSFolderFactory = tdconTarget.TestLabFolderFactory
        targetTSFilter = tdconTargetTSFolderFactory.Filter
        targetTSFilter.Filter("CF_ITEM_NAME") = "001_SynchTemp"

        targetTSFList = targetTSFilter.NewList()

        If targetTSFList.Count > 0 Then

            targetTestSetFolder = targetTSFList.Item(1)
            tdconTargetTestSetFactory = targetTestSetFolder.TestSetFactory

        End If

        tdconSourceTestSetFactory = tdconSource.TestSetFactory

        ' Get the list of test sets modified in the source since the last run or by the specified date range...

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select cy_cycle_id from cycle where (cy_vts >= '" & checkFromDate & "' and cy_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and CY_USER_02 like '2022%' order by cy_cycle_id"

        Else

            ' Just fetch all test sets in the current source since the last run...

            sqlString = "select cy_cycle_id from cycle where cy_vts > '" & lastChecked & "' and CY_USER_02 like '2022%' order by cy_cycle_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestSetID = tdconRecSet.FieldValue(0)
                sourceTestSet = tdconSourceTestSetFactory.Item(sourceTestSetID)

                RunStatus.Text = "Processing Test Set # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("CY_USER_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("CY_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid project name: " & sourceTestSet.Field("CY_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_02") <> "" Then

                    If relName.Contains(sourceTestSet.Field("CY_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid release name: " & sourceTestSet.Field("CY_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_03") <> "" Then

                    If appName.Contains(sourceTestSet.Field("CY_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid application name: " & sourceTestSet.Field("CY_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing application name")
                    badRecord = True

                End If

                ' Test Phase...
                Custom_TestPhase = ""

                Select Case sourceTestSet.Field("CY_USER_05")
                    Case "0 Static", "1 Unit", "4 CAT"
                        Custom_TestPhase = "UAT"

                    Case "2 FIT", "Sprint"
                        Custom_TestPhase = "Pre-SIT"

                    Case "3 SIT"
                        Custom_TestPhase = "SIT"

                    Case "5 PRDR"
                        Custom_TestPhase = "Dress Rehearsal"

                    Case "6 PLT"
                        Custom_TestPhase = "Performance – PLT Only"

                    Case "7 Warranty", "8 Extended Warranty", "9 Out of Warranty"
                        Custom_TestPhase = "Warranty"

                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid test phase: '" & sourceTestSet.Field("CY_USER_05") & "'")
                        badRecord = True

                End Select

                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test Set is already in...look in Related ID field...

                    sqlString2 = "select CY_CYCLE_ID from Cycle where CY_USER_08 = '" & sProject & "' and CY_USER_04 = '" & sourceTestID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        ' Just one record is already in...fetch it and check for updates...

                        foundGood = True
                        tempTestSetID = tdconRecSet2.FieldValue(0)
                        tempTestSet = tdconTargetTestFactory.Item(tempTestSetID)

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTestSet.Field("CY_CYCLE") <> sourceTestSet.Field("CY_CYCLE") Then
                                    tempTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_SUBTYPE_ID") <> sourceTestSet.Field("CY_SUBTYPE_ID") Then
                                    tempTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_STATUS") <> sourceTestSet.Field("CY_STATUS") Then
                                    tempTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_COMMENT") <> sourceTestSet.Field("CY_COMMENT") Then
                                    tempTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_TYPE") <> sourceTestSet.Field("CY_TYPE") Then
                                    tempTestSet.Field("CY_TYPE") = sourceTestSet.Field("CY_TYPE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_01") <> sourceTestSet.Field("CY_USER_01") Then
                                    tempTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_01")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_02") <> sourceTestSet.Field("CY_USER_02") Then
                                    tempTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_02")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_03") <> sourceTestSet.Field("CY_USER_03") Then
                                    tempTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_03")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_04") <> sourceTestSet.ID Then
                                    tempTestSet.Field("CY_USER_04") = sourceTestSet.ID
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_05") <> curSource Then
                                    tempTestSet.Field("CY_USER_05") = curSource
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_08") <> sProject Then
                                    tempTestSet.Field("CY_USER_08") = sProject
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_07") <> Custom_TestPhase Then
                                    tempTestSet.Field("CY_USER_07") = Custom_TestPhase
                                    wasChanged = True
                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTestSet.Post()
                                    reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestSetID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test Set not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' Create new test set from the fields...
                            newTestSet = tdconTargetTestSetFactory.AddItem(System.DBNull.Value)

                            newTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                            newTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")

                            newTestSet.Field("CY_USER_04") = sourceTestSet.ID
                            newTestSet.Field("CY_USER_05") = curSource
                            newTestSet.Field("CY_USER_07") = Custom_TestPhase
                            newTestSet.Field("CY_USER_08") = sProject
                            newTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")

                            newTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")

                            newTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_01")
                            newTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_02")
                            newTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_03")

                            ' Post the test set...

                            newTestSet.Post()

                            reportWrite.WriteLine(sourceTestSetID & ": New related ALM Test Set created")

                            ' ...now loop over the source test set test factory to add known ones to this new test set...

                            sourceTSTFactory = sourceTestSet.TSTestFactory
                            sourceTSTFList = sourceTSTFactory.NewList("")

                            targetTSTFactory = newTestSet.TSTestFactory

                            For Each sourceTSTest In sourceTSTFList

                                sourceTestID = sourceTSTest.TestId

                                ' See if this test is already in the target...

                                sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                                tdconCommand2 = tdconTarget.Command
                                tdconCommand2.CommandText = sqlString2
                                tdconRecSet2 = tdconCommand2.Execute

                                If tdconRecSet2.RecordCount > 0 Then

                                    ' Found the test...

                                    tempTestID = tdconRecSet2.FieldValue(0)
                                    tempTest = tdconTargetTestFactory.Item(tempTestID)

                                    targetTSTFactory.AddItem(tempTest)

                                Else

                                    RunStatus.Text = "Error:  Source test # " & sourceTestID & " not found in target..."
                                    Application.DoEvents()

                                End If

                            Next

                            ' ...and now move it to the correct folder...

                            RunStatus.Text = "Moving the test set from the temp synch folder..."
                            Application.DoEvents()

                            moveToFolderID = setTestSetFolder(newTestSet.ID)

                            tempTestSetID = newTestSet.ID
                            sqlString = "update cycle set cy_folder_id = " & moveToFolderID & " where cy_cycle_id = " & tempTestSetID

                            tdconCommand2 = tdconTarget.Command
                            tdconCommand2.CommandText = sqlString
                            tdconRecSet2 = tdconCommand2.Execute

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processSTIALMDefects(sDomain, sProject)

        Dim foundGood As Boolean

        curSource = "hSTI ALM"

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select bg_bug_id from bug where (bg_vts >= '" & checkFromDate & "' and bg_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and BG_USER_37 like '2022%' order by bg_bug_id"

        Else

            ' Just fetch all requirements in the current source since the last run...

            sqlString = "select bg_bug_id from bug where bg_vts > '" & lastChecked & "' and BG_USER_37 like '2022%' order by bg_bug_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceBugID = tdconRecSet.FieldValue(0)
                sourceBug = tdconSource.BugFactory.Item(sourceBugID)

                RunStatus.Text = "Processing defect # " & sourceBug.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceBug.Field("BG_USER_13") <> "" Then

                    If projectName.Contains(sourceBug.Field("BG_USER_13")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid project name: " & sourceBug.Field("BG_USER_13"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing project name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_37") <> "" Then

                    If relName.Contains(sourceBug.Field("BG_USER_37")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid Detected On release name: " & sourceBug.Field("BG_USER_37"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing Detected On release name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_16") <> "" Then

                    If relName.Contains(sourceBug.Field("BG_USER_16")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid Installed release name: " & sourceBug.Field("BG_USER_16"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing Installed release name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_02") <> "" Then

                    If appName.Contains(sourceBug.Field("BG_USER_02")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid application name: " & sourceBug.Field("BG_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                ' Defect status...
                Custom_State = ""

                Select Case sourceBug.Field("BG_STATUS")

                    Case "New", "Closed", "Deferred", "Fixed", "Open", "Rejected", "Retest"
                        Custom_State = sourceBug.Field("BG_STATUS")

                    Case "Failed Retest"
                        Custom_State = "Open"

                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid defect state: '" & sourceBug.Field("BG_STATUS") & "'")
                        badRecord = True

                End Select

                ' Severity...
                Custom_Severity = ""

                Select Case sourceBug.Field("BG_SEVERITY")

                    Case "1"
                        Custom_Severity = "1-Critical"

                    Case "2"
                        Custom_Severity = "2-High"

                    Case "3"
                        Custom_Severity = "3-Medium"

                    Case "4"
                        Custom_Severity = "4-Low"

                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid severity: '" & sourceBug.Field("BG_SEVERITY") & "'")
                        badRecord = True

                End Select

                ' Priority...
                Custom_Priority = ""

                Select Case sourceBug.Field("BG_PRIORITY")

                    Case "1 - High"
                        Custom_Priority = "1-High"

                    Case "2 - Medium"
                        Custom_Priority = "2-Medium"

                    Case "3 - Low"
                        Custom_Priority = "3-Low"

                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid priority: '" & sourceBug.Field("BG_PRIORITY") & "'")
                        badRecord = True

                End Select

                ' Test Phase...
                Custom_TestPhase = ""

                Select Case sourceBug.Field("BG_USER_19")
                    Case "0 Static", "1 Unit", "4 CAT"
                        Custom_TestPhase = "UAT"

                    Case "2 FIT", "Sprint"
                        Custom_TestPhase = "Pre-SIT"

                    Case "3 SIT"
                        Custom_TestPhase = "SIT"

                    Case "5 PRDR"
                        Custom_TestPhase = "Dress Rehearsal"

                    Case "6 PLT"
                        Custom_TestPhase = "Performance – PLT Only"

                    Case "7 Warranty", "8 Extended Warranty", "9 Out of Warranty"
                        Custom_TestPhase = "Warranty"

                    Case Else

                        reportWrite.WriteLine(sourceBugID & ": Invalid test phase: '" & sourceBug.Field("BG_USER_19") & "'")
                        badRecord = True

                End Select

                If badRecord = False Then

                    ' Check to see if the defect is already in...look in Related ID field...

                    sqlString2 = "select BG_BUG_ID from bug where BG_USER_05 = 'hSTI ALM' and BG_USER_04 = '" & sourceBugID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet2.RecordCount > 1 Then

                            ' As the source is ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet2.RecordCount

                                tempBugID = tdconRecSet2.FieldValue(0)
                                tempBug = tdconTarget.BugFactory.Item(tempBugID)

                                If tempBug.Field("BG_USER_18") <> "Duplicate Defect" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet2.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempBugID = tdconRecSet2.FieldValue(0)
                            tempBug = tdconTarget.BugFactory.Item(tempBugID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                'Compare and change just what's changed so the audit table reads right...

                                If tempBug.Field("BG_USER_07") <> sProject Then
                                    tempBug.Field("BG_USER_07") = sProject
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DESCRIPTION") <> sourceBug.Field("BG_DESCRIPTION") Then
                                    tempBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_STATUS") <> Custom_State Then
                                    tempBug.Field("BG_STATUS") = Custom_State
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_01") <> sourceBug.Field("BG_USER_13") Then
                                    tempBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_13")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_02") <> sourceBug.Field("BG_USER_37") Then
                                    tempBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_37")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_12") <> sourceBug.Field("BG_USER_16") Then
                                    tempBug.Field("BG_USER_12") = sourceBug.Field("BG_USER_16")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_03") <> sourceBug.Field("BG_USER_02") Then
                                    tempBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_02")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DETECTED_BY") <> sourceBug.Field("BG_DETECTED_BY") Then
                                    tempBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DETECTION_DATE") <> sourceBug.Field("BG_DETECTION_DATE") Then
                                    tempBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_13") <> Custom_TestPhase Then
                                    tempBug.Field("BG_USER_13") = Custom_TestPhase
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_14") <> sourceBug.Field("BG_USER_05") Then
                                    tempBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_05")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_15") <> sourceBug.Field("BG_USER_18") Then
                                    tempBug.Field("BG_USER_15") = sourceBug.Field("BG_USER_18")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_16") <> sourceBug.Field("BG_USER_40") Then
                                    tempBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_40")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_26") <> sourceBug.Field("BG_USER_46") Then
                                    tempBug.Field("BG_USER_26") = sourceBug.Field("BG_USER_46")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_SEVERITY") <> Custom_Severity Then
                                    tempBug.Field("BG_SEVERITY") = Custom_Severity
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_SUMMARY") <> sourceBug.Field("BG_SUMMARY") Then
                                    tempBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_RESPONSIBLE") <> sourceBug.Field("BG_RESPONSIBLE") Then
                                    tempBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_PRIORITY") <> Custom_Priority Then
                                    tempBug.Field("BG_PRIORITY") = Custom_Priority
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_CLOSING_DATE") <> sourceBug.Field("BG_CLOSING_DATE") Then
                                    tempBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")
                                    wasChanged = True
                                End If

                                ' Post the defect...
                                If wasChanged Then

                                    tempBug.Post()
                                    reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceBugID & ": Related defect not updated - more than one found active, or related defect deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newBug = tdconTarget.BugFactory.AddItem(System.DBNull.Value)

                            newBug.Field("BG_USER_04") = sourceBug.ID
                            newBug.Field("BG_USER_05") = curSource
                            newBug.Field("BG_USER_07") = sProject
                            newBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                            newBug.Field("BG_STATUS") = Custom_State
                            newBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_13")
                            newBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_37")
                            newBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_02")
                            newBug.Field("BG_USER_12") = sourceBug.Field("BG_USER_16")
                            newBug.Field("BG_USER_26") = sourceBug.Field("BG_USER_46")

                            newBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                            newBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                            newBug.Field("BG_USER_13") = Custom_TestPhase
                            newBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_05")
                            newBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_40")
                            newBug.Field("BG_SEVERITY") = Custom_Severity
                            newBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                            newBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                            newBug.Field("BG_PRIORITY") = Custom_Priority
                            newBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")

                            ' Post the defect...

                            newBug.Post()
                            reportWrite.WriteLine(sourceBugID & ": New related ALM defect created")

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceBugID & ": Related defect not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processTruistALMReqs(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount As Integer

        ' Set the initial destination for all new requirements to the 001_SynchTemp folder...

        tdconTargetReqFactory = tdconTarget.ReqFactory
        tdconSourceReqFactory = tdconSource.ReqFactory

        curSource = "Truist ALM"

        curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", "001_SynchTemp", 16)
        tempString = curLocation.Item(1)
        tempArray = Split(tempString, ",")
        moveToFolderID = tempArray(0)

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select rq_req_id from req where (rq_vts >= '" & checkFromDate & "' and rq_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%'"
            sqlString = sqlString & " and RQ_USER_05 NOT LIKE '%ALM%' order by rq_req_id"

            sqlString2 = "select rq_req_id from req where (rq_vts >= '" & checkFromDate & "' and rq_vts <= '" & checkToDate & "')"
            sqlString2 = sqlString2 & " and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%'"
            sqlString2 = sqlString2 & " and RQ_USER_05 IS NULL order by rq_req_id"

        Else

            ' Fetch all MOE-specific requirements in the current source since the last run...
            ' MOE-specific are indicated if the Related Source does not contain "ALM"...

            sqlString = "select rq_req_id from req where rq_vts > '" & lastChecked & "' and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%'"
            sqlString = sqlString & " and RQ_USER_05 NOT LIKE '%ALM%' order by rq_req_id"

            sqlString2 = "select rq_req_id from req where rq_vts > '" & lastChecked & "' and RQ_TYPE_ID <> 1 and RQ_USER_02 like '2022%'"
            sqlString2 = sqlString2 & " and RQ_USER_05 IS NULL order by rq_req_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceReqID = tdconRecSet.FieldValue(0)
                sourceReq = tdconSourceReqFactory.Item(sourceReqID)

                RunStatus.Text = "Processing requirement # " & sourceReq.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceReq.Field("RQ_USER_01") <> "" Then

                    If projectName.Contains(sourceReq.Field("RQ_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid project name: " & sourceReq.Field("RQ_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing project name")
                    badRecord = True

                End If

                If sourceReq.Field("RQ_USER_02") <> "" Then

                    If relName.Contains(sourceReq.Field("RQ_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid release name: " & sourceReq.Field("RQ_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing release name")
                    badRecord = True

                End If

                If sourceReq.Field("RQ_USER_03") <> "" Then

                    If appName.Contains(sourceReq.Field("RQ_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceReqID & ": Invalid application name: " & sourceReq.Field("RQ_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Application Name is missing...
                    reportWrite.WriteLine(sourceReqID & ": Missing application name")
                    badRecord = True

                End If

                If badRecord = False Then

                    ' Check to see if the requirement is already in...look in Related ID field...

                    If sourceReq.Field("RQ_USER_04") <> "" Then

                        ' In MOE from another location...check the Optional ID 2 field...
                        sqlString3 = "select RQ_REQ_ID from req where RQ_USER_07 = '" & sProject & "' and RQ_USER_04 = '" & sourceReqID & "'"

                    Else

                        ' Created in MOE...check the Related ID field...
                        sqlString3 = "select RQ_REQ_ID from req where RQ_USER_05 = 'Truist ALM' and RQ_USER_04 = '" & sourceReqID & "'"

                    End If

                    tdconCommand3 = tdconTarget.Command
                    tdconCommand3.CommandText = sqlString3
                    tdconRecSet3 = tdconCommand3.Execute

                    If tdconRecSet3.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet3.RecordCount > 1 Then

                            ' As the source is ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet3.RecordCount

                                tempReqID = tdconRecSet3.FieldValue(0)
                                tempReq = tdconTargetReqFactory.Item(tempReqID)

                                If tempReq.Field("RQ_USER_06") <> "Obsolete" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet3.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempReqID = tdconRecSet3.FieldValue(0)
                            tempReq = tdconTargetReqFactory.Item(tempReqID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempReq.Field("RQ_USER_07") <> sourceReq.Field("RQ_USER_08") Then
                                    tempReq.Field("RQ_USER_07") = sourceReq.Field("RQ_USER_08")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_COMMENT") <> sourceReq.Field("RQ_REQ_COMMENT") Then
                                    tempReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_STATUS") <> sourceReq.Field("RQ_REQ_STATUS") Then
                                    tempReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_06") <> sourceReq.Field("RQ_USER_06") Then
                                    tempReq.Field("RQ_USER_06") = sourceReq.Field("RQ_USER_06")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_01") <> sourceReq.Field("RQ_USER_01") Then
                                    tempReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_02") <> sourceReq.Field("RQ_USER_02") Then
                                    tempReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_USER_03") <> sourceReq.Field("RQ_USER_03") Then
                                    tempReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_AUTHOR") <> sourceReq.Field("RQ_REQ_AUTHOR") Then
                                    If sourceReq.Field("RQ_REQ_AUTHOR") = "" Then
                                        tempReq.Field("RQ_REQ_AUTHOR") = "sv-alm-syncprod"
                                    Else
                                        tempReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                    End If
                                    tempReq.Field("RQ_USER_12") = tempReq.Field("RQ_REQ_AUTHOR")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_DATE") <> sourceReq.Field("RQ_REQ_DATE") Then
                                    tempReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                    wasChanged = True
                                End If

                                If tempReq.Field("RQ_REQ_NAME") <> sourceReq.Field("RQ_REQ_NAME") Then

                                    origName = tempReq.Field("RQ_REQ_NAME")

                                    If origName.Contains(" - Duplicate # ") Then

                                        ' We don't rename duplicates...it causes issues later...

                                    Else

                                        ' If the name is unique, it can be renamed...

                                        tempReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                        wasChanged = True

                                    End If

                                End If

                                If tempReq.Field("RQ_REQ_PRIORITY") <> sourceReq.Field("RQ_REQ_PRIORITY") Then
                                    tempReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")
                                    wasChanged = True
                                End If

                                ' Post the requirement...
                                If wasChanged Then

                                    tempReq.Post()
                                    reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceReqID & ": Related requirement not updated - more than one found active, or related requirement deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newReq = tdconTargetReqFactory.AddItem(System.DBNull.Value)

                            newReq.Field("RQ_TYPE_ID") = sourceReq.Field("RQ_TYPE_ID")

                            If sourceReq.Field("RQ_USER_04") <> "" Then

                                ' Set the New related source and ID to the same as it was in MOE...

                                newReq.Field("RQ_USER_04") = sourceReq.Field("RQ_USER_04")
                                newReq.Field("RQ_USER_05") = sourceReq.Field("RQ_USER_05")
                                newReq.Field("RQ_USER_07") = sourceReq.Field("RQ_USER_07")
                                newReq.Field("RQ_USER_08") = sourceReq.ID                        ' For ones synched to MOE, add the old MOE ID in Opt. ID 2

                            Else

                                ' Set the New related source and ID to MOE's current info...

                                newReq.Field("RQ_USER_04") = sourceReq.ID
                                newReq.Field("RQ_USER_05") = curSource
                                newReq.Field("RQ_USER_07") = sProject

                            End If

                            newReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                            newReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                            newReq.Field("RQ_USER_06") = sourceReq.Field("RQ_USER_06")
                            newReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                            newReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                            newReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")

                            newReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                            newReq.Field("RQ_USER_12") = sourceReq.Field("RQ_REQ_AUTHOR")

                            newReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                            newReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                            newReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")

                            ' Post the requirement...

                            newReq.Post()
                            reportWrite.WriteLine(sourceReqID & ": New related ALM requirement created")

                            ' Now move it to the synch temp folder...

                            notMoved = True
                            dupeCount = 0
                            origName = newReq.Field("RQ_REQ_NAME")

                            While notMoved

                                Try

                                    newReq.Move(moveToFolderID, -4)
                                    notMoved = False

                                Catch ex As Exception

                                    ' Means one with that name is already in the SynchTemp...
                                    dupeCount = dupeCount + 1
                                    newReq.Field("RQ_REQ_NAME") = origName & " - Duplicate # " & dupeCount
                                    newReq.Post()

                                End Try

                            End While

                            ' ...and now try moving it to the correct location...

                            Try

                                moveToFolderID = setReqFolder(newReq.ID)
                                newReq.Move(moveToFolderID, -4)

                            Catch ex2 As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not moved: " & ex2.Message)

                            End Try

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceReqID & ": Related requirement not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

        If sqlString2 <> "" Then

            tdconCommand2 = tdconSource.Command
            tdconCommand2.CommandText = sqlString2
            tdconRecSet2 = tdconCommand2.Execute

            If tdconRecSet2.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

                ndx1 = 1

                While ndx1 <= tdconRecSet2.RecordCount

                    sourceReqID = tdconRecSet2.FieldValue(0)
                    sourceReq = tdconSourceReqFactory.Item(sourceReqID)

                    RunStatus.Text = "Processing requirement # " & sourceReq.ID & " from " & sProject & "..."
                    Application.DoEvents()

                    badRecord = False

                    ' Verify the straight assign fields...

                    If sourceReq.Field("RQ_USER_01") <> "" Then

                        If projectName.Contains(sourceReq.Field("RQ_USER_01")) Then
                            ' Project Name is right...
                        Else
                            ' Project Name is wrong...
                            reportWrite.WriteLine(sourceReqID & ": Invalid project name: " & sourceReq.Field("RQ_USER_01"))
                            badRecord = True
                        End If

                    Else

                        ' Project Name is missing...
                        reportWrite.WriteLine(sourceReqID & ": Missing project name")
                        badRecord = True

                    End If

                    If sourceReq.Field("RQ_USER_02") <> "" Then

                        If relName.Contains(sourceReq.Field("RQ_USER_02")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceReqID & ": Invalid release name: " & sourceReq.Field("RQ_USER_02"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceReqID & ": Missing release name")
                        badRecord = True

                    End If

                    If sourceReq.Field("RQ_USER_03") <> "" Then

                        If appName.Contains(sourceReq.Field("RQ_USER_03")) Then
                            ' Application Name is right...
                        Else
                            ' Application Name is wrong...
                            reportWrite.WriteLine(sourceReqID & ": Invalid application name: " & sourceReq.Field("RQ_USER_03"))
                            badRecord = True
                        End If

                    Else

                        ' Application Name is missing...
                        reportWrite.WriteLine(sourceReqID & ": Missing application name")
                        badRecord = True

                    End If

                    If badRecord = False Then

                        ' Check to see if the requirement is already in...look in Related ID field...

                        sqlString3 = "select RQ_REQ_ID from req where RQ_USER_07 = '" & sProject & "' and RQ_USER_04 = '" & sourceReqID & "'"

                        tdconCommand3 = tdconTarget.Command
                        tdconCommand3.CommandText = sqlString3
                        tdconRecSet3 = tdconCommand3.Execute

                        If tdconRecSet3.RecordCount > 0 Then

                            foundGood = False

                            If tdconRecSet3.RecordCount > 1 Then

                                ' As the source is ALM, we need to be sure there's only ONE active synch target...
                                ' If there is more than one, then there are dupes and we have to find the specific active one...

                                ndx2 = 1

                                While ndx2 <= tdconRecSet3.RecordCount

                                    tempReqID = tdconRecSet3.FieldValue(0)
                                    tempReq = tdconTargetReqFactory.Item(tempReqID)

                                    If tempReq.Field("RQ_USER_06") <> "Obsolete" Then

                                        ' Found a non-duplicate...exit the loop...
                                        foundGood = True
                                        Exit While

                                    End If

                                    tdconRecSet3.Next()

                                    ndx2 = ndx2 + 1

                                End While

                            Else

                                ' Just one record is already in...fetch it and check for updates...
                                foundGood = True
                                tempReqID = tdconRecSet3.FieldValue(0)
                                tempReq = tdconTargetReqFactory.Item(tempReqID)

                            End If

                            ' Correct source defect found...proceed with processing...

                            If foundGood Then

                                Try

                                    wasChanged = False

                                    ' Compare and change just what's changed so the audit table reads right...

                                    If tempReq.Field("RQ_USER_07") <> sourceReq.Field("RQ_USER_08") Then
                                        tempReq.Field("RQ_USER_07") = sourceReq.Field("RQ_USER_08")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_COMMENT") <> sourceReq.Field("RQ_REQ_COMMENT") Then
                                        tempReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_STATUS") <> sourceReq.Field("RQ_REQ_STATUS") Then
                                        tempReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_06") <> sourceReq.Field("RQ_USER_06") Then
                                        tempReq.Field("RQ_USER_06") = sourceReq.Field("RQ_USER_06")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_01") <> sourceReq.Field("RQ_USER_01") Then
                                        tempReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_02") <> sourceReq.Field("RQ_USER_02") Then
                                        tempReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_USER_03") <> sourceReq.Field("RQ_USER_03") Then
                                        tempReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_AUTHOR") <> sourceReq.Field("RQ_REQ_AUTHOR") Then
                                        If sourceReq.Field("RQ_REQ_AUTHOR") = "" Then
                                            tempReq.Field("RQ_REQ_AUTHOR") = "sv-alm-syncprod"
                                        Else
                                            tempReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                        End If
                                        tempReq.Field("RQ_USER_12") = tempReq.Field("RQ_REQ_AUTHOR")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_DATE") <> sourceReq.Field("RQ_REQ_DATE") Then
                                        tempReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                        wasChanged = True
                                    End If

                                    If tempReq.Field("RQ_REQ_NAME") <> sourceReq.Field("RQ_REQ_NAME") Then

                                        origName = tempReq.Field("RQ_REQ_NAME")

                                        If origName.Contains(" - Duplicate # ") Then

                                            ' We don't rename duplicates...it causes issues later...

                                        Else

                                            ' If the name is unique, it can be renamed...

                                            tempReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                            wasChanged = True

                                        End If

                                    End If

                                    If tempReq.Field("RQ_REQ_PRIORITY") <> sourceReq.Field("RQ_REQ_PRIORITY") Then
                                        tempReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")
                                        wasChanged = True
                                    End If

                                    ' Post the requirement...
                                    If wasChanged Then

                                        tempReq.Post()
                                        reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " updated")

                                    End If

                                Catch ex As Exception

                                    reportWrite.WriteLine(sourceReqID & ": Related requirement # " & tempReqID & " not updated: " & ex.Message)

                                End Try

                            Else

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not updated - more than one found active, or related requirement deleted!")

                            End If

                        Else

                            Try

                                ' It's not...create new from the fields...
                                newReq = tdconTargetReqFactory.AddItem(System.DBNull.Value)

                                newReq.Field("RQ_TYPE_ID") = sourceReq.Field("RQ_TYPE_ID")

                                If sourceReq.Field("RQ_USER_04") <> "" Then

                                    ' Set the New related source and ID to the same as it was in MOE...

                                    newReq.Field("RQ_USER_04") = sourceReq.Field("RQ_USER_04")
                                    newReq.Field("RQ_USER_05") = sourceReq.Field("RQ_USER_05")
                                    newReq.Field("RQ_USER_07") = sourceReq.Field("RQ_USER_07")
                                    newReq.Field("RQ_USER_08") = sourceReq.ID                        ' For ones synched to MOE, add the old MOE ID in Opt. ID 2

                                Else

                                    ' Set the New related source and ID to MOE's current info...

                                    newReq.Field("RQ_USER_04") = sourceReq.ID
                                    newReq.Field("RQ_USER_05") = curSource
                                    newReq.Field("RQ_USER_07") = sProject

                                End If

                                newReq.Field("RQ_REQ_COMMENT") = sourceReq.Field("RQ_REQ_COMMENT")
                                newReq.Field("RQ_REQ_STATUS") = sourceReq.Field("RQ_REQ_STATUS")
                                newReq.Field("RQ_USER_06") = sourceReq.Field("RQ_USER_06")
                                newReq.Field("RQ_USER_01") = sourceReq.Field("RQ_USER_01")
                                newReq.Field("RQ_USER_02") = sourceReq.Field("RQ_USER_02")
                                newReq.Field("RQ_USER_03") = sourceReq.Field("RQ_USER_03")

                                newReq.Field("RQ_REQ_AUTHOR") = sourceReq.Field("RQ_REQ_AUTHOR")
                                newReq.Field("RQ_USER_12") = sourceReq.Field("RQ_REQ_AUTHOR")

                                newReq.Field("RQ_REQ_DATE") = sourceReq.Field("RQ_REQ_DATE")
                                newReq.Field("RQ_REQ_NAME") = sourceReq.Field("RQ_REQ_NAME")
                                newReq.Field("RQ_REQ_PRIORITY") = sourceReq.Field("RQ_REQ_PRIORITY")

                                ' Post the requirement...

                                newReq.Post()
                                reportWrite.WriteLine(sourceReqID & ": New related ALM requirement created")

                                ' Now move it to the synch temp folder...

                                notMoved = True
                                dupeCount = 0
                                origName = newReq.Field("RQ_REQ_NAME")

                                While notMoved

                                    Try

                                        newReq.Move(moveToFolderID, -4)
                                        notMoved = False

                                    Catch ex As Exception

                                        ' Means one with that name is already in the SynchTemp...
                                        dupeCount = dupeCount + 1
                                        newReq.Field("RQ_REQ_NAME") = origName & " - Duplicate # " & dupeCount
                                        newReq.Post()

                                    End Try

                                End While

                                ' ...and now try moving it to the correct location...

                                Try

                                    moveToFolderID = setReqFolder(newReq.ID)
                                    newReq.Move(moveToFolderID, -4)

                                Catch ex2 As Exception

                                    reportWrite.WriteLine(sourceReqID & ": Related requirement not moved: " & ex2.Message)

                                End Try

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceReqID & ": Related requirement not created: " & ex.Message)

                            End Try

                        End If

                    End If

                    ' Update the status bars...

                    tdconRecSet2.Next()

                    fileProgress.Value = 100 * (ndx1 / tdconRecSet2.RecordCount)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                End While

            End If

        End If

    End Sub

    Sub processTruistALMTests(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        tdconTargetTestFactory = tdconTarget.TestFactory
        tdconSourceTestFactory = tdconSource.TestFactory

        curSource = "Truist ALM"

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        testTreeMgr = tdconTarget.TreeManager
        workingFolder = testTreeMgr.NodeByPath("Subject\001_SynchTemp")
        moveToFolderID = workingFolder.NodeID
        tdconTargetTestFactory = workingFolder.TestFactory

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select ts_test_id from test where (ts_vts >= '" & checkFromDate & "' and ts_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and TS_USER_02 like '2022%'"
            sqlString = sqlString & " and TS_USER_05 NOT LIKE '%ALM%' order by ts_test_id"

            sqlString2 = "select ts_test_id from test where (ts_vts >= '" & checkFromDate & "' and ts_vts <= '" & checkToDate & "')"
            sqlString2 = sqlString2 & " and TS_USER_02 like '2022%'"
            sqlString2 = sqlString2 & " and TS_USER_05 is NULL order by ts_test_id"

        Else

            ' Fetch all MOE-specific tests in the current source since the last run...
            ' MOE-specific are indicated if the Related Source does not contain "ALM"...

            sqlString = "select ts_test_id from test where ts_vts > '" & lastChecked & "' and TS_USER_02 like '2022%'"
            sqlString = sqlString & " and TS_USER_05 NOT LIKE '%ALM%' order by ts_test_id"

            sqlString2 = "select ts_test_id from test where ts_vts > '" & lastChecked & "' and TS_USER_02 like '2022%'"
            sqlString2 = sqlString2 & " and TS_USER_05 is NULL order by ts_test_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestID = tdconRecSet.FieldValue(0)
                sourceTest = tdconSourceTestFactory.Item(sourceTestID)

                RunStatus.Text = "Processing Test # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("TS_USER_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("TS_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid project name: " & sourceTestSet.Field("TS_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("TS_USER_02") <> "" Then

                    If relName.Contains(sourceTestSet.Field("TS_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid release name: " & sourceTestSet.Field("TS_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("TS_USER_03") <> "" Then

                    If appName.Contains(sourceTestSet.Field("TS_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestID & ": Invalid application name: " & sourceTestSet.Field("TS_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestID & ": Missing application name")
                    badRecord = True

                End If

                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test is already in...look in Related ID field...

                    sqlString3 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                    tdconCommand3 = tdconTarget.Command
                    tdconCommand3.CommandText = sqlString3
                    tdconRecSet3 = tdconCommand3.Execute

                    If tdconRecSet3.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet3.RecordCount > 1 Then

                            ' As the source is ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet3.RecordCount

                                tempTestID = tdconRecSet3.FieldValue(0)
                                tempTest = tdconTargetTestFactory.Item(tempTestID)

                                If tempTest.Field("TS_USER_06") <> "Obsolete" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet3.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempTestID = tdconRecSet3.FieldValue(0)
                            tempTest = tdconTargetTestFactory.Item(tempTestID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTest.Field("TS_USER_06") <> sourceTestSet.Field("TS_USER_06") Then
                                    tempTest.Field("TS_USER_06") = sourceTestSet.Field("TS_USER_06")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_DESCRIPTION") <> sourceTestSet.Field("TS_DESCRIPTION") Then
                                    tempTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_EXEC_STATUS") <> sourceTestSet.Field("TS_EXEC_STATUS") Then
                                    tempTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_STATUS") <> sourceTestSet.Field("TS_STATUS") Then
                                    tempTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_DEV_COMMENTS") <> sourceTestSet.Field("TS_DEV_COMMENTS") Then
                                    tempTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_TYPE") <> sourceTestSet.Field("TS_TYPE") Then
                                    tempTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_01") <> sourceTestSet.Field("TS_USER_01") Then
                                    tempTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_02") <> sourceTestSet.Field("TS_USER_02") Then
                                    tempTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_03") <> sourceTestSet.Field("TS_USER_03") Then
                                    tempTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_12") <> sourceTestSet.Field("TS_USER_07") Then
                                    tempTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_07")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_USER_25") <> sourceTestSet.Field("TS_USER_25") Then
                                    tempTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_25")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_RESPONSIBLE") <> sourceTestSet.Field("TS_RESPONSIBLE") Then
                                    tempTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_CREATION_DATE") <> sourceTestSet.Field("TS_CREATION_DATE") Then
                                    tempTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                    wasChanged = True
                                End If

                                If tempTest.Field("TS_NAME") <> sourceTestSet.Field("TS_NAME") Then

                                    origName = tempTest.Field("TS_NAME")

                                    If origName.Contains(" - Duplicate # ") Then

                                        ' We don't rename duplicates...it causes issues later...

                                    Else

                                        ' If the name is unique, it can be renamed...

                                        tempTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")
                                        wasChanged = True

                                    End If

                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTest.Post()
                                    reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " updated")

                                End If

                                ' Test processed...now work with the Design Steps...

                                If sourceTestSet.DesStepsNum > 0 Then

                                    ' This test has design steps...see if there were changes...

                                    Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                End If

                                ' If Automated Tests option selected, perform the repo copy...

                                If doAutoTests.Checked Then

                                    Try

                                        RunStatus.Text = "Starting the test repo copy..."
                                        Application.DoEvents()

                                        sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                        testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                        sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                        sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                        ' Bring locally the test's repo...
                                        testSourceExtendedStorage.Load("-r *.*", True)

                                        testTargetExtendedStorage = newTest.ExtendedStorage

                                        targetTestClientPath = testTargetExtendedStorage.ClientPath
                                        targetTestServerPath = testTargetExtendedStorage.ServerPath

                                        testTargetExtendedStorage.Load("-r *.*", True)

                                        ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                        My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                        ' Save the repo...
                                        testTargetExtendedStorage.Save("-r *.*", True)

                                        tempTest.Post()

                                        ' If successful, delete the local copies to keep space usage low...

                                        My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                        My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                    Catch ex2 As Exception

                                        reportWrite.WriteLine(sourceTestID & ": Related Test's repo not updated:", ex2.Message)

                                    End Try

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestID & ": Related Test not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newTest = tdconTargetTestFactory.AddItem(System.DBNull.Value)

                            newTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")

                            If sourceTestSet.Field("TS_USER_04") <> "" Then

                                ' Set the New related source and ID to the same as it was in MOE...
                                newTest.Field("TS_USER_04") = sourceTestSet.Field("TS_USER_04")
                                newTest.Field("TS_USER_05") = sourceTestSet.Field("TS_USER_05")
                                newTest.Field("TS_USER_07") = sourceTestSet.Field("TS_USER_08")
                                newTest.Field("TS_USER_08") = sourceTestSet.ID

                            Else

                                ' Set the New related source and ID to MOE's current info...
                                newTest.Field("TS_USER_04") = sourceTestSet.ID
                                newTest.Field("TS_USER_05") = curSource
                                newTest.Field("TS_USER_07") = sProject

                            End If

                            newTest.Field("TS_USER_06") = sourceTestSet.Field("TS_USER_06")
                            newTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_07")
                            newTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                            newTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")

                            newTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                            newTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")

                            newTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                            newTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                            newTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")

                            If sourceTestSet.Field("TS_USER_25") = "" Then
                                newTest.Field("TS_USER_25") = "N/A"
                            Else
                                newTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_25")
                            End If

                            newTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")

                            newTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                            newTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")

                            ' Post the test...

                            newTest.Post()
                            reportWrite.WriteLine(sourceTestID & ": New related ALM Test created")

                            ' ...and now move it to the correct location...

                            moveToFolderID = setTestFolder(newTest.ID)

                            tempTestID = newTest.ID
                            sqlString4 = "update test set ts_subject = " & moveToFolderID & " where ts_test_id = " & tempTestID

                            tdconCommand4 = tdconTarget.Command
                            tdconCommand4.CommandText = sqlString
                            tdconRecSet4 = tdconCommand4.Execute

                            tempTest.Post()

                            ' Test created...now work with the Design Steps...

                            If sourceTestSet.DesStepsNum > 0 Then

                                ' This test has design steps...see if there were changes...

                                Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                            End If


                            ' If Automated Tests option selected, perform the repo copy...

                            If doAutoTests.Checked Then

                                Try

                                    RunStatus.Text = "Starting the test repo copy..."
                                    Application.DoEvents()

                                    sourceTest = tdconSourceTestFactory.Item(tempTestID)
                                    testSourceExtendedStorage = sourceTestSet.ExtendedStorage

                                    sourceTestClientPath = testSourceExtendedStorage.ClientPath
                                    sourceTestServerPath = testSourceExtendedStorage.ServerPath

                                    ' Bring locally the test's repo...
                                    testSourceExtendedStorage.Load("-r *.*", True)

                                    testTargetExtendedStorage = newTest.ExtendedStorage

                                    targetTestClientPath = testTargetExtendedStorage.ClientPath
                                    targetTestServerPath = testTargetExtendedStorage.ServerPath

                                    testTargetExtendedStorage.Load("-r *.*", True)

                                    ' Copy the files from sourceTestClientPath to targetTestClientPath through Windows...

                                    My.Computer.FileSystem.CopyDirectory(sourceTestClientPath, targetTestClientPath, True)

                                    ' Save the repo...
                                    testTargetExtendedStorage.Save("-r *.*", True)

                                    newTest.Post()

                                    ' If successful, delete the local copies to keep space usage low...

                                    My.Computer.FileSystem.DeleteDirectory(sourceTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
                                    My.Computer.FileSystem.DeleteDirectory(targetTestClientPath, FileIO.DeleteDirectoryOption.DeleteAllContents)

                                Catch ex2 As Exception

                                    reportWrite.WriteLine(sourceTestID & ": Related Test's repo not created:", ex2.Message)

                                End Try

                            End If

                            ' Link test to requirement...

                            ' testNum = newTest.ID
                            ' Call AddTestToCoverage(reqNum, testNum)

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

        If sqlString2 <> "" Then

            tdconCommand2 = tdconSource.Command
            tdconCommand2.CommandText = sqlString2
            tdconRecSet2 = tdconCommand2.Execute

            If tdconRecSet2.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet2.RecordCount & " records to be examined...")

                ndx1 = 1

                While ndx1 <= tdconRecSet2.RecordCount

                    sourceTestID = tdconRecSet2.FieldValue(0)
                    sourceTest = tdconSourceTestFactory.Item(sourceTestID)

                    RunStatus.Text = "Processing Test # " & sourceTestSet.ID & " from " & sProject & "..."
                    Application.DoEvents()

                    badRecord = False

                    ' Verify the straight assign fields...

                    If sourceTestSet.Field("TS_USER_01") <> "" Then

                        If projectName.Contains(sourceTestSet.Field("TS_USER_01")) Then
                            ' Project Name is right...
                        Else
                            ' Project Name is wrong...
                            reportWrite.WriteLine(sourceTestID & ": Invalid project name: " & sourceTestSet.Field("TS_USER_01"))
                            badRecord = True
                        End If

                    Else

                        ' Project Name is missing...
                        reportWrite.WriteLine(sourceTestID & ": Missing project name")
                        badRecord = True

                    End If

                    If sourceTestSet.Field("TS_USER_02") <> "" Then

                        If relName.Contains(sourceTestSet.Field("TS_USER_02")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceTestID & ": Invalid release name: " & sourceTestSet.Field("TS_USER_02"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceTestID & ": Missing release name")
                        badRecord = True

                    End If

                    If sourceTestSet.Field("TS_USER_03") <> "" Then

                        If appName.Contains(sourceTestSet.Field("TS_USER_03")) Then
                            ' Application Name is right...
                        Else
                            ' Application Name is wrong...
                            reportWrite.WriteLine(sourceTestID & ": Invalid application name: " & sourceTestSet.Field("TS_USER_03"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceTestID & ": Missing application name")
                        badRecord = True

                    End If

                    ' Map these fields to the target values...

                    If badRecord = False Then

                        ' Check to see if the Test is already in...look in Related ID field...

                        sqlString3 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                        tdconCommand3 = tdconTarget.Command
                        tdconCommand3.CommandText = sqlString3
                        tdconRecSet3 = tdconCommand3.Execute

                        If tdconRecSet3.RecordCount > 0 Then

                            foundGood = False

                            If tdconRecSet3.RecordCount > 1 Then

                                ' As the source is ALM, we need to be sure there's only ONE active synch target...
                                ' If there is more than one, then there are dupes and we have to find the specific active one...

                                ndx2 = 1

                                While ndx2 <= tdconRecSet3.RecordCount

                                    tempTestID = tdconRecSet3.FieldValue(0)
                                    tempTest = tdconTargetTestFactory.Item(tempTestID)

                                    If tempTest.Field("TS_USER_06") <> "Obsolete" Then

                                        ' Found a non-duplicate...exit the loop...
                                        foundGood = True
                                        Exit While

                                    End If

                                    tdconRecSet3.Next()

                                    ndx2 = ndx2 + 1

                                End While

                            Else

                                ' Just one record is already in...fetch it and check for updates...
                                foundGood = True
                                tempTestID = tdconRecSet3.FieldValue(0)
                                tempTest = tdconTargetTestFactory.Item(tempTestID)

                            End If

                            ' Correct source defect found...proceed with processing...

                            If foundGood Then

                                Try

                                    wasChanged = False

                                    ' Compare and change just what's changed so the audit table reads right...

                                    If tempTest.Field("TS_USER_06") <> sourceTestSet.Field("TS_USER_06") Then
                                        tempTest.Field("TS_USER_06") = sourceTestSet.Field("TS_USER_06")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_DESCRIPTION") <> sourceTestSet.Field("TS_DESCRIPTION") Then
                                        tempTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_EXEC_STATUS") <> sourceTestSet.Field("TS_EXEC_STATUS") Then
                                        tempTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_STATUS") <> sourceTestSet.Field("TS_STATUS") Then
                                        tempTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_DEV_COMMENTS") <> sourceTestSet.Field("TS_DEV_COMMENTS") Then
                                        tempTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_TYPE") <> sourceTestSet.Field("TS_TYPE") Then
                                        tempTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_01") <> sourceTestSet.Field("TS_USER_01") Then
                                        tempTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_02") <> sourceTestSet.Field("TS_USER_02") Then
                                        tempTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_03") <> sourceTestSet.Field("TS_USER_03") Then
                                        tempTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_12") <> sourceTestSet.Field("TS_USER_07") Then
                                        tempTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_07")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_USER_25") <> sourceTestSet.Field("TS_USER_25") Then
                                        tempTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_25")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_RESPONSIBLE") <> sourceTestSet.Field("TS_RESPONSIBLE") Then
                                        tempTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_CREATION_DATE") <> sourceTestSet.Field("TS_CREATION_DATE") Then
                                        tempTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                        wasChanged = True
                                    End If

                                    If tempTest.Field("TS_NAME") <> sourceTestSet.Field("TS_NAME") Then

                                        origName = tempTest.Field("TS_NAME")

                                        If origName.Contains(" - Duplicate # ") Then

                                            ' We don't rename duplicates...it causes issues later...

                                        Else

                                            ' If the name is unique, it can be renamed...

                                            tempTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")
                                            wasChanged = True

                                        End If

                                    End If

                                    ' Post the test...
                                    If wasChanged Then

                                        tempTest.Post()
                                        reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " updated")

                                    End If

                                    ' Test processed...now work with the Design Steps...

                                    If sourceTestSet.DesStepsNum > 0 Then

                                        ' This test has design steps...see if there were changes...

                                        Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                    End If

                                Catch ex As Exception

                                    reportWrite.WriteLine(sourceTestID & ": Related Test # " & tempTestID & " not updated: " & ex.Message)

                                End Try

                            Else

                                reportWrite.WriteLine(sourceTestID & ": Related Test not updated - more than one found active, or related Test deleted!")

                            End If

                        Else

                            Try

                                ' It's not...create new from the fields...
                                newTest = tdconTargetTestFactory.AddItem(System.DBNull.Value)

                                newTest.Field("TS_TYPE") = sourceTestSet.Field("TS_TYPE")

                                If sourceTestSet.Field("TS_USER_04") <> "" Then

                                    ' Set the New related source and ID to the same as it was in MOE...
                                    newTest.Field("TS_USER_04") = sourceTestSet.Field("TS_USER_04")
                                    newTest.Field("TS_USER_05") = sourceTestSet.Field("TS_USER_05")
                                    newTest.Field("TS_USER_07") = sourceTestSet.Field("TS_USER_08")
                                    newTest.Field("TS_USER_08") = sourceTestSet.ID

                                Else

                                    ' Set the New related source and ID to MOE's current info...
                                    newTest.Field("TS_USER_04") = sourceTestSet.ID
                                    newTest.Field("TS_USER_05") = curSource
                                    newTest.Field("TS_USER_07") = sProject

                                End If

                                newTest.Field("TS_USER_06") = sourceTestSet.Field("TS_USER_06")
                                newTest.Field("TS_USER_12") = sourceTestSet.Field("TS_USER_07")
                                newTest.Field("TS_DESCRIPTION") = sourceTestSet.Field("TS_DESCRIPTION")
                                newTest.Field("TS_DEV_COMMENTS") = sourceTestSet.Field("TS_DEV_COMMENTS")

                                newTest.Field("TS_STATUS") = sourceTestSet.Field("TS_STATUS")
                                newTest.Field("TS_EXEC_STATUS") = sourceTestSet.Field("TS_EXEC_STATUS")

                                newTest.Field("TS_USER_01") = sourceTestSet.Field("TS_USER_01")
                                newTest.Field("TS_USER_02") = sourceTestSet.Field("TS_USER_02")
                                newTest.Field("TS_USER_03") = sourceTestSet.Field("TS_USER_03")

                                If sourceTestSet.Field("TS_USER_25") = "" Then
                                    newTest.Field("TS_USER_25") = "N/A"
                                Else
                                    newTest.Field("TS_USER_25") = sourceTestSet.Field("TS_USER_25")
                                End If

                                newTest.Field("TS_RESPONSIBLE") = sourceTestSet.Field("TS_RESPONSIBLE")

                                newTest.Field("TS_CREATION_DATE") = sourceTestSet.Field("TS_CREATION_DATE")
                                newTest.Field("TS_NAME") = sourceTestSet.Field("TS_NAME")

                                ' Post the test...

                                newTest.Post()
                                reportWrite.WriteLine(sourceTestID & ": New related ALM Test created")

                                ' ...and now move it to the correct location...

                                moveToFolderID = setTestFolder(newTest.ID)

                                tempTestID = newTest.ID
                                sqlString4 = "update test set ts_subject = " & moveToFolderID & " where ts_test_id = " & tempTestID

                                tdconCommand4 = tdconTarget.Command
                                tdconCommand4.CommandText = sqlString4
                                tdconRecSet4 = tdconCommand4.Execute

                                ' Test created...now work with the Design Steps...

                                If sourceTestSet.DesStepsNum > 0 Then

                                    ' This test has design steps...see if there were changes...

                                    Call CopyDesignSteps(sourceTestSet.ID, tempTestID)

                                End If

                                ' Link test to requirement...

                                ' testNum = newTest.ID
                                ' Call AddTestToCoverage(reqNum, testNum)

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestID & ": Related Test not created: " & ex.Message)

                            End Try

                        End If

                    End If

                    ' Update the status bars...

                    tdconRecSet2.Next()

                    fileProgress.Value = 100 * (ndx1 / tdconRecSet2.RecordCount)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                End While

            End If

        End If

    End Sub

    Sub processTruistALMTestSets(sDomain, sProject)

        Dim foundGood, notMoved As Boolean
        Dim tempString, origName As String
        Dim tempArray As Object
        Dim dupeCount, testnum As Integer

        curSource = "Truist ALM"

        tdconTargetTestFactory = tdconTarget.TestFactory

        ' Set the initial destination for all new tests to the 001_SynchTemp folder...

        tdconTargetTSFolderFactory = tdconTarget.TestLabFolderFactory
        targetTSFilter = tdconTargetTSFolderFactory.Filter
        targetTSFilter.Filter("CF_ITEM_NAME") = "001_SynchTemp"

        targetTSFList = targetTSFilter.NewList()

        If targetTSFList.Count > 0 Then

            targetTestSetFolder = targetTSFList.Item(1)
            tdconTargetTestSetFactory = targetTestSetFolder.TestSetFactory

        End If

        tdconSourceTestSetFactory = tdconSource.TestSetFactory

        ' Get the list of test sets modified in the source since the last run or by the specified date range...

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select cy_cycle_id from cycle where (cy_vts >= '" & checkFromDate & "' and cy_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and CY_USER_02 like '2022%' order by cy_cycle_id"

        Else

            ' Just fetch all test sets in the current source since the last run...

            sqlString = "select cy_cycle_id from cycle where cy_vts > '" & lastChecked & "' and CY_USER_02 like '2022%' order by cy_cycle_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceTestSetID = tdconRecSet.FieldValue(0)
                sourceTestSet = tdconSourceTestSetFactory.Item(sourceTestSetID)

                RunStatus.Text = "Processing Test Set # " & sourceTestSet.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceTestSet.Field("CY_USER_01") <> "" Then

                    If projectName.Contains(sourceTestSet.Field("CY_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid project name: " & sourceTestSet.Field("CY_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing project name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_02") <> "" Then

                    If relName.Contains(sourceTestSet.Field("CY_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid release name: " & sourceTestSet.Field("CY_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing release name")
                    badRecord = True

                End If

                If sourceTestSet.Field("CY_USER_03") <> "" Then

                    If appName.Contains(sourceTestSet.Field("CY_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceTestSetID & ": Invalid application name: " & sourceTestSet.Field("CY_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceTestSetID & ": Missing application name")
                    badRecord = True

                End If


                ' Map these fields to the target values...

                If badRecord = False Then

                    ' Check to see if the Test Set is already in...look in Related ID field...

                    sqlString2 = "select CY_CYCLE_ID from Cycle where CY_USER_08 = '" & sProject & "' and CY_USER_04 = '" & sourceTestID & "'"

                    tdconCommand2 = tdconTarget.Command
                    tdconCommand2.CommandText = sqlString2
                    tdconRecSet2 = tdconCommand2.Execute

                    If tdconRecSet2.RecordCount > 0 Then

                        foundGood = False

                        ' Just one record is already in...fetch it and check for updates...

                        foundGood = True
                        tempTestSetID = tdconRecSet2.FieldValue(0)
                        tempTestSet = tdconTargetTestFactory.Item(tempTestSetID)

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                ' Compare and change just what's changed so the audit table reads right...

                                If tempTestSet.Field("CY_CYCLE") <> sourceTestSet.Field("CY_CYCLE") Then
                                    tempTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_SUBTYPE_ID") <> sourceTestSet.Field("CY_SUBTYPE_ID") Then
                                    tempTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_STATUS") <> sourceTestSet.Field("CY_STATUS") Then
                                    tempTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_COMMENT") <> sourceTestSet.Field("CY_COMMENT") Then
                                    tempTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_TYPE") <> sourceTestSet.Field("CY_TYPE") Then
                                    tempTestSet.Field("CY_TYPE") = sourceTestSet.Field("CY_TYPE")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_01") <> sourceTestSet.Field("CY_USER_01") Then
                                    tempTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_01")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_02") <> sourceTestSet.Field("CY_USER_02") Then
                                    tempTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_02")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_03") <> sourceTestSet.Field("CY_USER_03") Then
                                    tempTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_03")
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_04") <> sourceTestSet.ID Then
                                    tempTestSet.Field("CY_USER_04") = sourceTestSet.ID
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_05") <> curSource Then
                                    tempTestSet.Field("CY_USER_05") = curSource
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_08") <> sProject Then
                                    tempTestSet.Field("CY_USER_08") = sProject
                                    wasChanged = True
                                End If

                                If tempTestSet.Field("CY_USER_07") <> sourceTestSet.Field("CY_USER_07") Then
                                    tempTestSet.Field("CY_USER_07") = sourceTestSet.Field("CY_USER_07")
                                    wasChanged = True
                                End If

                                ' Post the test...
                                If wasChanged Then

                                    tempTestSet.Post()
                                    reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestSetID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceTestSetID & ": Related Test Set # " & tempTestID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test Set not updated - more than one found active, or related Test deleted!")

                        End If

                    Else

                        Try

                            ' Create new test set from the fields...
                            newTestSet = tdconTargetTestSetFactory.AddItem(System.DBNull.Value)

                            newTestSet.Field("CY_CYCLE") = sourceTestSet.Field("CY_CYCLE")
                            newTestSet.Field("CY_SUBTYPE_ID") = sourceTestSet.Field("CY_SUBTYPE_ID")

                            newTestSet.Field("CY_USER_04") = sourceTestSet.ID
                            newTestSet.Field("CY_USER_05") = curSource
                            newTestSet.Field("CY_USER_07") = sourceTestSet.Field("CY_USER_07")
                            newTestSet.Field("CY_USER_08") = sProject
                            newTestSet.Field("CY_COMMENT") = sourceTestSet.Field("CY_COMMENT")

                            newTestSet.Field("CY_STATUS") = sourceTestSet.Field("CY_STATUS")

                            newTestSet.Field("CY_USER_01") = sourceTestSet.Field("CY_USER_01")
                            newTestSet.Field("CY_USER_02") = sourceTestSet.Field("CY_USER_02")
                            newTestSet.Field("CY_USER_03") = sourceTestSet.Field("CY_USER_03")

                            ' Post the test set...

                            newTestSet.Post()

                            reportWrite.WriteLine(sourceTestSetID & ": New related ALM Test Set created")

                            ' ...now loop over the source test set test factory to add known ones to this new test set...

                            sourceTSTFactory = sourceTestSet.TSTestFactory
                            sourceTSTFList = sourceTSTFactory.NewList("")

                            targetTSTFactory = newTestSet.TSTestFactory

                            For Each sourceTSTest In sourceTSTFList

                                sourceTestID = sourceTSTest.TestId

                                ' See if this test is already in the target...

                                sqlString2 = "select TS_Test_ID from Test where TS_USER_07 = '" & sProject & "' and TS_USER_04 = '" & sourceTestID & "'"

                                tdconCommand2 = tdconTarget.Command
                                tdconCommand2.CommandText = sqlString2
                                tdconRecSet2 = tdconCommand2.Execute

                                If tdconRecSet2.RecordCount > 0 Then

                                    ' Found the test...

                                    tempTestID = tdconRecSet2.FieldValue(0)
                                    tempTest = tdconTargetTestFactory.Item(tempTestID)

                                    targetTSTFactory.AddItem(tempTest)

                                Else

                                    RunStatus.Text = "Error:  Source test # " & sourceTestID & " not found in target..."
                                    Application.DoEvents()

                                End If

                            Next

                            ' ...and now move it to the correct folder...

                            RunStatus.Text = "Moving the test set from the temp synch folder..."
                            Application.DoEvents()

                            moveToFolderID = setTestSetFolder(newTestSet.ID)

                            tempTestSetID = newTestSet.ID
                            sqlString = "update cycle set cy_folder_id = " & moveToFolderID & " where cy_cycle_id = " & tempTestSetID

                            tdconCommand2 = tdconTarget.Command
                            tdconCommand2.CommandText = sqlString
                            tdconRecSet2 = tdconCommand2.Execute

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceTestSetID & ": Related Test not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

    End Sub

    Sub processTruistALMDefects(sDomain, sProject)

        Dim foundGood As Boolean

        ' Fetch all MOE-specific defects in the current source since the last run...
        ' MOE-specific are indicated if the Related Source does not contain "ALM"...
        ' MOE created are indicated with Related Source being empty...

        curSource = "Truist ALM"

        If checkTo.Checked Then

            ' Constain the date modified range...

            sqlString = "select bg_bug_id from bug where (bg_vts >= '" & checkFromDate & "' and bg_vts <= '" & checkToDate & "')"
            sqlString = sqlString & " and BG_USER_02 like '2022%' and BG_USER_05 NOT LIKE '%ALM%' order by bg_bug_id"

            sqlString2 = "select bg_bug_id from bug where (bg_vts >= '" & checkFromDate & "' and bg_vts <= '" & checkToDate & "')"
            sqlString2 = sqlString2 & " and BG_USER_02 like '2022%' and BG_USER_05 IS NULL order by bg_bug_id"

        Else

            ' Range is from specified start until current run time...

            sqlString = "select bg_bug_id from bug where bg_vts > '" & lastChecked & "' and BG_USER_02 like '2022%' and BG_USER_05 NOT LIKE '%ALM%' order by bg_bug_id"

            sqlString2 = "select bg_bug_id from bug where bg_vts > '" & lastChecked & "' and BG_USER_02 like '2022%' and BG_USER_05 IS NULL order by bg_bug_id"

        End If

        tdconCommand = tdconSource.Command
        tdconCommand.CommandText = sqlString
        tdconRecSet = tdconCommand.Execute

        If tdconRecSet.RecordCount > 0 Then

            ' This pass is for records NOT from other ALMs in MOE...

            reportWrite.WriteLine("--> Found " & tdconRecSet.RecordCount & " records to be examined...")

            ndx1 = 1

            While ndx1 <= tdconRecSet.RecordCount

                sourceBugID = tdconRecSet.FieldValue(0)
                sourceBug = tdconSource.BugFactory.Item(sourceBugID)

                RunStatus.Text = "Processing defect # " & sourceBug.ID & " from " & sProject & "..."
                Application.DoEvents()

                badRecord = False

                ' Verify the straight assign fields...

                If sourceBug.Field("BG_USER_01") <> "" Then

                    If projectName.Contains(sourceBug.Field("BG_USER_01")) Then
                        ' Project Name is right...
                    Else
                        ' Project Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid project name: " & sourceBug.Field("BG_USER_01"))
                        badRecord = True
                    End If

                Else

                    ' Project Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing project name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_02") <> "" Then

                    If relName.Contains(sourceBug.Field("BG_USER_02")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid Detected On release name: " & sourceBug.Field("BG_USER_02"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing Detected On release name")
                    badRecord = True

                End If

                If sourceBug.Field("BG_USER_08") <> "" Then

                    If relName.Contains(sourceBug.Field("BG_USER_08")) Then
                        ' Release Name is right...
                    Else
                        ' Release Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid Installed release name: " & sourceBug.Field("BG_USER_08"))
                        badRecord = True
                    End If

                End If

                If sourceBug.Field("BG_USER_03") <> "" Then

                    If appName.Contains(sourceBug.Field("BG_USER_03")) Then
                        ' Application Name is right...
                    Else
                        ' Application Name is wrong...
                        reportWrite.WriteLine(sourceBugID & ": Invalid application name: " & sourceBug.Field("BG_USER_03"))
                        badRecord = True
                    End If

                Else

                    ' Release Name is missing...
                    reportWrite.WriteLine(sourceBugID & ": Missing application name")
                    badRecord = True

                End If


                If badRecord = False Then

                    ' Check to see if the defect is already in...look in the correct Related ID field...

                    If sourceBug.Field("BG_USER_04") <> "" Then

                        ' In MOE from another location...check the Optional ID 2 field...
                        sqlString3 = "select BG_BUG_ID from bug where BG_USER_05 = '" & sourceBug.Field("BG_USER_05") & "' and BG_USER_08 = '" & sourceBugID & "'"

                    Else

                        ' Created in MOE...check the Related ID field...
                        sqlString3 = "select BG_BUG_ID from bug where BG_USER_05 = 'Truist ALM' and BG_USER_04 = '" & sourceBugID & "'"

                    End If

                    tdconCommand3 = tdconTarget.Command
                    tdconCommand3.CommandText = sqlString3
                    tdconRecSet3 = tdconCommand3.Execute

                    If tdconRecSet3.RecordCount > 0 Then

                        foundGood = False

                        If tdconRecSet3.RecordCount > 1 Then

                            ' As the source is ALM, we need to be sure there's only ONE active synch target...
                            ' If there is more than one, then there are dupes and we have to find the specific active one...

                            ndx2 = 1

                            While ndx2 <= tdconRecSet3.RecordCount

                                tempBugID = tdconRecSet3.FieldValue(0)
                                tempBug = tdconTarget.BugFactory.Item(tempBugID)

                                If tempBug.Field("BG_USER_18") <> "Duplicate Defect" Then

                                    ' Found a non-duplicate...exit the loop...
                                    foundGood = True
                                    Exit While

                                End If

                                tdconRecSet3.Next()

                                ndx2 = ndx2 + 1

                            End While

                        Else

                            ' Just one record is already in...fetch it and check for updates...
                            foundGood = True
                            tempBugID = tdconRecSet3.FieldValue(0)
                            tempBug = tdconTarget.BugFactory.Item(tempBugID)

                        End If

                        ' Correct source defect found...proceed with processing...

                        If foundGood Then

                            Try

                                wasChanged = False

                                'Compare and change just what's changed so the audit table reads right...

                                If tempBug.Field("BG_USER_07") <> sourceBug.Field("BG_USER_07") Then
                                    tempBug.Field("BG_USER_07") = sourceBug.Field("BG_USER_07")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DESCRIPTION") <> sourceBug.Field("BG_DESCRIPTION") Then
                                    tempBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_STATUS") <> sourceBug.Field("BG_STATUS") Then
                                    tempBug.Field("BG_STATUS") = sourceBug.Field("BG_STATUS")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_01") <> sourceBug.Field("BG_USER_01") Then
                                    tempBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_01")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_02") <> sourceBug.Field("BG_USER_02") Then
                                    tempBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_02")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_14") <> sourceBug.Field("BG_USER_12") Then
                                    tempBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_12")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_03") <> sourceBug.Field("BG_USER_03") Then
                                    tempBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_03")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DETECTED_BY") <> sourceBug.Field("BG_DETECTED_BY") Then
                                    tempBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_DETECTION_DATE") <> sourceBug.Field("BG_DETECTION_DATE") Then
                                    tempBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_13") <> sourceBug.Field("BG_USER_11") Then
                                    tempBug.Field("BG_USER_13") = sourceBug.Field("BG_USER_11")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_16") <> sourceBug.Field("BG_USER_10") Then
                                    tempBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_10")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_12") <> sourceBug.Field("BG_USER_08") Then
                                    tempBug.Field("BG_USER_12") = sourceBug.Field("BG_USER_08")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_USER_26") <> sourceBug.Field("BG_USER_26") Then
                                    tempBug.Field("BG_USER_26") = sourceBug.Field("BG_USER_26")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_SEVERITY") <> sourceBug.Field("BG_SEVERITY") Then
                                    tempBug.Field("BG_SEVERITY") = sourceBug.Field("BG_SEVERITY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_SUMMARY") <> sourceBug.Field("BG_SUMMARY") Then
                                    tempBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_RESPONSIBLE") <> sourceBug.Field("BG_RESPONSIBLE") Then
                                    tempBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_PRIORITY") <> sourceBug.Field("BG_PRIORITY") Then
                                    tempBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                                    wasChanged = True
                                End If

                                If tempBug.Field("BG_CLOSING_DATE") <> sourceBug.Field("BG_CLOSING_DATE") Then
                                    tempBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")
                                    wasChanged = True
                                End If

                                ' Post the defect...
                                If wasChanged Then

                                    tempBug.Post()
                                    reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " updated")

                                End If

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " not updated: " & ex.Message)

                            End Try

                        Else

                            reportWrite.WriteLine(sourceBugID & ": Related defect not updated - more than one found active, or related defect deleted!")

                        End If

                    Else

                        Try

                            ' It's not...create new from the fields...
                            newBug = tdconTarget.BugFactory.AddItem(System.DBNull.Value)

                            If sourceBug.Field("BG_USER_04") <> "" Then

                                ' Set the New related source and ID to the same as it was in MOE...

                                newBug.Field("BG_USER_04") = sourceBug.Field("BG_USER_04")
                                newBug.Field("BG_USER_05") = sourceBug.Field("BG_USER_05")
                                newBug.Field("BG_USER_07") = sourceBug.Field("BG_USER_07")
                                newBug.Field("BG_USER_08") = sourceBug.ID

                            Else

                                ' Set the New related source and ID to MOE's current info...

                                newBug.Field("BG_USER_04") = sourceBug.ID
                                newBug.Field("BG_USER_05") = curSource
                                newBug.Field("BG_USER_07") = sProject

                            End If

                            newBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                            newBug.Field("BG_STATUS") = sourceBug.Field("BG_STATUS")
                            newBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_01")
                            newBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_02")
                            newBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_03")
                            newBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_10")
                            newBug.Field("BG_USER_12") = sourceBug.Field("BG_USER_08")
                            newBug.Field("BG_USER_26") = sourceBug.Field("BG_USER_26")

                            newBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                            newBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                            newBug.Field("BG_USER_13") = sourceBug.Field("BG_USER_11")
                            newBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_12")
                            newBug.Field("BG_SEVERITY") = sourceBug.Field("BG_SEVERITY")
                            newBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                            newBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                            newBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                            newBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")

                            ' Post the defect...

                            newBug.Post()
                            reportWrite.WriteLine(sourceBugID & ": New related ALM defect created")

                        Catch ex As Exception

                            reportWrite.WriteLine(sourceBugID & ": Related defect not created: " & ex.Message)

                        End Try

                    End If

                End If

                ' Update the status bars...

                tdconRecSet.Next()

                fileProgress.Value = 100 * (ndx1 / tdconRecSet.RecordCount)
                Application.DoEvents()

                ndx1 = ndx1 + 1

            End While

        End If

        If sqlString2 <> "" Then

            ' This pass is looking for MOE-created defects ONLY...

            tdconCommand2 = tdconSource.Command
            tdconCommand2.CommandText = sqlString2
            tdconRecSet2 = tdconCommand2.Execute

            If tdconRecSet2.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet2.RecordCount & " records to be examined...")

                ndx1 = 1

                While ndx1 <= tdconRecSet2.RecordCount

                    sourceBugID = tdconRecSet2.FieldValue(0)
                    sourceBug = tdconSource.BugFactory.Item(sourceBugID)

                    RunStatus.Text = "Processing defect # " & sourceBug.ID & " from " & sProject & "..."
                    Application.DoEvents()

                    badRecord = False

                    ' Verify the straight assign fields...

                    If sourceBug.Field("BG_USER_01") <> "" Then

                        If projectName.Contains(sourceBug.Field("BG_USER_01")) Then
                            ' Project Name is right...
                        Else
                            ' Project Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid project name: " & sourceBug.Field("BG_USER_01"))
                            badRecord = True
                        End If

                    Else

                        ' Project Name is missing...
                        reportWrite.WriteLine(sourceBugID & ": Missing project name")
                        badRecord = True

                    End If

                    If sourceBug.Field("BG_USER_02") <> "" Then

                        If relName.Contains(sourceBug.Field("BG_USER_02")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid Detected On release name: " & sourceBug.Field("BG_USER_02"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceBugID & ": Missing Detected On release name")
                        badRecord = True

                    End If

                    If sourceBug.Field("BG_USER_08") <> "" Then

                        If relName.Contains(sourceBug.Field("BG_USER_08")) Then
                            ' Release Name is right...
                        Else
                            ' Release Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid Installed release name: " & sourceBug.Field("BG_USER_08"))
                            badRecord = True
                        End If

                    End If

                    If sourceBug.Field("BG_USER_03") <> "" Then

                        If appName.Contains(sourceBug.Field("BG_USER_03")) Then
                            ' Application Name is right...
                        Else
                            ' Application Name is wrong...
                            reportWrite.WriteLine(sourceBugID & ": Invalid application name: " & sourceBug.Field("BG_USER_03"))
                            badRecord = True
                        End If

                    Else

                        ' Release Name is missing...
                        reportWrite.WriteLine(sourceBugID & ": Missing application name")
                        badRecord = True

                    End If


                    If badRecord = False Then

                        ' Check to see if the defect is already in...look in Related ID field...

                        sqlString3 = "select BG_BUG_ID from bug where BG_USER_05 = 'Truist ALM' and BG_USER_04 = '" & sourceBugID & "'"

                        tdconCommand3 = tdconTarget.Command
                        tdconCommand3.CommandText = sqlString3
                        tdconRecSet3 = tdconCommand3.Execute

                        If tdconRecSet3.RecordCount > 0 Then

                            foundGood = False

                            If tdconRecSet3.RecordCount > 1 Then

                                ' As the source is ALM, we need to be sure there's only ONE active synch target...
                                ' If there is more than one, then there are dupes and we have to find the specific active one...

                                ndx2 = 1

                                While ndx2 <= tdconRecSet3.RecordCount

                                    tempBugID = tdconRecSet3.FieldValue(0)
                                    tempBug = tdconTarget.BugFactory.Item(tempBugID)

                                    If tempBug.Field("BG_USER_18") <> "Duplicate Defect" Then

                                        ' Found a non-duplicate...exit the loop...
                                        foundGood = True
                                        Exit While

                                    End If

                                    tdconRecSet2.Next()

                                    ndx2 = ndx2 + 1

                                End While

                            Else

                                ' Just one record is already in...fetch it and check for updates...
                                foundGood = True
                                tempBugID = tdconRecSet2.FieldValue(0)
                                tempBug = tdconTarget.BugFactory.Item(tempBugID)

                            End If

                            ' Correct source defect found...proceed with processing...

                            If foundGood Then

                                Try

                                    wasChanged = False

                                    'Compare and change just what's changed so the audit table reads right...

                                    If tempBug.Field("BG_USER_07") <> sourceBug.Field("BG_USER_07") Then
                                        tempBug.Field("BG_USER_07") = sourceBug.Field("BG_USER_07")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_DESCRIPTION") <> sourceBug.Field("BG_DESCRIPTION") Then
                                        tempBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_STATUS") <> sourceBug.Field("BG_STATUS") Then
                                        tempBug.Field("BG_STATUS") = sourceBug.Field("BG_STATUS")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_01") <> sourceBug.Field("BG_USER_01") Then
                                        tempBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_01")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_02") <> sourceBug.Field("BG_USER_02") Then
                                        tempBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_02")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_14") <> sourceBug.Field("BG_USER_12") Then
                                        tempBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_12")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_03") <> sourceBug.Field("BG_USER_03") Then
                                        tempBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_03")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_DETECTED_BY") <> sourceBug.Field("BG_DETECTED_BY") Then
                                        tempBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_DETECTION_DATE") <> sourceBug.Field("BG_DETECTION_DATE") Then
                                        tempBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_13") <> sourceBug.Field("BG_USER_11") Then
                                        tempBug.Field("BG_USER_13") = sourceBug.Field("BG_USER_11")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_16") <> sourceBug.Field("BG_USER_10") Then
                                        tempBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_10")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_12") <> sourceBug.Field("BG_USER_08") Then
                                        tempBug.Field("BG_USER_12") = sourceBug.Field("BG_USER_08")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_USER_26") <> sourceBug.Field("BG_USER_26") Then
                                        tempBug.Field("BG_USER_26") = sourceBug.Field("BG_USER_26")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_SEVERITY") <> sourceBug.Field("BG_SEVERITY") Then
                                        tempBug.Field("BG_SEVERITY") = sourceBug.Field("BG_SEVERITY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_SUMMARY") <> sourceBug.Field("BG_SUMMARY") Then
                                        tempBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_RESPONSIBLE") <> sourceBug.Field("BG_RESPONSIBLE") Then
                                        tempBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_PRIORITY") <> sourceBug.Field("BG_PRIORITY") Then
                                        tempBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                                        wasChanged = True
                                    End If

                                    If tempBug.Field("BG_CLOSING_DATE") <> sourceBug.Field("BG_CLOSING_DATE") Then
                                        tempBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")
                                        wasChanged = True
                                    End If

                                    ' Post the defect...
                                    If wasChanged Then

                                        tempBug.Post()
                                        reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " updated")

                                    End If

                                Catch ex As Exception

                                    reportWrite.WriteLine(sourceBugID & ": Related defect # " & tempBugID & " not updated: " & ex.Message)

                                End Try

                            Else

                                reportWrite.WriteLine(sourceBugID & ": Related defect not updated - more than one found active, or related defect deleted!")

                            End If

                        Else

                            Try

                                ' It's not...create new from the fields...
                                newBug = tdconTarget.BugFactory.AddItem(System.DBNull.Value)

                                If sourceBug.Field("BG_USER_04") <> "" Then

                                    ' Set the New related source and ID to the same as it was in MOE...

                                    newBug.Field("BG_USER_04") = sourceBug.Field("BG_USER_04")
                                    newBug.Field("BG_USER_05") = sourceBug.Field("BG_USER_05")
                                    newBug.Field("BG_USER_07") = sourceBug.Field("BG_USER_07")
                                    newBug.Field("BG_USER_08") = sourceBug.ID

                                Else

                                    ' Set the New related source and ID to MOE's current info...

                                    newBug.Field("BG_USER_04") = sourceBug.ID
                                    newBug.Field("BG_USER_05") = curSource
                                    newBug.Field("BG_USER_07") = sProject

                                End If

                                newBug.Field("BG_DESCRIPTION") = sourceBug.Field("BG_DESCRIPTION")
                                newBug.Field("BG_STATUS") = sourceBug.Field("BG_STATUS")
                                newBug.Field("BG_USER_01") = sourceBug.Field("BG_USER_01")
                                newBug.Field("BG_USER_02") = sourceBug.Field("BG_USER_02")
                                newBug.Field("BG_USER_03") = sourceBug.Field("BG_USER_03")
                                newBug.Field("BG_USER_16") = sourceBug.Field("BG_USER_10")
                                newBug.Field("BG_USER_12") = sourceBug.Field("BG_USER_08")
                                newBug.Field("BG_USER_26") = sourceBug.Field("BG_USER_26")

                                newBug.Field("BG_DETECTED_BY") = sourceBug.Field("BG_DETECTED_BY")
                                newBug.Field("BG_DETECTION_DATE") = sourceBug.Field("BG_DETECTION_DATE")
                                newBug.Field("BG_USER_13") = sourceBug.Field("BG_USER_11")
                                newBug.Field("BG_USER_14") = sourceBug.Field("BG_USER_12")
                                newBug.Field("BG_SEVERITY") = sourceBug.Field("BG_SEVERITY")
                                newBug.Field("BG_SUMMARY") = sourceBug.Field("BG_SUMMARY")
                                newBug.Field("BG_RESPONSIBLE") = sourceBug.Field("BG_RESPONSIBLE")
                                newBug.Field("BG_PRIORITY") = sourceBug.Field("BG_PRIORITY")
                                newBug.Field("BG_CLOSING_DATE") = sourceBug.Field("BG_CLOSING_DATE")

                                ' Post the defect...

                                newBug.Post()
                                reportWrite.WriteLine(sourceBugID & ": New related ALM defect created")

                            Catch ex As Exception

                                reportWrite.WriteLine(sourceBugID & ": Related defect not created: " & ex.Message)

                            End Try

                        End If

                    End If

                    ' Update the status bars...

                    tdconRecSet2.Next()

                    fileProgress.Value = 100 * (ndx1 / tdconRecSet2.RecordCount)
                    Application.DoEvents()

                    ndx1 = ndx1 + 1

                End While

            End If

        End If

    End Sub

    Sub CopyDesignSteps(fromTestID, toTestID)

        Dim dndx, sndx, tndx As Integer
        Dim stepModified As String
        Dim workingDate As Date
        Dim wasChanged As Boolean

        ' The source test has design steps...create/update them on the target copy...

        sourceTest = tdconSourceTestFactory.Item(fromTestID)
        tempTest = tdconTargetTestFactory.Item(toTestID)

        ' Set the design step factories...
        tdconSourceDesignStepFactory = sourceTestSet.DesignStepFactory
        tdconTargetDesignStepFactory = tempTest.DesignStepFactory

        sndx = sourceTestSet.DesStepsNum
        tndx = tempTest.DesStepsNum

        ' Check the target test step count - if 0, then create all the source steps...

        If tempTest.DesStepsNum = 0 Then

            ' Loop over the source step factory and create steps in the target...

            sqlString3 = "select DS_ID from dessteps where DS_TEST_ID = " & fromTestID

            tdconCommand3 = tdconSource.Command
            tdconCommand3.CommandText = sqlString3
            tdconRecSet3 = tdconCommand3.Execute

            If tdconRecSet3.RecordCount > 0 Then

                reportWrite.WriteLine("--> Found " & tdconRecSet3.RecordCount & " steps to be created...")

                dndx = 1

                While dndx <= tdconRecSet3.RecordCount

                    sndx = tdconRecSet3.FieldValue(0)

                    sourceStep = tdconSourceDesignStepFactory.Item(sndx)
                    targetStep = tdconTargetDesignStepFactory.AddItem(vbNull)

                    RunStatus.Text = "     Creating step '" & sourceStep.StepName & "' for test ID # " & toTestID & "..."
                    Application.DoEvents()

                    targetStep.StepName = sourceStep.StepName
                    targetStep.StepDescription = sourceStep.StepDescription
                    targetStep.StepExpectedResult = sourceStep.StepExpectedResult
                    targetStep.Order = sourceStep.Order

                    targetStep.Field("DS_USER_02") = sourceStep.ID
                    targetStep.Field("DS_USER_03") = curSource
                    targetStep.Field("DS_USER_04") = sProject

                    targetStep.Post()

                    tdconRecSet3.Next()

                    dndx = dndx + 1

                End While

            End If

            reportWrite.WriteLine(fromTestID & ": Related Test # " & toTestID & " - " & tdconRecSet3.RecordCount & " design steps created")

        Else

            wasChanged = False

            sqlString3 = "select DS_ID from dessteps where DS_TEST_ID = " & fromTestID

            tdconCommand3 = tdconSource.Command
            tdconCommand3.CommandText = sqlString3
            tdconRecSet3 = tdconCommand3.Execute

            ' Loop over each step to see if the source has changed...

            dndx = 1

            While dndx <= tdconRecSet3.RecordCount

                sndx = tdconRecSet3.FieldValue(0)

                sourceStep = tdconSourceDesignStepFactory.Item(sndx)
                stepModified = "#" & sourceStep.Field("DS_VTS") & "#"
                workingDate = stepModified
                stepModified = workingDate.ToString("yyyy-MM-dd HH:mm:ss")

                If stepModified >= lastChecked Then

                    ' A change has been made to this specific step...find the specific step and update the fields in the related one...

                    sqlString4 = "select DS_ID from dessteps where DS_USER_03 = '" & curSource & "' and DS_USER_02 = " & sourceStep.ID

                    tdconCommand4 = tdconTarget.Command
                    tdconCommand4.CommandText = sqlString4
                    tdconRecSet4 = tdconCommand4.Execute

                    If tdconRecSet4.RecordCount > 0 Then

                        tndx = tdconRecSet4.FieldValue(0)

                        ' Specific step found...update it...

                        targetStep = tdconTargetDesignStepFactory.Item(tndx)

                        RunStatus.Text = "     Updating step '" & targetStep.StepName & "' for test ID # " & toTestID & "..."
                        Application.DoEvents()

                        targetStep.StepName = sourceStep.StepName
                        targetStep.StepDescription = sourceStep.StepDescription
                        targetStep.StepExpectedResult = sourceStep.StepExpectedResult
                        targetStep.Order = sourceStep.Order

                        targetStep.Post()

                        wasChanged = True

                    End If

                End If

                tdconRecSet3.Next()

                dndx = dndx + 1

            End While

            If wasChanged Then reportWrite.WriteLine(fromTestID & ": Related Test # " & toTestID & " - design steps updated")

        End If

    End Sub
    Sub AddTestToCoverage(reqID, testID)

        ' Add this specific test to the existing requirement coverage...

        Try

            synchTempReqFactory = tdconSource.ReqFactory
            tempReq2 = synchTempReqFactory.Item(reqID)
            coverableReq = tempReq2
            coverableReq.AddTestToCoverage(testID)

            reportWrite.WriteLine(reqID & ": requirement linked to test " & testID)

            coverableReq = Nothing
            synchTempReqFactory = Nothing
            tempReq2 = Nothing

        Catch ex As Exception

            reportWrite.WriteLine(reqID & ": requirement not linked to test " & testID & " : " & ex.Message)

        End Try

    End Sub

    Public Function setReqFolder(ByVal reqID) As String

        Dim tempP, tempR, tempA, workingPath, tempSource, foundTag As String
        Dim folderNotFound As Boolean

        ' Create/Get the folder this requirement should go into...

        tempReq = tdconTargetReqFactory.Item(reqID)
        tempSource = "Synched from " & tempReq.Field("RQ_USER_05")

        ' Get the "Big 3" to make sure this one goes to the right place...

        tempP = tempReq.Field("RQ_USER_01")
        tempR = tempReq.Field("RQ_USER_02")
        tempA = tempReq.Field("RQ_USER_03")


        ' Check the internal table of already existing 'Synched from' folders...

        workingPath = tempP & "\" & tempR & "\" & tempA & "\" & tempSource

        ' Trace down to the existing desired path...

        curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", tempP, 16)
        If curLocation.Count > 0 Then

            ' This is top level - make sure the first result is NOT lower...

            foundTag = ""
            folderNotFound = False
            If curLocation.Count > 1 Then
                For ndx5 = 1 To curLocation.Count
                    foundTag = curLocation.Item(ndx5)
                    ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
                    ' Check the "parent" of this folder to see it it's at the top...
                    tempReq2 = tdconTargetReqFactory.Item(ndx3)
                    If tempReq2.ParentId = 0 Then
                        folderNotFound = False
                        Exit For
                    Else
                        folderNotFound = True
                    End If
                Next

                ' If we get here, then the "find" only returned deeper levels...so assume it's new...

                If folderNotFound Then

                    ' Create Project Folder under root...
                    tempReq2 = tdconTargetReqFactory.AddItem(-1)
                    tempReq2.Field("RQ_REQ_NAME") = tempP
                    tempReq2.Field("RQ_REQ_AUTHOR") = txtUser.Text
                    tempReq2.Field("RQ_TYPE_ID") = "Folder"
                    tempReq2.Post()
                    tempReq2 = Nothing
                    ' Now get its ID to go on...
                    curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", tempP, 16)
                    foundTag = curLocation.Item(1)
                    ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))

                End If

            Else
                foundTag = curLocation.Item(1)
            End If
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))

        Else
            ' Create Project Folder under root...
            tempReq2 = tdconTargetReqFactory.AddItem(-1)
            tempReq2.Field("RQ_REQ_NAME") = tempP
            tempReq2.Field("RQ_REQ_AUTHOR") = txtUser.Text
            tempReq2.Field("RQ_TYPE_ID") = "Folder"
            tempReq2.Post()
            tempReq2 = Nothing
            ' Now get its ID to go on...
            curLocation = tdconTargetReqFactory.Find(-1, "RQ_REQ_NAME", tempP, 16)
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))

        End If

        curLocation = tdconTargetReqFactory.Find(ndx3, "RQ_REQ_NAME", tempR, 16)
        If curLocation.Count > 0 Then
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
        Else
            ' Create Release Folder under the Project folder...
            tempReq2 = tdconTargetReqFactory.AddItem(ndx3)
            tempReq2.Field("RQ_REQ_NAME") = tempR
            tempReq2.Field("RQ_REQ_AUTHOR") = txtUser.Text
            tempReq2.Field("RQ_TYPE_ID") = "Folder"
            tempReq2.Post()
            tempReq2 = Nothing
            ' Now get its ID to go on...
            curLocation = tdconTargetReqFactory.Find(ndx3, "RQ_REQ_NAME", tempR, 16)
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
        End If

        curLocation = tdconTargetReqFactory.Find(ndx3, "RQ_REQ_NAME", tempA, 16)
        If curLocation.Count > 0 Then
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
        Else
            ' Create Application Folder under the Release folder...
            tempReq2 = tdconTargetReqFactory.AddItem(ndx3)
            tempReq2.Field("RQ_REQ_NAME") = tempA
            tempReq2.Field("RQ_REQ_AUTHOR") = txtUser.Text
            tempReq2.Field("RQ_TYPE_ID") = "Folder"
            tempReq2.Post()
            tempReq2 = Nothing
            ' Now get its ID to go on...
            curLocation = tdconTargetReqFactory.Find(ndx3, "RQ_REQ_NAME", tempA, 16)
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
        End If

        curLocation = tdconTargetReqFactory.Find(ndx3, "RQ_REQ_NAME", tempSource, 16)

        If curLocation.Count > 0 Then
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
        Else
            ' Create Application Folder under the Release folder...
            tempReq2 = tdconTargetReqFactory.AddItem(ndx3)
            tempReq2.Field("RQ_REQ_NAME") = tempSource
            tempReq2.Field("RQ_REQ_AUTHOR") = txtUser.Text
            tempReq2.Field("RQ_TYPE_ID") = "Folder"
            tempReq2.Post()
            tempReq2 = Nothing
            ' Now get its ID to go on...
            curLocation = tdconTargetReqFactory.Find(ndx3, "RQ_REQ_NAME", tempSource, 16)
            foundTag = curLocation.Item(1)
            ndx3 = foundTag.Substring(0, foundTag.IndexOf(","))
        End If

        ' Proper location found - return the index...

        Return (ndx3)

    End Function

    Public Function setTestFolder(ByVal testID) As String

        Dim tempP, tempR, tempA, tempSource As String

        tempTest = tdconTargetTestFactory.Item(testID)
        tempSource = "Synched from " & tempTest.Field("TS_USER_05")

        ' Get the "Big 3" to make sure this one goes to the right place...

        tempP = tempTest.Field("TS_USER_01")
        tempR = tempTest.Field("TS_USER_02")
        tempA = tempTest.Field("TS_USER_03")

        ' See if the top-level project folder found...

        testTreeMgr = tdconTarget.TreeManager

        Try

            workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP)

            ' Check next for the release...

            Try

                workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR)

                ' Check next for application...

                Try

                    workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA)

                    ' Finally for the synch-specific folder...

                    Try

                        workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA & "\" & tempSource)
                        moveToFolderID = workingFolder.NodeID

                    Catch ex4 As Exception

                        ' Doesn't exist...create it...

                        workingNode = workingFolder.AddNode(tempSource)
                        workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA & "\" & tempSource)

                        moveToFolderID = workingFolder.NodeID

                    End Try

                Catch ex3 As Exception

                    ' Application doesn't exist...create the rest...

                    workingNode = workingFolder.AddNode(tempA)
                    workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA)
                    workingNode = workingFolder.AddNode(tempSource)
                    workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA & "\" & tempSource)

                    moveToFolderID = workingFolder.NodeID

                End Try

            Catch ex2 As Exception

                ' Release doesn't exist...create the next ones all at once...

                workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP)
                workingNode = workingFolder.AddNode(tempR)
                workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR)
                workingNode = workingFolder.AddNode(tempA)
                workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA)
                workingNode = workingFolder.AddNode(tempSource)
                workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA & "\" & tempSource)

                moveToFolderID = workingFolder.NodeID

            End Try

        Catch ex As Exception

            ' Project folder does not exist, so we can create all four levels in one pass...

            testTreeMgr = tdconTarget.TreeManager

            workingFolder = testTreeMgr.NodeByPath("Subject")
            workingNode = workingFolder.AddNode(tempP)
            workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP)
            workingNode = workingFolder.AddNode(tempR)
            workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR)
            workingNode = workingFolder.AddNode(tempA)
            workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA)
            workingNode = workingFolder.AddNode(tempSource)
            workingFolder = testTreeMgr.NodeByPath("Subject\" & tempP & "\" & tempR & "\" & tempA & "\" & tempSource)

            moveToFolderID = workingFolder.NodeID

        End Try

        ' Proper location found - move the current test to there...

        Return (moveToFolderID)

    End Function

    Public Function setTestSetFolder(ByVal testSetID) As String

        Dim tempP, tempR, tempA, tempSource As String
        Dim targetProjTSFList, targetRelTSFList, targetAppTSFList, targetsynchFTSFList As TDAPIOLELib.List

        tdconTargetTestSetFactory = tdconTarget.TestSetFactory

        tempTestSet = tdconTargetTestSetFactory.Item(testSetID)
        tempSource = "Synched from " & tempTestSet.Field("CY_USER_05")

        ' Get the "Big 3" to make sure this one goes to the right place...

        tempP = tempTestSet.Field("CY_USER_01")
        tempR = tempTestSet.Field("CY_USER_02")
        tempA = tempTestSet.Field("CY_USER_03")

        ' See if the top-level project folder found...

        tdconTargetTSFolderFactory = tdconTarget.TestLabFolderFactory
        targetTSFilter = tdconTargetTSFolderFactory.Filter
        targetTSFilter.Filter("CF_ITEM_NAME") = "'" & tempP & "'"

        targetProjTSFList = targetTSFilter.NewList()

        If targetProjTSFList.Count > 0 Then

            ' Project folder found...

            targetTestSetFolder = targetProjTSFList.Item(1)

            tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
            targetTSFilter = tdconTargetTSFolderFactory.Filter
            targetTSFilter.Filter("CF_ITEM_NAME") = "'" & tempR & "'"

            targetRelTSFList = targetTSFilter.NewList()

            If targetRelTSFList.Count > 0 Then

                ' Release folder found...

                targetTestSetFolder = targetRelTSFList.Item(1)

                tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
                targetTSFilter = tdconTargetTSFolderFactory.Filter
                targetTSFilter.Filter("CF_ITEM_NAME") = "'" & tempA & "'"

                targetAppTSFList = targetTSFilter.NewList()

                If targetAppTSFList.Count > 0 Then

                    ' Application folder found...

                    targetTestSetFolder = targetAppTSFList.Item(1)

                    tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
                    targetTSFilter = tdconTargetTSFolderFactory.Filter
                    targetTSFilter.Filter("CF_ITEM_NAME") = "'" & tempSource & "'"

                    targetsynchFTSFList = targetTSFilter.NewList()

                    If targetsynchFTSFList.Count > 0 Then

                        targetTestSetFolder = targetsynchFTSFList.Item(1)

                    Else

                        ' Create synched from folder...
                        targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
                        targetTestSetFolder.Field("CF_ITEM_NAME") = tempSource
                        targetTestSetFolder.Post()

                    End If

                    moveToFolderID = targetTestSetFolder.ID

                Else

                    ' Create application folder...
                    targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
                    targetTestSetFolder.Field("CF_ITEM_NAME") = tempA
                    targetTestSetFolder.Post()

                    ' Create synched from folder...
                    tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
                    targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
                    targetTestSetFolder.Field("CF_ITEM_NAME") = tempSource
                    targetTestSetFolder.Post()

                    moveToFolderID = targetTestSetFolder.ID

                End If

            Else

                ' Create release folder...
                targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
                targetTestSetFolder.Field("CF_ITEM_NAME") = tempR
                targetTestSetFolder.Post()

                ' Create application folder...
                tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
                targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
                targetTestSetFolder.Field("CF_ITEM_NAME") = tempA
                targetTestSetFolder.Post()

                ' Create synched from folder...
                tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
                targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
                targetTestSetFolder.Field("CF_ITEM_NAME") = tempSource
                targetTestSetFolder.Post()

                moveToFolderID = targetTestSetFolder.ID

            End If

        Else

            ' Create project folder...
            tdconTargetTSFolderFactory = tdconTarget.TestLabFolderFactory
            targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
            targetTestSetFolder.Field("CF_ITEM_NAME") = tempP
            targetTestSetFolder.Post()

            ' Create release folder...
            tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
            targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
            targetTestSetFolder.Field("CF_ITEM_NAME") = tempR
            targetTestSetFolder.Post()

            ' Create application folder...
            tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
            targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
            targetTestSetFolder.Field("CF_ITEM_NAME") = tempA
            targetTestSetFolder.Post()

            ' Create synched from folder...
            tdconTargetTSFolderFactory = targetTestSetFolder.TestLabFolderFactory
            targetTestSetFolder = tdconTargetTSFolderFactory.AddItem(System.DBNull.Value)
            targetTestSetFolder.Field("CF_ITEM_NAME") = tempSource
            targetTestSetFolder.Post()

            moveToFolderID = targetTestSetFolder.ID

        End If


        ' Proper location found - move the current test set to there...

        Return (moveToFolderID)

    End Function

    Private Sub GetTokens()

        Dim tokenFileName As String
        Dim strCurrent As String
        Dim strArray As Object
        Dim strTemp As String 'Store the encrypted string as it grows
        Dim strkey As String 'The encryption key
        Dim strChar1 As New Microsoft.VisualBasic.Compatibility.VB6.FixedLengthString(1) 'The first character to XOR
        Dim strChar2 As New Microsoft.VisualBasic.Compatibility.VB6.FixedLengthString(1) 'The second character to XOR

        ' Subroutine to parse, decrypt, and assign values from the program's associated token file - values used in batch mode ONLY...

        tokenFileName = almFlat_DIR & "\ALM_MDTokens.txt"
        FileOpen(1, tokenFileName, OpenMode.Input)
        strCurrent = LineInput(1)
        FileClose(1)

        strkey = "SunTrust"
        strTemp = XORDecryption(strkey, strCurrent)

        strCurrent = strTemp
        strArray = Split(strCurrent, "^")

        txtUser.Text = strArray(0)
        txtPassword.Text = strArray(1)
        cmbURL.Text = strArray(2)
        cmbDomain.Text = strArray(3)
        cmbProject.Text = strArray(4)
        doReqs.Checked = strArray(5)
        doTests.Checked = strArray(6)
        doDefects.Checked = strArray(7)

    End Sub

    Private Sub SaveTokens_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SaveTokens.Click

        ' Special button to save current field values to the encrypted token file...

        Dim tokenFileName As String
        Dim strCurrent As String
        Dim strTemp As String 'Store the encrypted string as it grows
        Dim strkey As String 'The encryption key
        Dim strChar1 As New Microsoft.VisualBasic.Compatibility.VB6.FixedLengthString(1) 'The first character to XOR
        Dim strChar2 As New Microsoft.VisualBasic.Compatibility.VB6.FixedLengthString(1) 'The second character to XOR

        tokenFileName = almFlat_DIR & "\ALM_MDTokens.txt"

        strTemp = txtUser.Text & "^" & txtPassword.Text & "^" & cmbURL.Text & "^" & cmbDomain.Text & "^" & cmbProject.Text
        strTemp = strTemp & "^" & doReqs.Checked & "^" & doTests.Checked & "^" & doDefects.Checked
        strkey = "SunTrust"
        strCurrent = XOREncryption(strkey, strTemp)

        FileOpen(1, tokenFileName, OpenMode.Output)
        PrintLine(1, strCurrent)
        FileClose(1)

    End Sub

    Private Sub GetRunTag()

        Dim tokenFileName As String
        Dim workingDate As Date

        tokenFileName = almFlat_DIR & "\ALM_MDLastRun.txt"
        FileOpen(1, tokenFileName, OpenMode.Input)
        lastChecked = LineInput(1)
        FileClose(1)

        ' Subtract a day to cover any gaps in record lock by users...

        lastChecked = "#" & lastChecked & "#"
        workingDate = lastChecked
        workingDate = workingDate.AddDays(-1)
        lastChecked = workingDate.ToString("yyyy-MM-dd HH:mm:ss")
        ticketsAfter.Value = lastChecked
        ticketsTo.Value = Now.ToString("yyyy-MM-dd HH:mm:ss")

    End Sub

    Private Sub SaveRunTag()

        ' Quick routine to save out the current date/time stamp for the next run...
        Dim tokenFIleName As String

        tokenFIleName = almFlat_DIR & "\ALM_MDLastRun.txt"
        lastChecked = Now.ToString("yyyy-MM-dd HH:mm:ss")

        FileOpen(1, tokenFIleName, OpenMode.Output)
        PrintLine(1, lastChecked)
        FileClose(1)

    End Sub

    Public Function XOREncryption(ByRef CodeKey As String, ByRef DataIn As String) As String

        Dim lonDataPtr As Integer
        Dim strDataOut As String
        Dim temp As Short
        Dim tempstring As String
        Dim intXOrValue1 As Short
        Dim intXOrValue2 As Short

        strDataOut = ""
        For lonDataPtr = 1 To Len(DataIn)
            'The first value to be XOr-ed comes from the data to be encrypted
            intXOrValue1 = Asc(Mid(DataIn, lonDataPtr, 1))
            'The second value comes from the code key
            intXOrValue2 = Asc(Mid(CodeKey, (lonDataPtr Mod Len(CodeKey)) + 1, 1))

            temp = (intXOrValue1 Xor intXOrValue2)
            tempstring = Hex(temp)
            If Len(tempstring) = 1 Then tempstring = "0" & tempstring

            strDataOut = strDataOut & tempstring
        Next lonDataPtr
        XOREncryption = strDataOut
    End Function

    Public Function XORDecryption(ByRef CodeKey As String, ByRef DataIn As String) As String

        Dim lonDataPtr As Integer
        Dim strDataOut As String
        Dim intXOrValue1 As Short
        Dim intXOrValue2 As Short

        strDataOut = ""
        For lonDataPtr = 1 To (Len(DataIn) / 2)
            'The first value to be XOr-ed comes from the data to be encrypted
            intXOrValue1 = Val("&H" & (Mid(DataIn, (2 * lonDataPtr) - 1, 2)))
            'The second value comes from the code key
            intXOrValue2 = Asc(Mid(CodeKey, (lonDataPtr Mod Len(CodeKey)) + 1, 1))

            strDataOut = strDataOut & Chr(intXOrValue1 Xor intXOrValue2)
        Next lonDataPtr
        XORDecryption = strDataOut
    End Function

    Private Sub cmdServer_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdServer.Click
        Dim dom As Integer
        Dim tdurl_arr As Object

        cmbDomain.Items.Clear()

        On Error GoTo CheckError

        If txtUser.Text = "" Or txtPassword.Text = "" Then
            MsgBox("UserID and Password are required")
            Exit Sub
        End If

        tdconTarget.InitConnectionEx(cmbURL.Text)

        If tdconTarget.Connected = False Then
            MsgBox("Can not connect to ALM target server")
            Exit Sub
        End If

        tdconTarget.Login(txtUser.Text, txtPassword.Text)

        If tdconTarget.LoggedIn = False Then
            MsgBox("Unable to login to the target.  Check User and Password information then try again.")
            Exit Sub
        End If

        For dom = 1 To tdconTarget.VisibleDomains.Count
            If tdconTarget.VisibleProjects(tdconTarget.VisibleDomains.Item(dom)).Count > 0 Then
                cmbDomain.Items.Add((tdconTarget.VisibleDomains.Item(dom)))
            End If
        Next

        '  Enable Domain selection process
        cmbDomain.Enabled = True
        cmbDomain.SelectedIndex = 0

        ' Disable Server texbox and connection button
        cmbURL.Enabled = False
        cmdServer.Enabled = False
        txtUser.Enabled = False
        txtPassword.Enabled = False
        cmdDisconnect.Enabled = True

        ' Log in to the source but not a specific project...

        Call cmdServer2()

        RunStatus.Text = "Select Quality Center target and source projects..."
        Application.DoEvents()

        Exit Sub
CheckError:
        MsgBox("cmdServer_Click Error #" & (Err.Number - vbObjectError) & Chr(13) & Err.Description, MsgBoxStyle.Critical)
    End Sub

    Private Sub cmbDomain_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmbDomain.SelectedIndexChanged
        Dim proj As Integer

        cmbProject.Items.Clear()

        For proj = 1 To tdconTarget.VisibleProjects(cmbDomain.Text).Count
            cmbProject.Items.Add((tdconTarget.VisibleProjects(cmbDomain.Text).Item(proj)))
        Next

        cmbProject.SelectedIndex = 0

        ' Enable Project and Login processes
        cmbProject.Enabled = True
        cmdLogin.Enabled = True

    End Sub

    Private Sub cmdLogin_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLogin.Click

        ' connect selected project
        tdconTarget.Connect(cmbDomain.Text, cmbProject.Text)

        ' Disable Project/login objects
        cmbDomain.Enabled = False
        cmbProject.Enabled = False
        txtUser.Enabled = False
        txtPassword.Enabled = False
        cmdLogin.Enabled = False

        If cmbDomain.SelectedIndex = 0 Or cmbDomain2.SelectedIndex = 0 Or cmbProject.SelectedIndex = 0 Or cmbProject2.SelectedIndex = 0 Then

            MsgBox("Please make sure you have selected both domain and project for both target and source!")
            Exit Sub

        End If

        ' Ready to proceed...
        RunStatus.Text = "Review source options before starting move..."
        Application.DoEvents()

    End Sub

    Private Sub cmdLogout_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdLogout.Click

        If tdconTarget.Connected = True Then
            If tdconTarget.ProjectConnected = True Then
                tdconTarget.DisconnectProject()
            End If
        End If

        ' Enable Project/login objects
        cmbDomain.Enabled = True
        cmbProject.Enabled = True
        cmdLogin.Enabled = True

        ' Disable logout
        cmdLogout.Enabled = False
        cmbDomain.Focus()

    End Sub

    Private Sub cmdDisconnect_Click(sender As Object, e As EventArgs) Handles cmdDisconnect.Click

        tdconTarget.Disconnect()

        ' Enable Server textbox and connection button
        cmbURL.Enabled = True
        cmdServer.Enabled = True
        txtUser.Enabled = True
        txtPassword.Enabled = True
        cmdDisconnect.Enabled = False

    End Sub

    Private Sub cmdServer2()
        Dim dom As Integer
        Dim tdurl_arr As Object

        cmbDomain2.Items.Clear()

        On Error GoTo CheckError

        If txtUser.Text = "" Or txtPassword.Text = "" Then
            MsgBox("UserID and Password are required")
            Exit Sub
        End If

        tdconSource.InitConnectionEx(cmbURL.Text)

        If tdconSource.Connected = False Then
            MsgBox("Can not connect to ALM source Server")
            Exit Sub
        End If

        tdconSource.Login(txtUser.Text, txtPassword.Text)

        If tdconSource.LoggedIn = False Then
            MsgBox("Unable to login to the source.  Check User and Password information then try again.")
            Exit Sub
        End If

        For dom = 1 To tdconSource.VisibleDomains.Count
            If tdconSource.VisibleProjects(tdconSource.VisibleDomains.Item(dom)).Count > 0 Then
                cmbDomain2.Items.Add((tdconSource.VisibleDomains.Item(dom)))
            End If
        Next

        '  Enable Domain selection process
        cmbDomain2.Enabled = True
        cmbDomain2.SelectedIndex = 0

        RunStatus.Text = "Select Quality Center source..."
        Application.DoEvents()

        Exit Sub
CheckError:
        MsgBox("cmdServer2_Click Error #" & (Err.Number - vbObjectError) & Chr(13) & Err.Description, MsgBoxStyle.Critical)
    End Sub

    Private Sub cmbDomain2_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmbDomain2.SelectedIndexChanged
        Dim proj As Integer

        cmbProject2.Items.Clear()

        For proj = 1 To tdconSource.VisibleProjects(cmbDomain2.Text).Count
            cmbProject2.Items.Add((tdconSource.VisibleProjects(cmbDomain2.Text).Item(proj)))
        Next

        cmbProject2.SelectedIndex = 0

        ' Enable Project and Login processes
        cmbProject2.Enabled = True

    End Sub

    Private Sub cmdLogin2()

        ' connect selected project
        tdconSource.Connect(cmbDomain2.Text, cmbProject2.Text)

        ' Disable Project/login objects
        cmbDomain2.Enabled = False
        cmbProject2.Enabled = False

        ' Ready to proceed...
        RunStatus.Text = "Review options before starting move..."
        Application.DoEvents()

    End Sub

    Private Sub cmdLogout2()

        If tdconSource.Connected = True Then
            If tdconSource.ProjectConnected = True Then
                tdconSource.DisconnectProject()
            End If
        End If

        ' Enable Project/login objects
        cmbDomain2.Enabled = True
        cmbProject2.Enabled = True

        ' Disable logout
        cmbDomain2.Focus()

    End Sub

    Private Sub cmdDisconnect2_Click(sender As Object, e As EventArgs)

        tdconSource.Disconnect()

    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click

        Try

            ' Close out the ALM connections...
            If tdconSource.Connected = True Then
                If tdconSource.ProjectConnected = True Then
                    tdconSource.DisconnectProject()
                End If
            End If

            If tdconTarget.Connected = True Then
                If tdconTarget.ProjectConnected = True Then
                    tdconTarget.DisconnectProject()
                End If
            End If

            Try

                ' Close out the Excel instance and don't save the temp sheet...
                wb1.Close(SaveChanges:=False)
                wa1.Quit()

            Catch ex2 As Exception

            End Try

        Catch ex As Exception

        End Try

        ' We're done...
        Me.Close()

    End Sub

End Class
