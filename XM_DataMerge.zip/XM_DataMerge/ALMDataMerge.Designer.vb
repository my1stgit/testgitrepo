﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ALMDataMerge
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.doLinks = New System.Windows.Forms.CheckBox()
        Me.doTestSets = New System.Windows.Forms.CheckBox()
        Me.doAttachments = New System.Windows.Forms.CheckBox()
        Me.doAutoTests = New System.Windows.Forms.CheckBox()
        Me.checkTo = New System.Windows.Forms.CheckBox()
        Me.checkFrom = New System.Windows.Forms.CheckBox()
        Me.ticketsTo = New System.Windows.Forms.DateTimePicker()
        Me.doAllProjects = New System.Windows.Forms.CheckBox()
        Me.ticketsAfter = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.doDefects = New System.Windows.Forms.CheckBox()
        Me.doTests = New System.Windows.Forms.CheckBox()
        Me.doReqs = New System.Windows.Forms.CheckBox()
        Me.frameDomain = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbProject2 = New System.Windows.Forms.ComboBox()
        Me.cmdLogout = New System.Windows.Forms.Button()
        Me.cmbDomain2 = New System.Windows.Forms.ComboBox()
        Me.cmdLogin = New System.Windows.Forms.Button()
        Me.cmbProject = New System.Windows.Forms.ComboBox()
        Me.cmbDomain = New System.Windows.Forms.ComboBox()
        Me.SaveTokens = New System.Windows.Forms.Button()
        Me.frameConnection = New System.Windows.Forms.GroupBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdDisconnect = New System.Windows.Forms.Button()
        Me.cmbURL = New System.Windows.Forms.ComboBox()
        Me.cmdServer = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.lblUrl = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.doMOESynch = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.statusBox = New System.Windows.Forms.GroupBox()
        Me.fileProgress = New System.Windows.Forms.ProgressBar()
        Me.RunStatus = New System.Windows.Forms.RichTextBox()
        Me.GroupBox1.SuspendLayout()
        Me.frameDomain.SuspendLayout()
        Me.frameConnection.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.statusBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.doLinks)
        Me.GroupBox1.Controls.Add(Me.doTestSets)
        Me.GroupBox1.Controls.Add(Me.doAttachments)
        Me.GroupBox1.Controls.Add(Me.doAutoTests)
        Me.GroupBox1.Controls.Add(Me.checkTo)
        Me.GroupBox1.Controls.Add(Me.checkFrom)
        Me.GroupBox1.Controls.Add(Me.ticketsTo)
        Me.GroupBox1.Controls.Add(Me.doAllProjects)
        Me.GroupBox1.Controls.Add(Me.ticketsAfter)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.doDefects)
        Me.GroupBox1.Controls.Add(Me.doTests)
        Me.GroupBox1.Controls.Add(Me.doReqs)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 365)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(393, 154)
        Me.GroupBox1.TabIndex = 100
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Options"
        '
        'doLinks
        '
        Me.doLinks.AutoSize = True
        Me.doLinks.Location = New System.Drawing.Point(16, 63)
        Me.doLinks.Name = "doLinks"
        Me.doLinks.Size = New System.Drawing.Size(137, 17)
        Me.doLinks.TabIndex = 53
        Me.doLinks.Text = "Req/Test/Defect Links"
        Me.doLinks.UseVisualStyleBackColor = True
        '
        'doTestSets
        '
        Me.doTestSets.AutoSize = True
        Me.doTestSets.Location = New System.Drawing.Point(16, 41)
        Me.doTestSets.Name = "doTestSets"
        Me.doTestSets.Size = New System.Drawing.Size(71, 17)
        Me.doTestSets.TabIndex = 52
        Me.doTestSets.Text = "Test Sets"
        Me.doTestSets.UseVisualStyleBackColor = True
        '
        'doAttachments
        '
        Me.doAttachments.AutoSize = True
        Me.doAttachments.Location = New System.Drawing.Point(222, 41)
        Me.doAttachments.Name = "doAttachments"
        Me.doAttachments.Size = New System.Drawing.Size(85, 17)
        Me.doAttachments.TabIndex = 51
        Me.doAttachments.Text = "Attachments"
        Me.doAttachments.UseVisualStyleBackColor = True
        '
        'doAutoTests
        '
        Me.doAutoTests.AutoSize = True
        Me.doAutoTests.Location = New System.Drawing.Point(222, 20)
        Me.doAutoTests.Name = "doAutoTests"
        Me.doAutoTests.Size = New System.Drawing.Size(106, 17)
        Me.doAutoTests.TabIndex = 50
        Me.doAutoTests.Text = "Automated Tests"
        Me.doAutoTests.UseVisualStyleBackColor = True
        '
        'checkTo
        '
        Me.checkTo.AutoSize = True
        Me.checkTo.Location = New System.Drawing.Point(16, 128)
        Me.checkTo.Name = "checkTo"
        Me.checkTo.Size = New System.Drawing.Size(103, 17)
        Me.checkTo.TabIndex = 49
        Me.checkTo.Text = "Process data to:"
        Me.checkTo.UseVisualStyleBackColor = True
        '
        'checkFrom
        '
        Me.checkFrom.AutoSize = True
        Me.checkFrom.Location = New System.Drawing.Point(16, 106)
        Me.checkFrom.Name = "checkFrom"
        Me.checkFrom.Size = New System.Drawing.Size(114, 17)
        Me.checkFrom.TabIndex = 48
        Me.checkFrom.Text = "Process data from:"
        Me.checkFrom.UseVisualStyleBackColor = True
        '
        'ticketsTo
        '
        Me.ticketsTo.CustomFormat = "yyyy-MM-dd HH:mm:ss"
        Me.ticketsTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ticketsTo.Location = New System.Drawing.Point(137, 127)
        Me.ticketsTo.Name = "ticketsTo"
        Me.ticketsTo.Size = New System.Drawing.Size(150, 20)
        Me.ticketsTo.TabIndex = 46
        '
        'doAllProjects
        '
        Me.doAllProjects.AutoSize = True
        Me.doAllProjects.Location = New System.Drawing.Point(16, 85)
        Me.doAllProjects.Name = "doAllProjects"
        Me.doAllProjects.Size = New System.Drawing.Size(158, 17)
        Me.doAllProjects.TabIndex = 45
        Me.doAllProjects.Text = "Do Standard List of Projects"
        Me.doAllProjects.UseVisualStyleBackColor = True
        '
        'ticketsAfter
        '
        Me.ticketsAfter.CustomFormat = "yyyy-MM-dd HH:mm:ss"
        Me.ticketsAfter.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ticketsAfter.Location = New System.Drawing.Point(137, 104)
        Me.ticketsAfter.Name = "ticketsAfter"
        Me.ticketsAfter.Size = New System.Drawing.Size(150, 20)
        Me.ticketsAfter.TabIndex = 44
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(208, 104)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(0, 13)
        Me.Label20.TabIndex = 43
        '
        'doDefects
        '
        Me.doDefects.AutoSize = True
        Me.doDefects.Location = New System.Drawing.Point(126, 41)
        Me.doDefects.Name = "doDefects"
        Me.doDefects.Size = New System.Drawing.Size(63, 17)
        Me.doDefects.TabIndex = 2
        Me.doDefects.Text = "Defects"
        Me.doDefects.UseVisualStyleBackColor = True
        '
        'doTests
        '
        Me.doTests.AutoSize = True
        Me.doTests.Location = New System.Drawing.Point(126, 20)
        Me.doTests.Name = "doTests"
        Me.doTests.Size = New System.Drawing.Size(90, 17)
        Me.doTests.TabIndex = 1
        Me.doTests.Text = "Manual Tests"
        Me.doTests.UseVisualStyleBackColor = True
        '
        'doReqs
        '
        Me.doReqs.AutoSize = True
        Me.doReqs.Location = New System.Drawing.Point(16, 20)
        Me.doReqs.Name = "doReqs"
        Me.doReqs.Size = New System.Drawing.Size(91, 17)
        Me.doReqs.TabIndex = 0
        Me.doReqs.Text = "Requirements"
        Me.doReqs.UseVisualStyleBackColor = True
        '
        'frameDomain
        '
        Me.frameDomain.BackColor = System.Drawing.SystemColors.Control
        Me.frameDomain.Controls.Add(Me.Label1)
        Me.frameDomain.Controls.Add(Me.cmbProject2)
        Me.frameDomain.Controls.Add(Me.cmdLogout)
        Me.frameDomain.Controls.Add(Me.cmbDomain2)
        Me.frameDomain.Controls.Add(Me.cmdLogin)
        Me.frameDomain.Controls.Add(Me.cmbProject)
        Me.frameDomain.Controls.Add(Me.cmbDomain)
        Me.frameDomain.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameDomain.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameDomain.Location = New System.Drawing.Point(8, 152)
        Me.frameDomain.Name = "frameDomain"
        Me.frameDomain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameDomain.Size = New System.Drawing.Size(368, 185)
        Me.frameDomain.TabIndex = 13
        Me.frameDomain.TabStop = False
        Me.frameDomain.Text = "Select Target Domain and Project "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(170, 14)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Select Source Domain and Project"
        '
        'cmbProject2
        '
        Me.cmbProject2.BackColor = System.Drawing.SystemColors.Window
        Me.cmbProject2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject2.Enabled = False
        Me.cmbProject2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProject2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject2.Location = New System.Drawing.Point(6, 122)
        Me.cmbProject2.Name = "cmbProject2"
        Me.cmbProject2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbProject2.Size = New System.Drawing.Size(241, 22)
        Me.cmbProject2.TabIndex = 5
        Me.cmbProject2.Text = "Select Source Project"
        '
        'cmdLogout
        '
        Me.cmdLogout.BackColor = System.Drawing.SystemColors.Control
        Me.cmdLogout.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdLogout.Enabled = False
        Me.cmdLogout.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLogout.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdLogout.Location = New System.Drawing.Point(166, 150)
        Me.cmdLogout.Name = "cmdLogout"
        Me.cmdLogout.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLogout.Size = New System.Drawing.Size(81, 25)
        Me.cmdLogout.TabIndex = 20
        Me.cmdLogout.Text = "Log&out"
        Me.cmdLogout.UseVisualStyleBackColor = False
        '
        'cmbDomain2
        '
        Me.cmbDomain2.BackColor = System.Drawing.SystemColors.Window
        Me.cmbDomain2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbDomain2.Enabled = False
        Me.cmbDomain2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbDomain2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbDomain2.Location = New System.Drawing.Point(6, 94)
        Me.cmbDomain2.Name = "cmbDomain2"
        Me.cmbDomain2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbDomain2.Size = New System.Drawing.Size(241, 22)
        Me.cmbDomain2.TabIndex = 4
        Me.cmbDomain2.Text = "Select Source Domain"
        '
        'cmdLogin
        '
        Me.cmdLogin.BackColor = System.Drawing.SystemColors.Control
        Me.cmdLogin.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdLogin.Enabled = False
        Me.cmdLogin.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLogin.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdLogin.Location = New System.Drawing.Point(6, 150)
        Me.cmdLogin.Name = "cmdLogin"
        Me.cmdLogin.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLogin.Size = New System.Drawing.Size(89, 25)
        Me.cmdLogin.TabIndex = 19
        Me.cmdLogin.Text = "&Login"
        Me.cmdLogin.UseVisualStyleBackColor = False
        '
        'cmbProject
        '
        Me.cmbProject.BackColor = System.Drawing.SystemColors.Window
        Me.cmbProject.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject.Enabled = False
        Me.cmbProject.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProject.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject.Location = New System.Drawing.Point(6, 47)
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbProject.Size = New System.Drawing.Size(241, 22)
        Me.cmbProject.TabIndex = 5
        Me.cmbProject.Text = "Select Target Project"
        '
        'cmbDomain
        '
        Me.cmbDomain.BackColor = System.Drawing.SystemColors.Window
        Me.cmbDomain.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbDomain.Enabled = False
        Me.cmbDomain.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbDomain.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbDomain.Location = New System.Drawing.Point(6, 19)
        Me.cmbDomain.Name = "cmbDomain"
        Me.cmbDomain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbDomain.Size = New System.Drawing.Size(241, 22)
        Me.cmbDomain.TabIndex = 4
        Me.cmbDomain.Text = "Select Target Domain"
        '
        'SaveTokens
        '
        Me.SaveTokens.BackColor = System.Drawing.SystemColors.Control
        Me.SaveTokens.Cursor = System.Windows.Forms.Cursors.Default
        Me.SaveTokens.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaveTokens.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SaveTokens.Location = New System.Drawing.Point(158, 661)
        Me.SaveTokens.Name = "SaveTokens"
        Me.SaveTokens.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SaveTokens.Size = New System.Drawing.Size(103, 33)
        Me.SaveTokens.TabIndex = 104
        Me.SaveTokens.Text = "Save Tokens"
        Me.SaveTokens.UseVisualStyleBackColor = False
        '
        'frameConnection
        '
        Me.frameConnection.BackColor = System.Drawing.SystemColors.Control
        Me.frameConnection.Controls.Add(Me.Frame1)
        Me.frameConnection.Controls.Add(Me.frameDomain)
        Me.frameConnection.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameConnection.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameConnection.Location = New System.Drawing.Point(12, 12)
        Me.frameConnection.Name = "frameConnection"
        Me.frameConnection.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameConnection.Size = New System.Drawing.Size(393, 347)
        Me.frameConnection.TabIndex = 99
        Me.frameConnection.TabStop = False
        Me.frameConnection.Text = "Merge Target Connection "
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.cmdDisconnect)
        Me.Frame1.Controls.Add(Me.cmbURL)
        Me.Frame1.Controls.Add(Me.cmdServer)
        Me.Frame1.Controls.Add(Me.txtPassword)
        Me.Frame1.Controls.Add(Me.txtUser)
        Me.Frame1.Controls.Add(Me.lblUrl)
        Me.Frame1.Controls.Add(Me.lblPassword)
        Me.Frame1.Controls.Add(Me.lblUser)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(8, 25)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(368, 121)
        Me.Frame1.TabIndex = 14
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Quality Center Authentication"
        '
        'cmdDisconnect
        '
        Me.cmdDisconnect.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDisconnect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDisconnect.Enabled = False
        Me.cmdDisconnect.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDisconnect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDisconnect.Location = New System.Drawing.Point(256, 87)
        Me.cmdDisconnect.Name = "cmdDisconnect"
        Me.cmdDisconnect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDisconnect.Size = New System.Drawing.Size(97, 21)
        Me.cmdDisconnect.TabIndex = 22
        Me.cmdDisconnect.Text = "&Disconnect"
        Me.cmdDisconnect.UseVisualStyleBackColor = False
        '
        'cmbURL
        '
        Me.cmbURL.BackColor = System.Drawing.SystemColors.Window
        Me.cmbURL.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbURL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.cmbURL.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbURL.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbURL.Items.AddRange(New Object() {"http://qc.suntrust.com/qcbin/", "http://qc-qa.suntrust.com/qcbin/", "http://qc-dev.suntrust.com/qcbin/"})
        Me.cmbURL.Location = New System.Drawing.Point(64, 24)
        Me.cmbURL.Name = "cmbURL"
        Me.cmbURL.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbURL.Size = New System.Drawing.Size(225, 21)
        Me.cmbURL.TabIndex = 0
        Me.cmbURL.Text = "http://alm12.suntrust.com/qcbin"
        '
        'cmdServer
        '
        Me.cmdServer.BackColor = System.Drawing.SystemColors.Control
        Me.cmdServer.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdServer.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdServer.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdServer.Location = New System.Drawing.Point(256, 56)
        Me.cmdServer.Name = "cmdServer"
        Me.cmdServer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdServer.Size = New System.Drawing.Size(97, 20)
        Me.cmdServer.TabIndex = 3
        Me.cmdServer.Text = "&Authenticate"
        Me.cmdServer.UseVisualStyleBackColor = False
        '
        'txtPassword
        '
        Me.txtPassword.AcceptsReturn = True
        Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
        Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtPassword.Location = New System.Drawing.Point(64, 88)
        Me.txtPassword.MaxLength = 0
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPassword.Size = New System.Drawing.Size(177, 20)
        Me.txtPassword.TabIndex = 2
        '
        'txtUser
        '
        Me.txtUser.AcceptsReturn = True
        Me.txtUser.BackColor = System.Drawing.SystemColors.Window
        Me.txtUser.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUser.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUser.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUser.Location = New System.Drawing.Point(64, 56)
        Me.txtUser.MaxLength = 0
        Me.txtUser.Name = "txtUser"
        Me.txtUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtUser.Size = New System.Drawing.Size(177, 20)
        Me.txtUser.TabIndex = 1
        '
        'lblUrl
        '
        Me.lblUrl.BackColor = System.Drawing.SystemColors.Control
        Me.lblUrl.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUrl.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUrl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUrl.Location = New System.Drawing.Point(6, 27)
        Me.lblUrl.Name = "lblUrl"
        Me.lblUrl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUrl.Size = New System.Drawing.Size(33, 17)
        Me.lblUrl.TabIndex = 21
        Me.lblUrl.Text = "URL: "
        '
        'lblPassword
        '
        Me.lblPassword.BackColor = System.Drawing.SystemColors.Control
        Me.lblPassword.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPassword.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassword.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPassword.Location = New System.Drawing.Point(5, 93)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPassword.Size = New System.Drawing.Size(61, 17)
        Me.lblPassword.TabIndex = 16
        Me.lblPassword.Text = "Password:"
        '
        'lblUser
        '
        Me.lblUser.BackColor = System.Drawing.SystemColors.Control
        Me.lblUser.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblUser.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUser.Location = New System.Drawing.Point(6, 59)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblUser.Size = New System.Drawing.Size(33, 17)
        Me.lblUser.TabIndex = 15
        Me.lblUser.Text = "User:"
        '
        'doMOESynch
        '
        Me.doMOESynch.BackColor = System.Drawing.SystemColors.Control
        Me.doMOESynch.Cursor = System.Windows.Forms.Cursors.Default
        Me.doMOESynch.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.doMOESynch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.doMOESynch.Location = New System.Drawing.Point(12, 661)
        Me.doMOESynch.Name = "doMOESynch"
        Me.doMOESynch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.doMOESynch.Size = New System.Drawing.Size(121, 33)
        Me.doMOESynch.TabIndex = 102
        Me.doMOESynch.Text = "Process Merge"
        Me.doMOESynch.UseVisualStyleBackColor = False
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(284, 661)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(121, 33)
        Me.cmdExit.TabIndex = 103
        Me.cmdExit.Text = "Exit"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'statusBox
        '
        Me.statusBox.Controls.Add(Me.fileProgress)
        Me.statusBox.Controls.Add(Me.RunStatus)
        Me.statusBox.Location = New System.Drawing.Point(12, 525)
        Me.statusBox.Name = "statusBox"
        Me.statusBox.Size = New System.Drawing.Size(393, 130)
        Me.statusBox.TabIndex = 101
        Me.statusBox.TabStop = False
        Me.statusBox.Text = "Status"
        '
        'fileProgress
        '
        Me.fileProgress.Location = New System.Drawing.Point(15, 89)
        Me.fileProgress.Name = "fileProgress"
        Me.fileProgress.Size = New System.Drawing.Size(361, 23)
        Me.fileProgress.TabIndex = 9
        '
        'RunStatus
        '
        Me.RunStatus.BackColor = System.Drawing.SystemColors.Control
        Me.RunStatus.Location = New System.Drawing.Point(15, 19)
        Me.RunStatus.Name = "RunStatus"
        Me.RunStatus.Size = New System.Drawing.Size(361, 55)
        Me.RunStatus.TabIndex = 8
        Me.RunStatus.Text = "Log in to the target ALM project..."
        '
        'ALMDataMerge
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(419, 708)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.SaveTokens)
        Me.Controls.Add(Me.frameConnection)
        Me.Controls.Add(Me.doMOESynch)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.statusBox)
        Me.Name = "ALMDataMerge"
        Me.Text = "ALM 15.5.1 - Data Merge - v 1.4"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.frameDomain.ResumeLayout(False)
        Me.frameDomain.PerformLayout()
        Me.frameConnection.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.statusBox.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents doAllProjects As CheckBox
    Friend WithEvents ticketsAfter As DateTimePicker
    Friend WithEvents Label20 As Label
    Friend WithEvents doDefects As CheckBox
    Friend WithEvents doTests As CheckBox
    Friend WithEvents doReqs As CheckBox
    Public WithEvents frameDomain As GroupBox
    Friend WithEvents Label1 As Label
    Public WithEvents cmbProject2 As ComboBox
    Public WithEvents cmdLogout As Button
    Public WithEvents cmbDomain2 As ComboBox
    Public WithEvents cmdLogin As Button
    Public WithEvents cmbProject As ComboBox
    Public WithEvents cmbDomain As ComboBox
    Public WithEvents SaveTokens As Button
    Public WithEvents frameConnection As GroupBox
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdDisconnect As Button
    Public WithEvents cmbURL As ComboBox
    Public WithEvents cmdServer As Button
    Public WithEvents txtPassword As TextBox
    Public WithEvents txtUser As TextBox
    Public WithEvents lblUrl As Label
    Public WithEvents lblPassword As Label
    Public WithEvents lblUser As Label
    Public WithEvents doMOESynch As Button
    Public WithEvents cmdExit As Button
    Friend WithEvents statusBox As GroupBox
    Friend WithEvents fileProgress As ProgressBar
    Friend WithEvents RunStatus As RichTextBox
    Friend WithEvents ticketsTo As DateTimePicker
    Friend WithEvents checkTo As CheckBox
    Friend WithEvents checkFrom As CheckBox
    Friend WithEvents doLinks As CheckBox
    Friend WithEvents doTestSets As CheckBox
    Friend WithEvents doAttachments As CheckBox
    Friend WithEvents doAutoTests As CheckBox
End Class
